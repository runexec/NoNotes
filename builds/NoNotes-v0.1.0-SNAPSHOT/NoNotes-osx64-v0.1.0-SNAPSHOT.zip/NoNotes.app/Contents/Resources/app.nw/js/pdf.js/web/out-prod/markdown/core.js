// Compiled by ClojureScript 1.9.229 {}
goog.provide('markdown.core');
goog.require('cljs.core');
goog.require('markdown.common');
goog.require('markdown.links');
goog.require('markdown.transformers');
markdown.core.init_transformer = (function markdown$core$init_transformer(p__9246){
var map__9257 = p__9246;
var map__9257__$1 = ((((!((map__9257 == null)))?((((map__9257.cljs$lang$protocol_mask$partition0$ & (64))) || (map__9257.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__9257):map__9257);
var replacement_transformers = cljs.core.get.call(null,map__9257__$1,new cljs.core.Keyword(null,"replacement-transformers","replacement-transformers",-2028552897));
var custom_transformers = cljs.core.get.call(null,map__9257__$1,new cljs.core.Keyword(null,"custom-transformers","custom-transformers",1440601790));
return ((function (map__9257,map__9257__$1,replacement_transformers,custom_transformers){
return (function (html,line,next_line,state){
var _STAR_next_line_STAR_9259 = markdown.transformers._STAR_next_line_STAR_;
markdown.transformers._STAR_next_line_STAR_ = next_line;

try{var vec__9260 = cljs.core.reduce.call(null,((function (_STAR_next_line_STAR_9259,map__9257,map__9257__$1,replacement_transformers,custom_transformers){
return (function (p__9263,transformer){
var vec__9264 = p__9263;
var text = cljs.core.nth.call(null,vec__9264,(0),null);
var state__$1 = cljs.core.nth.call(null,vec__9264,(1),null);
return transformer.call(null,text,state__$1);
});})(_STAR_next_line_STAR_9259,map__9257,map__9257__$1,replacement_transformers,custom_transformers))
,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [line,state], null),(function (){var or__6409__auto__ = replacement_transformers;
if(cljs.core.truth_(or__6409__auto__)){
return or__6409__auto__;
} else {
return cljs.core.into.call(null,markdown.transformers.transformer_vector,custom_transformers);
}
})());
var text = cljs.core.nth.call(null,vec__9260,(0),null);
var new_state = cljs.core.nth.call(null,vec__9260,(1),null);
html.append(text);

return new_state;
}finally {markdown.transformers._STAR_next_line_STAR_ = _STAR_next_line_STAR_9259;
}});
;})(map__9257,map__9257__$1,replacement_transformers,custom_transformers))
});
/**
 * Removed from cljs.core 0.0-1885, Ref. http://goo.gl/su7Xkj
 */
markdown.core.format = (function markdown$core$format(var_args){
var args__7491__auto__ = [];
var len__7484__auto___9269 = arguments.length;
var i__7485__auto___9270 = (0);
while(true){
if((i__7485__auto___9270 < len__7484__auto___9269)){
args__7491__auto__.push((arguments[i__7485__auto___9270]));

var G__9271 = (i__7485__auto___9270 + (1));
i__7485__auto___9270 = G__9271;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((1) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((1)),(0),null)):null);
return markdown.core.format.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__7492__auto__);
});

markdown.core.format.cljs$core$IFn$_invoke$arity$variadic = (function (fmt,args){
return cljs.core.apply.call(null,goog.string.format,fmt,args);
});

markdown.core.format.cljs$lang$maxFixedArity = (1);

markdown.core.format.cljs$lang$applyTo = (function (seq9267){
var G__9268 = cljs.core.first.call(null,seq9267);
var seq9267__$1 = cljs.core.next.call(null,seq9267);
return markdown.core.format.cljs$core$IFn$_invoke$arity$variadic(G__9268,seq9267__$1);
});

markdown.core.parse_references = (function markdown$core$parse_references(lines){
var references = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var seq__9276_9280 = cljs.core.seq.call(null,lines);
var chunk__9277_9281 = null;
var count__9278_9282 = (0);
var i__9279_9283 = (0);
while(true){
if((i__9279_9283 < count__9278_9282)){
var line_9284 = cljs.core._nth.call(null,chunk__9277_9281,i__9279_9283);
markdown.links.parse_reference_link.call(null,line_9284,references);

var G__9285 = seq__9276_9280;
var G__9286 = chunk__9277_9281;
var G__9287 = count__9278_9282;
var G__9288 = (i__9279_9283 + (1));
seq__9276_9280 = G__9285;
chunk__9277_9281 = G__9286;
count__9278_9282 = G__9287;
i__9279_9283 = G__9288;
continue;
} else {
var temp__4657__auto___9289 = cljs.core.seq.call(null,seq__9276_9280);
if(temp__4657__auto___9289){
var seq__9276_9290__$1 = temp__4657__auto___9289;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__9276_9290__$1)){
var c__7220__auto___9291 = cljs.core.chunk_first.call(null,seq__9276_9290__$1);
var G__9292 = cljs.core.chunk_rest.call(null,seq__9276_9290__$1);
var G__9293 = c__7220__auto___9291;
var G__9294 = cljs.core.count.call(null,c__7220__auto___9291);
var G__9295 = (0);
seq__9276_9280 = G__9292;
chunk__9277_9281 = G__9293;
count__9278_9282 = G__9294;
i__9279_9283 = G__9295;
continue;
} else {
var line_9296 = cljs.core.first.call(null,seq__9276_9290__$1);
markdown.links.parse_reference_link.call(null,line_9296,references);

var G__9297 = cljs.core.next.call(null,seq__9276_9290__$1);
var G__9298 = null;
var G__9299 = (0);
var G__9300 = (0);
seq__9276_9280 = G__9297;
chunk__9277_9281 = G__9298;
count__9278_9282 = G__9299;
i__9279_9283 = G__9300;
continue;
}
} else {
}
}
break;
}

return cljs.core.deref.call(null,references);
});
markdown.core.parse_footnotes = (function markdown$core$parse_footnotes(lines){
var footnotes = cljs.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"next-fn-id","next-fn-id",738579636),(1),new cljs.core.Keyword(null,"processed","processed",800622264),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"unprocessed","unprocessed",766771972),cljs.core.PersistentArrayMap.EMPTY], null));
var seq__9305_9309 = cljs.core.seq.call(null,lines);
var chunk__9306_9310 = null;
var count__9307_9311 = (0);
var i__9308_9312 = (0);
while(true){
if((i__9308_9312 < count__9307_9311)){
var line_9313 = cljs.core._nth.call(null,chunk__9306_9310,i__9308_9312);
markdown.links.parse_footnote_link.call(null,line_9313,footnotes);

var G__9314 = seq__9305_9309;
var G__9315 = chunk__9306_9310;
var G__9316 = count__9307_9311;
var G__9317 = (i__9308_9312 + (1));
seq__9305_9309 = G__9314;
chunk__9306_9310 = G__9315;
count__9307_9311 = G__9316;
i__9308_9312 = G__9317;
continue;
} else {
var temp__4657__auto___9318 = cljs.core.seq.call(null,seq__9305_9309);
if(temp__4657__auto___9318){
var seq__9305_9319__$1 = temp__4657__auto___9318;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__9305_9319__$1)){
var c__7220__auto___9320 = cljs.core.chunk_first.call(null,seq__9305_9319__$1);
var G__9321 = cljs.core.chunk_rest.call(null,seq__9305_9319__$1);
var G__9322 = c__7220__auto___9320;
var G__9323 = cljs.core.count.call(null,c__7220__auto___9320);
var G__9324 = (0);
seq__9305_9309 = G__9321;
chunk__9306_9310 = G__9322;
count__9307_9311 = G__9323;
i__9308_9312 = G__9324;
continue;
} else {
var line_9325 = cljs.core.first.call(null,seq__9305_9319__$1);
markdown.links.parse_footnote_link.call(null,line_9325,footnotes);

var G__9326 = cljs.core.next.call(null,seq__9305_9319__$1);
var G__9327 = null;
var G__9328 = (0);
var G__9329 = (0);
seq__9305_9309 = G__9326;
chunk__9306_9310 = G__9327;
count__9307_9311 = G__9328;
i__9308_9312 = G__9329;
continue;
}
} else {
}
}
break;
}

return cljs.core.deref.call(null,footnotes);
});
markdown.core.parse_metadata = (function markdown$core$parse_metadata(lines){
var vec__9334 = cljs.core.split_with.call(null,(function (p1__9330_SHARP_){
return cljs.core.not_empty.call(null,p1__9330_SHARP_.trim());
}),lines);
var metadata = cljs.core.nth.call(null,vec__9334,(0),null);
var lines__$1 = cljs.core.nth.call(null,vec__9334,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [markdown.transformers.parse_metadata_headers.call(null,metadata),lines__$1], null);
});
/**
 * processes input text line by line and outputs an HTML string
 */
markdown.core.md_to_html_string_STAR_ = (function markdown$core$md_to_html_string_STAR_(text,params){
var _STAR_substring_STAR_9352 = markdown.common._STAR_substring_STAR_;
var formatter9353 = markdown.transformers.formatter;
markdown.common._STAR_substring_STAR_ = ((function (_STAR_substring_STAR_9352,formatter9353){
return (function (s,n){
return cljs.core.apply.call(null,cljs.core.str,cljs.core.drop.call(null,n,s));
});})(_STAR_substring_STAR_9352,formatter9353))
;

markdown.transformers.formatter = markdown.core.format;

try{var params__$1 = (cljs.core.truth_(params)?cljs.core.apply.call(null,cljs.core.partial.call(null,cljs.core.assoc,cljs.core.PersistentArrayMap.EMPTY),params):null);
var lines = [cljs.core.str(text),cljs.core.str("\n")].join('').split("\n");
var html = (new goog.string.StringBuffer(""));
var references = (cljs.core.truth_(new cljs.core.Keyword(null,"reference-links?","reference-links?",-2003778981).cljs$core$IFn$_invoke$arity$1(params__$1))?markdown.core.parse_references.call(null,lines):null);
var footnotes = (cljs.core.truth_(new cljs.core.Keyword(null,"footnotes?","footnotes?",-1590157845).cljs$core$IFn$_invoke$arity$1(params__$1))?markdown.core.parse_footnotes.call(null,lines):null);
var vec__9354 = (cljs.core.truth_(new cljs.core.Keyword(null,"parse-meta?","parse-meta?",-1938948742).cljs$core$IFn$_invoke$arity$1(params__$1))?markdown.core.parse_metadata.call(null,lines):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [null,lines], null));
var metadata = cljs.core.nth.call(null,vec__9354,(0),null);
var lines__$1 = cljs.core.nth.call(null,vec__9354,(1),null);
var transformer = markdown.core.init_transformer.call(null,params__$1);
var G__9360_9367 = lines__$1;
var vec__9361_9368 = G__9360_9367;
var seq__9362_9369 = cljs.core.seq.call(null,vec__9361_9368);
var first__9363_9370 = cljs.core.first.call(null,seq__9362_9369);
var seq__9362_9371__$1 = cljs.core.next.call(null,seq__9362_9369);
var line_9372 = first__9363_9370;
var more_9373 = seq__9362_9371__$1;
var state_9374 = cljs.core.merge.call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"clojurescript","clojurescript",-299769403),true,new cljs.core.Keyword(null,"references","references",882562509),references,new cljs.core.Keyword(null,"footnotes","footnotes",-1842778205),footnotes,new cljs.core.Keyword(null,"last-line-empty?","last-line-empty?",1279111527),true], null),params__$1);
var G__9360_9375__$1 = G__9360_9367;
var state_9376__$1 = state_9374;
while(true){
var vec__9364_9377 = G__9360_9375__$1;
var seq__9365_9378 = cljs.core.seq.call(null,vec__9364_9377);
var first__9366_9379 = cljs.core.first.call(null,seq__9365_9378);
var seq__9365_9380__$1 = cljs.core.next.call(null,seq__9365_9378);
var line_9381__$1 = first__9366_9379;
var more_9382__$1 = seq__9365_9380__$1;
var state_9383__$2 = state_9376__$1;
var state_9384__$3 = (cljs.core.truth_(new cljs.core.Keyword(null,"buf","buf",-213913340).cljs$core$IFn$_invoke$arity$1(state_9383__$2))?transformer.call(null,html,new cljs.core.Keyword(null,"buf","buf",-213913340).cljs$core$IFn$_invoke$arity$1(state_9383__$2),cljs.core.first.call(null,more_9382__$1),cljs.core.assoc.call(null,cljs.core.dissoc.call(null,state_9383__$2,new cljs.core.Keyword(null,"buf","buf",-213913340),new cljs.core.Keyword(null,"lists","lists",-884730684)),new cljs.core.Keyword(null,"last-line-empty?","last-line-empty?",1279111527),true)):state_9383__$2);
if(cljs.core.truth_(cljs.core.not_empty.call(null,more_9382__$1))){
var G__9385 = more_9382__$1;
var G__9386 = cljs.core.assoc.call(null,transformer.call(null,html,line_9381__$1,cljs.core.first.call(null,more_9382__$1),state_9384__$3),new cljs.core.Keyword(null,"last-line-empty?","last-line-empty?",1279111527),cljs.core.empty_QMARK_.call(null,line_9381__$1));
G__9360_9375__$1 = G__9385;
state_9376__$1 = G__9386;
continue;
} else {
transformer.call(null,html.append(markdown.transformers.footer.call(null,new cljs.core.Keyword(null,"footnotes","footnotes",-1842778205).cljs$core$IFn$_invoke$arity$1(state_9384__$3))),line_9381__$1,"",cljs.core.assoc.call(null,state_9384__$3,new cljs.core.Keyword(null,"eof","eof",-489063237),true));
}
break;
}

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"metadata","metadata",1799301597),metadata,new cljs.core.Keyword(null,"html","html",-998796897),html.toString()], null);
}finally {markdown.transformers.formatter = formatter9353;

markdown.common._STAR_substring_STAR_ = _STAR_substring_STAR_9352;
}});
markdown.core.md__GT_html = (function markdown$core$md__GT_html(var_args){
var args__7491__auto__ = [];
var len__7484__auto___9389 = arguments.length;
var i__7485__auto___9390 = (0);
while(true){
if((i__7485__auto___9390 < len__7484__auto___9389)){
args__7491__auto__.push((arguments[i__7485__auto___9390]));

var G__9391 = (i__7485__auto___9390 + (1));
i__7485__auto___9390 = G__9391;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((1) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((1)),(0),null)):null);
return markdown.core.md__GT_html.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__7492__auto__);
});

markdown.core.md__GT_html.cljs$core$IFn$_invoke$arity$variadic = (function (text,params){
return new cljs.core.Keyword(null,"html","html",-998796897).cljs$core$IFn$_invoke$arity$1(markdown.core.md_to_html_string_STAR_.call(null,text,params));
});

markdown.core.md__GT_html.cljs$lang$maxFixedArity = (1);

markdown.core.md__GT_html.cljs$lang$applyTo = (function (seq9387){
var G__9388 = cljs.core.first.call(null,seq9387);
var seq9387__$1 = cljs.core.next.call(null,seq9387);
return markdown.core.md__GT_html.cljs$core$IFn$_invoke$arity$variadic(G__9388,seq9387__$1);
});

markdown.core.md__GT_html_with_meta = (function markdown$core$md__GT_html_with_meta(var_args){
var args__7491__auto__ = [];
var len__7484__auto___9394 = arguments.length;
var i__7485__auto___9395 = (0);
while(true){
if((i__7485__auto___9395 < len__7484__auto___9394)){
args__7491__auto__.push((arguments[i__7485__auto___9395]));

var G__9396 = (i__7485__auto___9395 + (1));
i__7485__auto___9395 = G__9396;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((1) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((1)),(0),null)):null);
return markdown.core.md__GT_html_with_meta.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__7492__auto__);
});

markdown.core.md__GT_html_with_meta.cljs$core$IFn$_invoke$arity$variadic = (function (text,params){
return markdown.core.md_to_html_string_STAR_.call(null,text,cljs.core.into.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"parse-meta?","parse-meta?",-1938948742),true], null),params));
});

markdown.core.md__GT_html_with_meta.cljs$lang$maxFixedArity = (1);

markdown.core.md__GT_html_with_meta.cljs$lang$applyTo = (function (seq9392){
var G__9393 = cljs.core.first.call(null,seq9392);
var seq9392__$1 = cljs.core.next.call(null,seq9392);
return markdown.core.md__GT_html_with_meta.cljs$core$IFn$_invoke$arity$variadic(G__9393,seq9392__$1);
});

/**
 * Js accessible wrapper
 */
markdown.core.mdToHtml = (function markdown$core$mdToHtml(var_args){
var args__7491__auto__ = [];
var len__7484__auto___9398 = arguments.length;
var i__7485__auto___9399 = (0);
while(true){
if((i__7485__auto___9399 < len__7484__auto___9398)){
args__7491__auto__.push((arguments[i__7485__auto___9399]));

var G__9400 = (i__7485__auto___9399 + (1));
i__7485__auto___9399 = G__9400;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((0) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((0)),(0),null)):null);
return markdown.core.mdToHtml.cljs$core$IFn$_invoke$arity$variadic(argseq__7492__auto__);
});
goog.exportSymbol('markdown.core.mdToHtml', markdown.core.mdToHtml);

markdown.core.mdToHtml.cljs$core$IFn$_invoke$arity$variadic = (function (params){
return cljs.core.apply.call(null,markdown.core.md__GT_html,params);
});

markdown.core.mdToHtml.cljs$lang$maxFixedArity = (0);

markdown.core.mdToHtml.cljs$lang$applyTo = (function (seq9397){
return markdown.core.mdToHtml.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq9397));
});

/**
 * Js accessible wrapper
 */
markdown.core.mdToHtmlWithMeta = (function markdown$core$mdToHtmlWithMeta(var_args){
var args__7491__auto__ = [];
var len__7484__auto___9402 = arguments.length;
var i__7485__auto___9403 = (0);
while(true){
if((i__7485__auto___9403 < len__7484__auto___9402)){
args__7491__auto__.push((arguments[i__7485__auto___9403]));

var G__9404 = (i__7485__auto___9403 + (1));
i__7485__auto___9403 = G__9404;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((0) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((0)),(0),null)):null);
return markdown.core.mdToHtmlWithMeta.cljs$core$IFn$_invoke$arity$variadic(argseq__7492__auto__);
});
goog.exportSymbol('markdown.core.mdToHtmlWithMeta', markdown.core.mdToHtmlWithMeta);

markdown.core.mdToHtmlWithMeta.cljs$core$IFn$_invoke$arity$variadic = (function (params){
return cljs.core.apply.call(null,markdown.core.md__GT_html_with_meta,params);
});

markdown.core.mdToHtmlWithMeta.cljs$lang$maxFixedArity = (0);

markdown.core.mdToHtmlWithMeta.cljs$lang$applyTo = (function (seq9401){
return markdown.core.mdToHtmlWithMeta.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq9401));
});

