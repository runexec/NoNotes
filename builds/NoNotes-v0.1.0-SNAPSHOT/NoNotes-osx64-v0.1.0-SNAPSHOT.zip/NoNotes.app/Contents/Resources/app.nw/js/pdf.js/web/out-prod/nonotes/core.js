// Compiled by ClojureScript 1.9.229 {}
goog.provide('nonotes.core');
goog.require('cljs.core');
goog.require('reagent.core');
goog.require('markdown.core');
goog.require('goog.string');
goog.require('cljs.core.async');
goog.require('cljs.nodejs');
goog.require('goog.string.format');
goog.require('clojure.string');
/**
 * Native FIleSystem
 */
nonotes.core.fs = cljs.nodejs.require.call(null,"fs");
/**
 * OS Detection
 */
nonotes.core.nix_QMARK_ = cljs.core.not_EQ_.call(null,"win32",process.platform);
/**
 * OS Sensative Path Directory Delimiter
 */
nonotes.core.slash = (cljs.core.truth_(nonotes.core.nix_QMARK_)?"/":"\\");
var data_path_14048 = nw.App.dataPath;
if(typeof nonotes.core._PLUS_state_PLUS_ !== 'undefined'){
} else {
nonotes.core._PLUS_state_PLUS_ = reagent.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"paths","paths",-1807389588),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"data","data",-232669377),nw.App.dataPath,new cljs.core.Keyword(null,"notes","notes",-1039600523),data_path_14048], null),new cljs.core.Keyword(null,"toggle","toggle",1291842030),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"editor","editor",-989377770),false,new cljs.core.Keyword(null,"about","about",1423892543),false], null),new cljs.core.Keyword(null,"note-area","note-area",279463347),""], null));
}
/**
 * Simple boolean inversion
 */
nonotes.core.toggle_BANG__STAR_ = (function nonotes$core$toggle_BANG__STAR_(var_args){
var args__7491__auto__ = [];
var len__7484__auto___14050 = arguments.length;
var i__7485__auto___14051 = (0);
while(true){
if((i__7485__auto___14051 < len__7484__auto___14050)){
args__7491__auto__.push((arguments[i__7485__auto___14051]));

var G__14052 = (i__7485__auto___14051 + (1));
i__7485__auto___14051 = G__14052;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((0) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((0)),(0),null)):null);
return nonotes.core.toggle_BANG__STAR_.cljs$core$IFn$_invoke$arity$variadic(argseq__7492__auto__);
});

nonotes.core.toggle_BANG__STAR_.cljs$core$IFn$_invoke$arity$variadic = (function (ks){
return cljs.core.swap_BANG_.call(null,nonotes.core._PLUS_state_PLUS_,cljs.core.update_in,cljs.core.into.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"toggle","toggle",1291842030)], null),ks),cljs.core.not);
});

nonotes.core.toggle_BANG__STAR_.cljs$lang$maxFixedArity = (0);

nonotes.core.toggle_BANG__STAR_.cljs$lang$applyTo = (function (seq14049){
return nonotes.core.toggle_BANG__STAR_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq14049));
});

/**
 * Async toggle!*
 */
nonotes.core.toggle_BANG_ = (function nonotes$core$toggle_BANG_(var_args){
var args__7491__auto__ = [];
var len__7484__auto___14065 = arguments.length;
var i__7485__auto___14066 = (0);
while(true){
if((i__7485__auto___14066 < len__7484__auto___14065)){
args__7491__auto__.push((arguments[i__7485__auto___14066]));

var G__14067 = (i__7485__auto___14066 + (1));
i__7485__auto___14066 = G__14067;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((0) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((0)),(0),null)):null);
return nonotes.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$variadic(argseq__7492__auto__);
});

nonotes.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ks){
var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__){
return (function (state_14056){
var state_val_14057 = (state_14056[(1)]);
if((state_val_14057 === (1))){
var inst_14054 = cljs.core.apply.call(null,nonotes.core.toggle_BANG__STAR_,ks);
var state_14056__$1 = state_14056;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_14056__$1,inst_14054);
} else {
return null;
}
});})(c__11244__auto__))
;
return ((function (switch__11132__auto__,c__11244__auto__){
return (function() {
var nonotes$core$state_machine__11133__auto__ = null;
var nonotes$core$state_machine__11133__auto____0 = (function (){
var statearr_14061 = [null,null,null,null,null,null,null];
(statearr_14061[(0)] = nonotes$core$state_machine__11133__auto__);

(statearr_14061[(1)] = (1));

return statearr_14061;
});
var nonotes$core$state_machine__11133__auto____1 = (function (state_14056){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_14056);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e14062){if((e14062 instanceof Object)){
var ex__11136__auto__ = e14062;
var statearr_14063_14068 = state_14056;
(statearr_14063_14068[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_14056);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e14062;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__14069 = state_14056;
state_14056 = G__14069;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
nonotes$core$state_machine__11133__auto__ = function(state_14056){
switch(arguments.length){
case 0:
return nonotes$core$state_machine__11133__auto____0.call(this);
case 1:
return nonotes$core$state_machine__11133__auto____1.call(this,state_14056);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
nonotes$core$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = nonotes$core$state_machine__11133__auto____0;
nonotes$core$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = nonotes$core$state_machine__11133__auto____1;
return nonotes$core$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__))
})();
var state__11246__auto__ = (function (){var statearr_14064 = f__11245__auto__.call(null);
(statearr_14064[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_14064;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__))
);

return c__11244__auto__;
});

nonotes.core.toggle_BANG_.cljs$lang$maxFixedArity = (0);

nonotes.core.toggle_BANG_.cljs$lang$applyTo = (function (seq14053){
return nonotes.core.toggle_BANG_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq14053));
});

/**
 * Toggle State
 */
nonotes.core.toggle = (function nonotes$core$toggle(k){
return k.call(null,new cljs.core.Keyword(null,"toggle","toggle",1291842030).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,nonotes.core._PLUS_state_PLUS_)));
});
nonotes.core.toggle_editor_BANG_ = (function nonotes$core$toggle_editor_BANG_(){
return nonotes.core.toggle_BANG_.call(null,new cljs.core.Keyword(null,"editor","editor",-989377770));
});
/**
 * Synchronous toggle-editor!
 */
nonotes.core.toggle_editor_BANG__STAR_ = (function nonotes$core$toggle_editor_BANG__STAR_(){
return nonotes.core.toggle_BANG__STAR_.call(null,new cljs.core.Keyword(null,"editor","editor",-989377770));
});
/**
 * Current value
 */
nonotes.core.toggle_editor = (function nonotes$core$toggle_editor(){
return nonotes.core.toggle.call(null,new cljs.core.Keyword(null,"editor","editor",-989377770));
});
nonotes.core.toggle_about_BANG_ = (function nonotes$core$toggle_about_BANG_(){
return nonotes.core.toggle_BANG_.call(null,new cljs.core.Keyword(null,"about","about",1423892543));
});
/**
 * Current Value
 */
nonotes.core.toggle_about = (function nonotes$core$toggle_about(){
return nonotes.core.toggle.call(null,new cljs.core.Keyword(null,"about","about",1423892543));
});
/**
 * Note area data channel
 */
nonotes.core.notes_chan = cljs.core.async.chan.call(null);
var c__11244__auto___14095 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___14095){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___14095){
return (function (state_14081){
var state_val_14082 = (state_14081[(1)]);
if((state_val_14082 === (1))){
var state_14081__$1 = state_14081;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_14081__$1,(2),nonotes.core.notes_chan);
} else {
if((state_val_14082 === (2))){
var inst_14071 = (state_14081[(2)]);
var inst_14072 = inst_14071;
var state_14081__$1 = (function (){var statearr_14083 = state_14081;
(statearr_14083[(7)] = inst_14072);

return statearr_14083;
})();
var statearr_14084_14096 = state_14081__$1;
(statearr_14084_14096[(2)] = null);

(statearr_14084_14096[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_14082 === (3))){
var inst_14072 = (state_14081[(7)]);
var inst_14074 = cljs.core.swap_BANG_.call(null,nonotes.core._PLUS_state_PLUS_,cljs.core.assoc,new cljs.core.Keyword(null,"note-area","note-area",279463347),inst_14072);
var state_14081__$1 = (function (){var statearr_14085 = state_14081;
(statearr_14085[(8)] = inst_14074);

return statearr_14085;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_14081__$1,(5),nonotes.core.notes_chan);
} else {
if((state_val_14082 === (4))){
var inst_14079 = (state_14081[(2)]);
var state_14081__$1 = state_14081;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_14081__$1,inst_14079);
} else {
if((state_val_14082 === (5))){
var inst_14076 = (state_14081[(2)]);
var inst_14072 = inst_14076;
var state_14081__$1 = (function (){var statearr_14086 = state_14081;
(statearr_14086[(7)] = inst_14072);

return statearr_14086;
})();
var statearr_14087_14097 = state_14081__$1;
(statearr_14087_14097[(2)] = null);

(statearr_14087_14097[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
});})(c__11244__auto___14095))
;
return ((function (switch__11132__auto__,c__11244__auto___14095){
return (function() {
var nonotes$core$state_machine__11133__auto__ = null;
var nonotes$core$state_machine__11133__auto____0 = (function (){
var statearr_14091 = [null,null,null,null,null,null,null,null,null];
(statearr_14091[(0)] = nonotes$core$state_machine__11133__auto__);

(statearr_14091[(1)] = (1));

return statearr_14091;
});
var nonotes$core$state_machine__11133__auto____1 = (function (state_14081){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_14081);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e14092){if((e14092 instanceof Object)){
var ex__11136__auto__ = e14092;
var statearr_14093_14098 = state_14081;
(statearr_14093_14098[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_14081);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e14092;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__14099 = state_14081;
state_14081 = G__14099;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
nonotes$core$state_machine__11133__auto__ = function(state_14081){
switch(arguments.length){
case 0:
return nonotes$core$state_machine__11133__auto____0.call(this);
case 1:
return nonotes$core$state_machine__11133__auto____1.call(this,state_14081);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
nonotes$core$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = nonotes$core$state_machine__11133__auto____0;
nonotes$core$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = nonotes$core$state_machine__11133__auto____1;
return nonotes$core$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___14095))
})();
var state__11246__auto__ = (function (){var statearr_14094 = f__11245__auto__.call(null);
(statearr_14094[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___14095);

return statearr_14094;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___14095))
);

/**
 * For Exporting Notes
 */
nonotes.core.notes_path = (function nonotes$core$notes_path(var_args){
var args14100 = [];
var len__7484__auto___14103 = arguments.length;
var i__7485__auto___14104 = (0);
while(true){
if((i__7485__auto___14104 < len__7484__auto___14103)){
args14100.push((arguments[i__7485__auto___14104]));

var G__14105 = (i__7485__auto___14104 + (1));
i__7485__auto___14104 = G__14105;
continue;
} else {
}
break;
}

var G__14102 = args14100.length;
switch (G__14102) {
case 0:
return nonotes.core.notes_path.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return nonotes.core.notes_path.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args14100.length)].join('')));

}
});

nonotes.core.notes_path.cljs$core$IFn$_invoke$arity$0 = (function (){
return new cljs.core.Keyword(null,"notes","notes",-1039600523).cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"paths","paths",-1807389588).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,nonotes.core._PLUS_state_PLUS_)));
});

nonotes.core.notes_path.cljs$core$IFn$_invoke$arity$1 = (function (pdf_file_name){
return [cljs.core.str(nonotes.core.notes_path.call(null)),cljs.core.str(nonotes.core.slash),cljs.core.str(pdf_file_name)].join('');
});

nonotes.core.notes_path.cljs$lang$maxFixedArity = 1;

/**
 * Current Note Data
 */
nonotes.core.note_area = (function nonotes$core$note_area(){
return new cljs.core.Keyword(null,"note-area","note-area",279463347).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,nonotes.core._PLUS_state_PLUS_));
});
/**
 * Async Note value setting
 */
nonotes.core.note_area_BANG_ = (function nonotes$core$note_area_BANG_(evt){
return cljs.core.async.put_BANG_.call(null,nonotes.core.notes_chan,evt.currentTarget.value);
});
/**
 * Markdown to HTML
 */
nonotes.core.html_notes = (function nonotes$core$html_notes(){
return markdown.core.md__GT_html.call(null,clojure.string.replace.call(null,nonotes.core.note_area.call(null),/\n/,"<br />\n"));
});
/**
 * Loaded Notes FilePath for export
 */
nonotes.core.current_notes_fp = (function nonotes$core$current_notes_fp(){
return nonotes.core.notes_path.call(null,[cljs.core.str(PDFViewerApplication.documentFingerprint),cljs.core.str(".nonotes")].join(''));
});
/**
 * Reading Page Value
 */
nonotes.core.current_page = (function nonotes$core$current_page(){
return document.getElementById("pageNumber").value;
});
/**
 * Annotation injection when opening note editor
 */
nonotes.core.inject_page_string = [cljs.core.str("%s\n<p><a class=\"annotation note-started\">Note Started : %s</a><br />"),cljs.core.str("<a class=\"annotation page-link\" target=\"_parent\" href=\"#page=%d\">Page %d</a>"),cljs.core.str("<a class=\"annotation page-book\" target=\"_parent\" href=\"#page=1\">%s</a></p>\n\n   ")].join('');
/**
 * Annotation injection
 */
nonotes.core.inject_note_page_BANG_ = (function nonotes$core$inject_note_page_BANG_(){
return cljs.core.swap_BANG_.call(null,nonotes.core._PLUS_state_PLUS_,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"note-area","note-area",279463347)], null),(function (na){
var cp = nonotes.core.current_page.call(null);
return goog.string.format(nonotes.core.inject_page_string,na,(new Date()),cp,cp,document.title);
}));
});
/**
 * HTML Element
 */
nonotes.core.editor = (function nonotes$core$editor(){
return document.getElementById("noteInput");
});
/**
 * Display Editor Toggle
 */
nonotes.core.toggle_event_BANG_ = (function nonotes$core$toggle_event_BANG_(){
return nonotes.core.toggle_editor_BANG_.call(null);
});
/**
 * About Page Toggle
 */
nonotes.core.about_event_BANG_ = (function nonotes$core$about_event_BANG_(_){
return nonotes.core.toggle_about_BANG_.call(null);
});
/**
 * Invoke PDF.js Open File
 */
nonotes.core.open_event_BANG_ = (function nonotes$core$open_event_BANG_(_){
var fp = (function (){
return document.getElementById("openFile");
});
return fp.call(null).click();
});
/**
 * Sync preview box with input box tail input
 */
nonotes.core.scroll_preview_event_BANG_ = (function nonotes$core$scroll_preview_event_BANG_(_){
var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__){
return (function (state_14124){
var state_val_14125 = (state_14124[(1)]);
if((state_val_14125 === (1))){
var inst_14120 = document.getElementById("htmlPreview");
var inst_14121 = inst_14120.scrollHeight;
var inst_14122 = inst_14120.scrollTop = inst_14121;
var state_14124__$1 = state_14124;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_14124__$1,inst_14122);
} else {
return null;
}
});})(c__11244__auto__))
;
return ((function (switch__11132__auto__,c__11244__auto__){
return (function() {
var nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__ = null;
var nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____0 = (function (){
var statearr_14129 = [null,null,null,null,null,null,null];
(statearr_14129[(0)] = nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__);

(statearr_14129[(1)] = (1));

return statearr_14129;
});
var nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____1 = (function (state_14124){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_14124);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e14130){if((e14130 instanceof Object)){
var ex__11136__auto__ = e14130;
var statearr_14131_14133 = state_14124;
(statearr_14131_14133[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_14124);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e14130;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__14134 = state_14124;
state_14124 = G__14134;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__ = function(state_14124){
switch(arguments.length){
case 0:
return nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____0.call(this);
case 1:
return nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____1.call(this,state_14124);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____0;
nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto____1;
return nonotes$core$scroll_preview_event_BANG__$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__))
})();
var state__11246__auto__ = (function (){var statearr_14132 = f__11245__auto__.call(null);
(statearr_14132[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_14132;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__))
);

return c__11244__auto__;
});
/**
 * Opens Editor
 */
nonotes.core.new_event_BANG_ = (function nonotes$core$new_event_BANG_(_){
nonotes.core.toggle_editor_BANG__STAR_.call(null);

if(cljs.core.truth_(nonotes.core.toggle_editor.call(null))){
nonotes.core.inject_note_page_BANG_.call(null);

return setTimeout((function (){
nonotes.core.scroll_preview_event_BANG_.call(null,null);

var e = nonotes.core.editor.call(null);
e.scrollTop = e.scrollHeight;

e.focus();

return e.click();
}),(100));
} else {
return null;
}
});
/**
 * Load Notes
 */
nonotes.core.load_event_BANG_ = (function nonotes$core$load_event_BANG_(_){
return nonotes.core.fs.readFile(nonotes.core.current_notes_fp.call(null),"utf8",(function (err,data){
if(cljs.core.truth_(err)){
console.log([cljs.core.str("A Loading Error: "),cljs.core.str(err)].join(''));
} else {
}

return cljs.core.swap_BANG_.call(null,nonotes.core._PLUS_state_PLUS_,cljs.core.assoc,new cljs.core.Keyword(null,"note-area","note-area",279463347),(function (){var or__6409__auto__ = data;
if(cljs.core.truth_(or__6409__auto__)){
return or__6409__auto__;
} else {
return "";
}
})());
}));
});
/**
 * Save Notes
 */
nonotes.core.save_event_BANG_ = (function nonotes$core$save_event_BANG_(_){
if(cljs.core.truth_(confirm("Are you sure you want to save? Old data will be overwritten."))){
return nonotes.core.fs.writeFile(nonotes.core.current_notes_fp.call(null),nonotes.core.note_area.call(null),"utf8",(function (err){
if(cljs.core.truth_(err)){
return alert([cljs.core.str("Couldn't save! Error: "),cljs.core.str(err)].join(''));
} else {
return null;
}
}));
} else {
return null;
}
});
/**
 * Set Note input data
 */
nonotes.core.note_area_event_BANG_ = (function nonotes$core$note_area_event_BANG_(evt){
return nonotes.core.note_area_BANG_.call(null,evt);
});
nonotes.core.link = (function nonotes$core$link(href){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"a","a",-2123407586),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"href","href",-793805698),href,new cljs.core.Keyword(null,"target","target",253001721),"_blank"], null),href], null);
});
/**
 * The Only View
 */
nonotes.core.index = (function nonotes$core$index(){
var editor_QMARK_ = nonotes.core.toggle_editor.call(null);
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div.editor-toggle","div.editor-toggle",-942100808),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"position","position",-2011731912),new cljs.core.Keyword(null,"fixed","fixed",-562004358),new cljs.core.Keyword(null,"background-color","background-color",570434026),new cljs.core.Keyword(null,"#FFFFFF","#FFFFFF",1396815616),new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"100%","100%",2121014846),new cljs.core.Keyword(null,"height","height",1025178622),(cljs.core.truth_(editor_QMARK_)?new cljs.core.Keyword(null,"200px","200px",-386181901):new cljs.core.Keyword(null,"20px","20px",-778661343)),new cljs.core.Keyword(null,"z-index","z-index",1892827090),(10),new cljs.core.Keyword(null,"bottom","bottom",-1550509018),(cljs.core.truth_(editor_QMARK_)?new cljs.core.Keyword(null,"40px","40px",-1191086507):new cljs.core.Keyword(null,"15px","15px",-317910143))], null)], null),(cljs.core.truth_(editor_QMARK_)?null:new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"100%","100%",2121014846),new cljs.core.Keyword(null,"background","background",-863952629),new cljs.core.Keyword(null,"#FFFFFF","#FFFFFF",1396815616),new cljs.core.Keyword(null,"padding","padding",1660304693),new cljs.core.Keyword(null,"2px","2px",-1697779893)], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"100%","100%",2121014846)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.new_event_BANG_], null),"Open"], null)], null)),new cljs.core.PersistentVector(null, 10, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"visibility","visibility",1338380893),(cljs.core.truth_(editor_QMARK_)?"visible":"hidden")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"5%","5%",-1106511396)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.about_event_BANG_], null),"?"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"5%","5%",-1106511396)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.toggle_event_BANG_], null),"\u2716"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"25%","25%",-289627339)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.open_event_BANG_], null),"Open PDF"], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"25%","25%",-289627339)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.load_event_BANG_], null),"Load Notes"], null),(cljs.core.truth_(editor_QMARK_)?new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"a","a",-2123407586),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"href","href",-793805698),[cljs.core.str("file://"),cljs.core.str(nonotes.core.current_notes_fp.call(null))].join(''),new cljs.core.Keyword(null,"on-click","on-click",1632826543),((function (editor_QMARK_){
return (function (){
return alert("Warning: Anything unsaved will not be exported!");
});})(editor_QMARK_))
,new cljs.core.Keyword(null,"download","download",-300081668),goog.string.format("NoNotes - %s - %s.md",document.title,(new Date()))], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"25%","25%",-289627339)], null)], null),"Export Notes"], null)], null):null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"15%","15%",145016571)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.save_event_BANG_], null),"Save"], null),new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"max-height","max-height",-612563804),new cljs.core.Keyword(null,"text-align","text-align",1786091845),new cljs.core.Keyword(null,"overflow","overflow",2058931880),new cljs.core.Keyword(null,"background-color","background-color",570434026),new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"z-index","z-index",1892827090),new cljs.core.Keyword(null,"display","display",242065432),new cljs.core.Keyword(null,"position","position",-2011731912),new cljs.core.Keyword(null,"margin-bottom","margin-bottom",388334941),new cljs.core.Keyword(null,"height","height",1025178622)],[new cljs.core.Keyword(null,"200px","200px",-386181901),new cljs.core.Keyword(null,"center","center",-748944368),new cljs.core.Keyword(null,"auto","auto",-566279492),new cljs.core.Keyword(null,"white","white",-483998618),new cljs.core.Keyword(null,"100%","100%",2121014846),(20),(cljs.core.truth_(nonotes.core.toggle_about.call(null))?"block":"none"),new cljs.core.Keyword(null,"fixed","fixed",-562004358),new cljs.core.Keyword(null,"100px","100px",-860452660),new cljs.core.Keyword(null,"200px","200px",-386181901)])], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"button","button",1456579943),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"left","left",-399115937),new cljs.core.Keyword(null,"2px","2px",-1697779893),new cljs.core.Keyword(null,"bottom","bottom",-1550509018),(170),new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"10%","10%",-1282153063),new cljs.core.Keyword(null,"position","position",-2011731912),new cljs.core.Keyword(null,"fixed","fixed",-562004358)], null),new cljs.core.Keyword(null,"on-click","on-click",1632826543),nonotes.core.about_event_BANG_], null),"close"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"h1","h1",-1896887462),"About NoNotes"], null),"Ryan Kelker - 2016",new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"table.aboutTable","table.aboutTable",-1506887840),new cljs.core.PersistentVector(null, 8, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tbody","tbody",-80678300),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"Source Code via Github"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://www.github.com/runexec/NoNotes")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"Mozilla PDF.js via Github"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://mozilla.github.io/pdf.js/")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"Mozilla PDF.js License"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://github.com/mozilla/pdf.js/blob/master/LICENSE")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"Reagent via Github"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://reagent-project.github.io/")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"Reagent License"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://opensource.org/licenses/MIT")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"NW.js"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://nwjs.io/")], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),"NW.js License"], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),nonotes.core.link.call(null,"https://github.com/nwjs/nw.js/blob/nw17/LICENSE")], null)], null)], null)], null)], null),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"table","table",-564943036),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"100%","100%",2121014846)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tbody","tbody",-80678300),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"tr","tr",-1424774646),new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td","td",1479933353),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"50%","50%",2071665143)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"textarea#noteInput","textarea#noteInput",-794270840),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"value","value",305978217),nonotes.core.note_area.call(null),new cljs.core.Keyword(null,"onKeyPress","onKeyPress",1548576017),nonotes.core.scroll_preview_event_BANG_,new cljs.core.Keyword(null,"onChange","onChange",-312891301),nonotes.core.note_area_event_BANG_,new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"100%","100%",2121014846),new cljs.core.Keyword(null,"height","height",1025178622),new cljs.core.Keyword(null,"195px","195px",1648805529)], null)], null)], null)], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"td#htmlPreview.html-preview","td#htmlPreview.html-preview",2032592511),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"dangerouslySetInnerHTML","dangerouslySetInnerHTML",-554971138),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"__html","__html",674048345),nonotes.core.html_notes.call(null)], null),new cljs.core.Keyword(null,"style","style",-496642736),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"position","position",-2011731912),new cljs.core.Keyword(null,"absolute","absolute",1655386478),new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"50%","50%",2071665143),new cljs.core.Keyword(null,"height","height",1025178622),new cljs.core.Keyword(null,"195px","195px",1648805529),new cljs.core.Keyword(null,"overflow","overflow",2058931880),new cljs.core.Keyword(null,"scroll","scroll",971553779),new cljs.core.Keyword(null,"background","background",-863952629),new cljs.core.Keyword(null,"white","white",-483998618)], null)], null)], null)], null)], null)], null)], null)], null);
});
nonotes.core.mount_root = (function nonotes$core$mount_root(){
return reagent.core.render.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [nonotes.core.index], null),document.getElementById("app"));
});
nonotes.core.init_BANG_ = (function nonotes$core$init_BANG_(){
return nonotes.core.mount_root.call(null);
});
