// Compiled by ClojureScript 1.9.229 {}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var args11289 = [];
var len__7484__auto___11295 = arguments.length;
var i__7485__auto___11296 = (0);
while(true){
if((i__7485__auto___11296 < len__7484__auto___11295)){
args11289.push((arguments[i__7485__auto___11296]));

var G__11297 = (i__7485__auto___11296 + (1));
i__7485__auto___11296 = G__11297;
continue;
} else {
}
break;
}

var G__11291 = args11289.length;
switch (G__11291) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11289.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.call(null,f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if(typeof cljs.core.async.t_cljs$core$async11292 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async11292 = (function (f,blockable,meta11293){
this.f = f;
this.blockable = blockable;
this.meta11293 = meta11293;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_11294,meta11293__$1){
var self__ = this;
var _11294__$1 = this;
return (new cljs.core.async.t_cljs$core$async11292(self__.f,self__.blockable,meta11293__$1));
});

cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_11294){
var self__ = this;
var _11294__$1 = this;
return self__.meta11293;
});

cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async11292.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async11292.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"blockable","blockable",-28395259,null),new cljs.core.Symbol(null,"meta11293","meta11293",1760028218,null)], null);
});

cljs.core.async.t_cljs$core$async11292.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async11292.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async11292";

cljs.core.async.t_cljs$core$async11292.cljs$lang$ctorPrWriter = (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async11292");
});

cljs.core.async.__GT_t_cljs$core$async11292 = (function cljs$core$async$__GT_t_cljs$core$async11292(f__$1,blockable__$1,meta11293){
return (new cljs.core.async.t_cljs$core$async11292(f__$1,blockable__$1,meta11293));
});

}

return (new cljs.core.async.t_cljs$core$async11292(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;

/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer.call(null,n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if(!((buff == null))){
if((false) || (buff.cljs$core$async$impl$protocols$UnblockingBuffer$)){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var args11301 = [];
var len__7484__auto___11304 = arguments.length;
var i__7485__auto___11305 = (0);
while(true){
if((i__7485__auto___11305 < len__7484__auto___11304)){
args11301.push((arguments[i__7485__auto___11305]));

var G__11306 = (i__7485__auto___11305 + (1));
i__7485__auto___11305 = G__11306;
continue;
} else {
}
break;
}

var G__11303 = args11301.length;
switch (G__11303) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11301.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.call(null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.call(null,buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.call(null,buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.call(null,buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("buffer must be supplied when transducer is"),cljs.core.str("\n"),cljs.core.str("buf-or-n")].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.call(null,((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer.call(null,buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var args11308 = [];
var len__7484__auto___11311 = arguments.length;
var i__7485__auto___11312 = (0);
while(true){
if((i__7485__auto___11312 < len__7484__auto___11311)){
args11308.push((arguments[i__7485__auto___11312]));

var G__11313 = (i__7485__auto___11312 + (1));
i__7485__auto___11312 = G__11313;
continue;
} else {
}
break;
}

var G__11310 = args11308.length;
switch (G__11310) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11308.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.call(null,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.call(null,xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.call(null,cljs.core.async.impl.buffers.promise_buffer.call(null),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout.call(null,msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var args11315 = [];
var len__7484__auto___11318 = arguments.length;
var i__7485__auto___11319 = (0);
while(true){
if((i__7485__auto___11319 < len__7484__auto___11318)){
args11315.push((arguments[i__7485__auto___11319]));

var G__11320 = (i__7485__auto___11319 + (1));
i__7485__auto___11319 = G__11320;
continue;
} else {
}
break;
}

var G__11317 = args11315.length;
switch (G__11317) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11315.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.call(null,port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(ret)){
var val_11322 = cljs.core.deref.call(null,ret);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,val_11322);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (val_11322,ret){
return (function (){
return fn1.call(null,val_11322);
});})(val_11322,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;

cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.call(null,cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn0 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn0 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var args11323 = [];
var len__7484__auto___11326 = arguments.length;
var i__7485__auto___11327 = (0);
while(true){
if((i__7485__auto___11327 < len__7484__auto___11326)){
args11323.push((arguments[i__7485__auto___11327]));

var G__11328 = (i__7485__auto___11327 + (1));
i__7485__auto___11327 = G__11328;
continue;
} else {
}
break;
}

var G__11325 = args11323.length;
switch (G__11325) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11323.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__4655__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__4655__auto__)){
var ret = temp__4655__auto__;
return cljs.core.deref.call(null,ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.call(null,port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__4655__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(temp__4655__auto__)){
var retb = temp__4655__auto__;
var ret = cljs.core.deref.call(null,retb);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,ret);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (ret,retb,temp__4655__auto__){
return (function (){
return fn1.call(null,ret);
});})(ret,retb,temp__4655__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;

cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_.call(null,port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__7324__auto___11330 = n;
var x_11331 = (0);
while(true){
if((x_11331 < n__7324__auto___11330)){
(a[x_11331] = (0));

var G__11332 = (x_11331 + (1));
x_11331 = G__11332;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.call(null,i,n)){
return a;
} else {
var j = cljs.core.rand_int.call(null,i);
(a[i] = (a[j]));

(a[j] = i);

var G__11333 = (i + (1));
i = G__11333;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.call(null,true);
if(typeof cljs.core.async.t_cljs$core$async11337 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async11337 = (function (alt_flag,flag,meta11338){
this.alt_flag = alt_flag;
this.flag = flag;
this.meta11338 = meta11338;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_11339,meta11338__$1){
var self__ = this;
var _11339__$1 = this;
return (new cljs.core.async.t_cljs$core$async11337(self__.alt_flag,self__.flag,meta11338__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_11339){
var self__ = this;
var _11339__$1 = this;
return self__.meta11338;
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref.call(null,self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"alt-flag","alt-flag",-1794972754,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"private","private",-558947994),true,new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(cljs.core.PersistentVector.EMPTY))], null)),new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"meta11338","meta11338",1370202655,null)], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async11337.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async11337.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async11337";

cljs.core.async.t_cljs$core$async11337.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async11337");
});})(flag))
;

cljs.core.async.__GT_t_cljs$core$async11337 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async11337(alt_flag__$1,flag__$1,meta11338){
return (new cljs.core.async.t_cljs$core$async11337(alt_flag__$1,flag__$1,meta11338));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async11337(cljs$core$async$alt_flag,flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if(typeof cljs.core.async.t_cljs$core$async11343 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async11343 = (function (alt_handler,flag,cb,meta11344){
this.alt_handler = alt_handler;
this.flag = flag;
this.cb = cb;
this.meta11344 = meta11344;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_11345,meta11344__$1){
var self__ = this;
var _11345__$1 = this;
return (new cljs.core.async.t_cljs$core$async11343(self__.alt_handler,self__.flag,self__.cb,meta11344__$1));
});

cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_11345){
var self__ = this;
var _11345__$1 = this;
return self__.meta11344;
});

cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.flag);
});

cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async11343.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit.call(null,self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async11343.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"alt-handler","alt-handler",963786170,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"private","private",-558947994),true,new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null)], null)))], null)),new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null),new cljs.core.Symbol(null,"meta11344","meta11344",440691351,null)], null);
});

cljs.core.async.t_cljs$core$async11343.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async11343.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async11343";

cljs.core.async.t_cljs$core$async11343.cljs$lang$ctorPrWriter = (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async11343");
});

cljs.core.async.__GT_t_cljs$core$async11343 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async11343(alt_handler__$1,flag__$1,cb__$1,meta11344){
return (new cljs.core.async.t_cljs$core$async11343(alt_handler__$1,flag__$1,cb__$1,meta11344));
});

}

return (new cljs.core.async.t_cljs$core$async11343(cljs$core$async$alt_handler,flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag.call(null);
var n = cljs.core.count.call(null,ports);
var idxs = cljs.core.async.random_array.call(null,n);
var priority = new cljs.core.Keyword(null,"priority","priority",1431093715).cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.call(null,ports,idx);
var wport = ((cljs.core.vector_QMARK_.call(null,port))?port.call(null,(0)):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = port.call(null,(1));
return cljs.core.async.impl.protocols.put_BANG_.call(null,wport,val,cljs.core.async.alt_handler.call(null,flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__11346_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__11346_SHARP_,wport], null));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.alt_handler.call(null,flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__11347_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__11347_SHARP_,port], null));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref.call(null,vbox),(function (){var or__6409__auto__ = wport;
if(cljs.core.truth_(or__6409__auto__)){
return or__6409__auto__;
} else {
return port;
}
})()], null));
} else {
var G__11348 = (i + (1));
i = G__11348;
continue;
}
} else {
return null;
}
break;
}
})();
var or__6409__auto__ = ret;
if(cljs.core.truth_(or__6409__auto__)){
return or__6409__auto__;
} else {
if(cljs.core.contains_QMARK_.call(null,opts,new cljs.core.Keyword(null,"default","default",-1987822328))){
var temp__4657__auto__ = (function (){var and__6397__auto__ = cljs.core.async.impl.protocols.active_QMARK_.call(null,flag);
if(cljs.core.truth_(and__6397__auto__)){
return cljs.core.async.impl.protocols.commit.call(null,flag);
} else {
return and__6397__auto__;
}
})();
if(cljs.core.truth_(temp__4657__auto__)){
var got = temp__4657__auto__;
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"default","default",-1987822328).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"default","default",-1987822328)], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__7491__auto__ = [];
var len__7484__auto___11354 = arguments.length;
var i__7485__auto___11355 = (0);
while(true){
if((i__7485__auto___11355 < len__7484__auto___11354)){
args__7491__auto__.push((arguments[i__7485__auto___11355]));

var G__11356 = (i__7485__auto___11355 + (1));
i__7485__auto___11355 = G__11356;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((1) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((1)),(0),null)):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__7492__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__11351){
var map__11352 = p__11351;
var map__11352__$1 = ((((!((map__11352 == null)))?((((map__11352.cljs$lang$protocol_mask$partition0$ & (64))) || (map__11352.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__11352):map__11352);
var opts = map__11352__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq11349){
var G__11350 = cljs.core.first.call(null,seq11349);
var seq11349__$1 = cljs.core.next.call(null,seq11349);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__11350,seq11349__$1);
});

/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var args11357 = [];
var len__7484__auto___11407 = arguments.length;
var i__7485__auto___11408 = (0);
while(true){
if((i__7485__auto___11408 < len__7484__auto___11407)){
args11357.push((arguments[i__7485__auto___11408]));

var G__11409 = (i__7485__auto___11408 + (1));
i__7485__auto___11408 = G__11409;
continue;
} else {
}
break;
}

var G__11359 = args11357.length;
switch (G__11359) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11357.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.call(null,from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__11244__auto___11411 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___11411){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___11411){
return (function (state_11383){
var state_val_11384 = (state_11383[(1)]);
if((state_val_11384 === (7))){
var inst_11379 = (state_11383[(2)]);
var state_11383__$1 = state_11383;
var statearr_11385_11412 = state_11383__$1;
(statearr_11385_11412[(2)] = inst_11379);

(statearr_11385_11412[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (1))){
var state_11383__$1 = state_11383;
var statearr_11386_11413 = state_11383__$1;
(statearr_11386_11413[(2)] = null);

(statearr_11386_11413[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (4))){
var inst_11362 = (state_11383[(7)]);
var inst_11362__$1 = (state_11383[(2)]);
var inst_11363 = (inst_11362__$1 == null);
var state_11383__$1 = (function (){var statearr_11387 = state_11383;
(statearr_11387[(7)] = inst_11362__$1);

return statearr_11387;
})();
if(cljs.core.truth_(inst_11363)){
var statearr_11388_11414 = state_11383__$1;
(statearr_11388_11414[(1)] = (5));

} else {
var statearr_11389_11415 = state_11383__$1;
(statearr_11389_11415[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (13))){
var state_11383__$1 = state_11383;
var statearr_11390_11416 = state_11383__$1;
(statearr_11390_11416[(2)] = null);

(statearr_11390_11416[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (6))){
var inst_11362 = (state_11383[(7)]);
var state_11383__$1 = state_11383;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11383__$1,(11),to,inst_11362);
} else {
if((state_val_11384 === (3))){
var inst_11381 = (state_11383[(2)]);
var state_11383__$1 = state_11383;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11383__$1,inst_11381);
} else {
if((state_val_11384 === (12))){
var state_11383__$1 = state_11383;
var statearr_11391_11417 = state_11383__$1;
(statearr_11391_11417[(2)] = null);

(statearr_11391_11417[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (2))){
var state_11383__$1 = state_11383;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11383__$1,(4),from);
} else {
if((state_val_11384 === (11))){
var inst_11372 = (state_11383[(2)]);
var state_11383__$1 = state_11383;
if(cljs.core.truth_(inst_11372)){
var statearr_11392_11418 = state_11383__$1;
(statearr_11392_11418[(1)] = (12));

} else {
var statearr_11393_11419 = state_11383__$1;
(statearr_11393_11419[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (9))){
var state_11383__$1 = state_11383;
var statearr_11394_11420 = state_11383__$1;
(statearr_11394_11420[(2)] = null);

(statearr_11394_11420[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (5))){
var state_11383__$1 = state_11383;
if(cljs.core.truth_(close_QMARK_)){
var statearr_11395_11421 = state_11383__$1;
(statearr_11395_11421[(1)] = (8));

} else {
var statearr_11396_11422 = state_11383__$1;
(statearr_11396_11422[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (14))){
var inst_11377 = (state_11383[(2)]);
var state_11383__$1 = state_11383;
var statearr_11397_11423 = state_11383__$1;
(statearr_11397_11423[(2)] = inst_11377);

(statearr_11397_11423[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (10))){
var inst_11369 = (state_11383[(2)]);
var state_11383__$1 = state_11383;
var statearr_11398_11424 = state_11383__$1;
(statearr_11398_11424[(2)] = inst_11369);

(statearr_11398_11424[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11384 === (8))){
var inst_11366 = cljs.core.async.close_BANG_.call(null,to);
var state_11383__$1 = state_11383;
var statearr_11399_11425 = state_11383__$1;
(statearr_11399_11425[(2)] = inst_11366);

(statearr_11399_11425[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___11411))
;
return ((function (switch__11132__auto__,c__11244__auto___11411){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_11403 = [null,null,null,null,null,null,null,null];
(statearr_11403[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_11403[(1)] = (1));

return statearr_11403;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_11383){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11383);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11404){if((e11404 instanceof Object)){
var ex__11136__auto__ = e11404;
var statearr_11405_11426 = state_11383;
(statearr_11405_11426[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11383);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11404;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11427 = state_11383;
state_11383 = G__11427;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_11383){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_11383);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___11411))
})();
var state__11246__auto__ = (function (){var statearr_11406 = f__11245__auto__.call(null);
(statearr_11406[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11411);

return statearr_11406;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___11411))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;

cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error("Assert failed: (pos? n)"));
}

var jobs = cljs.core.async.chan.call(null,n);
var results = cljs.core.async.chan.call(null,n);
var process = ((function (jobs,results){
return (function (p__11615){
var vec__11616 = p__11615;
var v = cljs.core.nth.call(null,vec__11616,(0),null);
var p = cljs.core.nth.call(null,vec__11616,(1),null);
var job = vec__11616;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1),xf,ex_handler);
var c__11244__auto___11802 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results){
return (function (state_11623){
var state_val_11624 = (state_11623[(1)]);
if((state_val_11624 === (1))){
var state_11623__$1 = state_11623;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11623__$1,(2),res,v);
} else {
if((state_val_11624 === (2))){
var inst_11620 = (state_11623[(2)]);
var inst_11621 = cljs.core.async.close_BANG_.call(null,res);
var state_11623__$1 = (function (){var statearr_11625 = state_11623;
(statearr_11625[(7)] = inst_11620);

return statearr_11625;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11623__$1,inst_11621);
} else {
return null;
}
}
});})(c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results))
;
return ((function (switch__11132__auto__,c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_11629 = [null,null,null,null,null,null,null,null];
(statearr_11629[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__);

(statearr_11629[(1)] = (1));

return statearr_11629;
});
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1 = (function (state_11623){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11623);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11630){if((e11630 instanceof Object)){
var ex__11136__auto__ = e11630;
var statearr_11631_11803 = state_11623;
(statearr_11631_11803[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11623);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11630;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11804 = state_11623;
state_11623 = G__11804;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = function(state_11623){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1.call(this,state_11623);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results))
})();
var state__11246__auto__ = (function (){var statearr_11632 = f__11245__auto__.call(null);
(statearr_11632[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11802);

return statearr_11632;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___11802,res,vec__11616,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__11633){
var vec__11634 = p__11633;
var v = cljs.core.nth.call(null,vec__11634,(0),null);
var p = cljs.core.nth.call(null,vec__11634,(1),null);
var job = vec__11634;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1));
xf.call(null,v,res);

cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results,process))
;
var n__7324__auto___11805 = n;
var __11806 = (0);
while(true){
if((__11806 < n__7324__auto___11805)){
var G__11637_11807 = (((type instanceof cljs.core.Keyword))?type.fqn:null);
switch (G__11637_11807) {
case "compute":
var c__11244__auto___11809 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__11806,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (__11806,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function (state_11650){
var state_val_11651 = (state_11650[(1)]);
if((state_val_11651 === (1))){
var state_11650__$1 = state_11650;
var statearr_11652_11810 = state_11650__$1;
(statearr_11652_11810[(2)] = null);

(statearr_11652_11810[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11651 === (2))){
var state_11650__$1 = state_11650;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11650__$1,(4),jobs);
} else {
if((state_val_11651 === (3))){
var inst_11648 = (state_11650[(2)]);
var state_11650__$1 = state_11650;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11650__$1,inst_11648);
} else {
if((state_val_11651 === (4))){
var inst_11640 = (state_11650[(2)]);
var inst_11641 = process.call(null,inst_11640);
var state_11650__$1 = state_11650;
if(cljs.core.truth_(inst_11641)){
var statearr_11653_11811 = state_11650__$1;
(statearr_11653_11811[(1)] = (5));

} else {
var statearr_11654_11812 = state_11650__$1;
(statearr_11654_11812[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11651 === (5))){
var state_11650__$1 = state_11650;
var statearr_11655_11813 = state_11650__$1;
(statearr_11655_11813[(2)] = null);

(statearr_11655_11813[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11651 === (6))){
var state_11650__$1 = state_11650;
var statearr_11656_11814 = state_11650__$1;
(statearr_11656_11814[(2)] = null);

(statearr_11656_11814[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11651 === (7))){
var inst_11646 = (state_11650[(2)]);
var state_11650__$1 = state_11650;
var statearr_11657_11815 = state_11650__$1;
(statearr_11657_11815[(2)] = inst_11646);

(statearr_11657_11815[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__11806,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
;
return ((function (__11806,switch__11132__auto__,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_11661 = [null,null,null,null,null,null,null];
(statearr_11661[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__);

(statearr_11661[(1)] = (1));

return statearr_11661;
});
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1 = (function (state_11650){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11650);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11662){if((e11662 instanceof Object)){
var ex__11136__auto__ = e11662;
var statearr_11663_11816 = state_11650;
(statearr_11663_11816[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11650);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11662;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11817 = state_11650;
state_11650 = G__11817;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = function(state_11650){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1.call(this,state_11650);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__;
})()
;})(__11806,switch__11132__auto__,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
})();
var state__11246__auto__ = (function (){var statearr_11664 = f__11245__auto__.call(null);
(statearr_11664[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11809);

return statearr_11664;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(__11806,c__11244__auto___11809,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
);


break;
case "async":
var c__11244__auto___11818 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__11806,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (__11806,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function (state_11677){
var state_val_11678 = (state_11677[(1)]);
if((state_val_11678 === (1))){
var state_11677__$1 = state_11677;
var statearr_11679_11819 = state_11677__$1;
(statearr_11679_11819[(2)] = null);

(statearr_11679_11819[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11678 === (2))){
var state_11677__$1 = state_11677;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11677__$1,(4),jobs);
} else {
if((state_val_11678 === (3))){
var inst_11675 = (state_11677[(2)]);
var state_11677__$1 = state_11677;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11677__$1,inst_11675);
} else {
if((state_val_11678 === (4))){
var inst_11667 = (state_11677[(2)]);
var inst_11668 = async.call(null,inst_11667);
var state_11677__$1 = state_11677;
if(cljs.core.truth_(inst_11668)){
var statearr_11680_11820 = state_11677__$1;
(statearr_11680_11820[(1)] = (5));

} else {
var statearr_11681_11821 = state_11677__$1;
(statearr_11681_11821[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11678 === (5))){
var state_11677__$1 = state_11677;
var statearr_11682_11822 = state_11677__$1;
(statearr_11682_11822[(2)] = null);

(statearr_11682_11822[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11678 === (6))){
var state_11677__$1 = state_11677;
var statearr_11683_11823 = state_11677__$1;
(statearr_11683_11823[(2)] = null);

(statearr_11683_11823[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11678 === (7))){
var inst_11673 = (state_11677[(2)]);
var state_11677__$1 = state_11677;
var statearr_11684_11824 = state_11677__$1;
(statearr_11684_11824[(2)] = inst_11673);

(statearr_11684_11824[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__11806,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
;
return ((function (__11806,switch__11132__auto__,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_11688 = [null,null,null,null,null,null,null];
(statearr_11688[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__);

(statearr_11688[(1)] = (1));

return statearr_11688;
});
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1 = (function (state_11677){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11677);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11689){if((e11689 instanceof Object)){
var ex__11136__auto__ = e11689;
var statearr_11690_11825 = state_11677;
(statearr_11690_11825[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11677);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11689;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11826 = state_11677;
state_11677 = G__11826;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = function(state_11677){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1.call(this,state_11677);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__;
})()
;})(__11806,switch__11132__auto__,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
})();
var state__11246__auto__ = (function (){var statearr_11691 = f__11245__auto__.call(null);
(statearr_11691[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11818);

return statearr_11691;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(__11806,c__11244__auto___11818,G__11637_11807,n__7324__auto___11805,jobs,results,process,async))
);


break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(type)].join('')));

}

var G__11827 = (__11806 + (1));
__11806 = G__11827;
continue;
} else {
}
break;
}

var c__11244__auto___11828 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___11828,jobs,results,process,async){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___11828,jobs,results,process,async){
return (function (state_11713){
var state_val_11714 = (state_11713[(1)]);
if((state_val_11714 === (1))){
var state_11713__$1 = state_11713;
var statearr_11715_11829 = state_11713__$1;
(statearr_11715_11829[(2)] = null);

(statearr_11715_11829[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11714 === (2))){
var state_11713__$1 = state_11713;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11713__$1,(4),from);
} else {
if((state_val_11714 === (3))){
var inst_11711 = (state_11713[(2)]);
var state_11713__$1 = state_11713;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11713__$1,inst_11711);
} else {
if((state_val_11714 === (4))){
var inst_11694 = (state_11713[(7)]);
var inst_11694__$1 = (state_11713[(2)]);
var inst_11695 = (inst_11694__$1 == null);
var state_11713__$1 = (function (){var statearr_11716 = state_11713;
(statearr_11716[(7)] = inst_11694__$1);

return statearr_11716;
})();
if(cljs.core.truth_(inst_11695)){
var statearr_11717_11830 = state_11713__$1;
(statearr_11717_11830[(1)] = (5));

} else {
var statearr_11718_11831 = state_11713__$1;
(statearr_11718_11831[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11714 === (5))){
var inst_11697 = cljs.core.async.close_BANG_.call(null,jobs);
var state_11713__$1 = state_11713;
var statearr_11719_11832 = state_11713__$1;
(statearr_11719_11832[(2)] = inst_11697);

(statearr_11719_11832[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11714 === (6))){
var inst_11694 = (state_11713[(7)]);
var inst_11699 = (state_11713[(8)]);
var inst_11699__$1 = cljs.core.async.chan.call(null,(1));
var inst_11700 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_11701 = [inst_11694,inst_11699__$1];
var inst_11702 = (new cljs.core.PersistentVector(null,2,(5),inst_11700,inst_11701,null));
var state_11713__$1 = (function (){var statearr_11720 = state_11713;
(statearr_11720[(8)] = inst_11699__$1);

return statearr_11720;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11713__$1,(8),jobs,inst_11702);
} else {
if((state_val_11714 === (7))){
var inst_11709 = (state_11713[(2)]);
var state_11713__$1 = state_11713;
var statearr_11721_11833 = state_11713__$1;
(statearr_11721_11833[(2)] = inst_11709);

(statearr_11721_11833[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11714 === (8))){
var inst_11699 = (state_11713[(8)]);
var inst_11704 = (state_11713[(2)]);
var state_11713__$1 = (function (){var statearr_11722 = state_11713;
(statearr_11722[(9)] = inst_11704);

return statearr_11722;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11713__$1,(9),results,inst_11699);
} else {
if((state_val_11714 === (9))){
var inst_11706 = (state_11713[(2)]);
var state_11713__$1 = (function (){var statearr_11723 = state_11713;
(statearr_11723[(10)] = inst_11706);

return statearr_11723;
})();
var statearr_11724_11834 = state_11713__$1;
(statearr_11724_11834[(2)] = null);

(statearr_11724_11834[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___11828,jobs,results,process,async))
;
return ((function (switch__11132__auto__,c__11244__auto___11828,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_11728 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_11728[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__);

(statearr_11728[(1)] = (1));

return statearr_11728;
});
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1 = (function (state_11713){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11713);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11729){if((e11729 instanceof Object)){
var ex__11136__auto__ = e11729;
var statearr_11730_11835 = state_11713;
(statearr_11730_11835[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11713);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11729;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11836 = state_11713;
state_11713 = G__11836;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = function(state_11713){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1.call(this,state_11713);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___11828,jobs,results,process,async))
})();
var state__11246__auto__ = (function (){var statearr_11731 = f__11245__auto__.call(null);
(statearr_11731[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11828);

return statearr_11731;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___11828,jobs,results,process,async))
);


var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__,jobs,results,process,async){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__,jobs,results,process,async){
return (function (state_11769){
var state_val_11770 = (state_11769[(1)]);
if((state_val_11770 === (7))){
var inst_11765 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
var statearr_11771_11837 = state_11769__$1;
(statearr_11771_11837[(2)] = inst_11765);

(statearr_11771_11837[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (20))){
var state_11769__$1 = state_11769;
var statearr_11772_11838 = state_11769__$1;
(statearr_11772_11838[(2)] = null);

(statearr_11772_11838[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (1))){
var state_11769__$1 = state_11769;
var statearr_11773_11839 = state_11769__$1;
(statearr_11773_11839[(2)] = null);

(statearr_11773_11839[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (4))){
var inst_11734 = (state_11769[(7)]);
var inst_11734__$1 = (state_11769[(2)]);
var inst_11735 = (inst_11734__$1 == null);
var state_11769__$1 = (function (){var statearr_11774 = state_11769;
(statearr_11774[(7)] = inst_11734__$1);

return statearr_11774;
})();
if(cljs.core.truth_(inst_11735)){
var statearr_11775_11840 = state_11769__$1;
(statearr_11775_11840[(1)] = (5));

} else {
var statearr_11776_11841 = state_11769__$1;
(statearr_11776_11841[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (15))){
var inst_11747 = (state_11769[(8)]);
var state_11769__$1 = state_11769;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11769__$1,(18),to,inst_11747);
} else {
if((state_val_11770 === (21))){
var inst_11760 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
var statearr_11777_11842 = state_11769__$1;
(statearr_11777_11842[(2)] = inst_11760);

(statearr_11777_11842[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (13))){
var inst_11762 = (state_11769[(2)]);
var state_11769__$1 = (function (){var statearr_11778 = state_11769;
(statearr_11778[(9)] = inst_11762);

return statearr_11778;
})();
var statearr_11779_11843 = state_11769__$1;
(statearr_11779_11843[(2)] = null);

(statearr_11779_11843[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (6))){
var inst_11734 = (state_11769[(7)]);
var state_11769__$1 = state_11769;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11769__$1,(11),inst_11734);
} else {
if((state_val_11770 === (17))){
var inst_11755 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
if(cljs.core.truth_(inst_11755)){
var statearr_11780_11844 = state_11769__$1;
(statearr_11780_11844[(1)] = (19));

} else {
var statearr_11781_11845 = state_11769__$1;
(statearr_11781_11845[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (3))){
var inst_11767 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11769__$1,inst_11767);
} else {
if((state_val_11770 === (12))){
var inst_11744 = (state_11769[(10)]);
var state_11769__$1 = state_11769;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11769__$1,(14),inst_11744);
} else {
if((state_val_11770 === (2))){
var state_11769__$1 = state_11769;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11769__$1,(4),results);
} else {
if((state_val_11770 === (19))){
var state_11769__$1 = state_11769;
var statearr_11782_11846 = state_11769__$1;
(statearr_11782_11846[(2)] = null);

(statearr_11782_11846[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (11))){
var inst_11744 = (state_11769[(2)]);
var state_11769__$1 = (function (){var statearr_11783 = state_11769;
(statearr_11783[(10)] = inst_11744);

return statearr_11783;
})();
var statearr_11784_11847 = state_11769__$1;
(statearr_11784_11847[(2)] = null);

(statearr_11784_11847[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (9))){
var state_11769__$1 = state_11769;
var statearr_11785_11848 = state_11769__$1;
(statearr_11785_11848[(2)] = null);

(statearr_11785_11848[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (5))){
var state_11769__$1 = state_11769;
if(cljs.core.truth_(close_QMARK_)){
var statearr_11786_11849 = state_11769__$1;
(statearr_11786_11849[(1)] = (8));

} else {
var statearr_11787_11850 = state_11769__$1;
(statearr_11787_11850[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (14))){
var inst_11749 = (state_11769[(11)]);
var inst_11747 = (state_11769[(8)]);
var inst_11747__$1 = (state_11769[(2)]);
var inst_11748 = (inst_11747__$1 == null);
var inst_11749__$1 = cljs.core.not.call(null,inst_11748);
var state_11769__$1 = (function (){var statearr_11788 = state_11769;
(statearr_11788[(11)] = inst_11749__$1);

(statearr_11788[(8)] = inst_11747__$1);

return statearr_11788;
})();
if(inst_11749__$1){
var statearr_11789_11851 = state_11769__$1;
(statearr_11789_11851[(1)] = (15));

} else {
var statearr_11790_11852 = state_11769__$1;
(statearr_11790_11852[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (16))){
var inst_11749 = (state_11769[(11)]);
var state_11769__$1 = state_11769;
var statearr_11791_11853 = state_11769__$1;
(statearr_11791_11853[(2)] = inst_11749);

(statearr_11791_11853[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (10))){
var inst_11741 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
var statearr_11792_11854 = state_11769__$1;
(statearr_11792_11854[(2)] = inst_11741);

(statearr_11792_11854[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (18))){
var inst_11752 = (state_11769[(2)]);
var state_11769__$1 = state_11769;
var statearr_11793_11855 = state_11769__$1;
(statearr_11793_11855[(2)] = inst_11752);

(statearr_11793_11855[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11770 === (8))){
var inst_11738 = cljs.core.async.close_BANG_.call(null,to);
var state_11769__$1 = state_11769;
var statearr_11794_11856 = state_11769__$1;
(statearr_11794_11856[(2)] = inst_11738);

(statearr_11794_11856[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto__,jobs,results,process,async))
;
return ((function (switch__11132__auto__,c__11244__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_11798 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_11798[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__);

(statearr_11798[(1)] = (1));

return statearr_11798;
});
var cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1 = (function (state_11769){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11769);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11799){if((e11799 instanceof Object)){
var ex__11136__auto__ = e11799;
var statearr_11800_11857 = state_11769;
(statearr_11800_11857[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11769);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11799;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11858 = state_11769;
state_11769 = G__11858;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__ = function(state_11769){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1.call(this,state_11769);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__,jobs,results,process,async))
})();
var state__11246__auto__ = (function (){var statearr_11801 = f__11245__auto__.call(null);
(statearr_11801[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_11801;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__,jobs,results,process,async))
);

return c__11244__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var args11859 = [];
var len__7484__auto___11862 = arguments.length;
var i__7485__auto___11863 = (0);
while(true){
if((i__7485__auto___11863 < len__7484__auto___11862)){
args11859.push((arguments[i__7485__auto___11863]));

var G__11864 = (i__7485__auto___11863 + (1));
i__7485__auto___11863 = G__11864;
continue;
} else {
}
break;
}

var G__11861 = args11859.length;
switch (G__11861) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11859.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.call(null,n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_.call(null,n,to,af,from,close_QMARK_,null,new cljs.core.Keyword(null,"async","async",1050769601));
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;

/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var args11866 = [];
var len__7484__auto___11869 = arguments.length;
var i__7485__auto___11870 = (0);
while(true){
if((i__7485__auto___11870 < len__7484__auto___11869)){
args11866.push((arguments[i__7485__auto___11870]));

var G__11871 = (i__7485__auto___11870 + (1));
i__7485__auto___11870 = G__11871;
continue;
} else {
}
break;
}

var G__11868 = args11866.length;
switch (G__11868) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11866.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.call(null,n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.call(null,n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_.call(null,n,to,xf,from,close_QMARK_,ex_handler,new cljs.core.Keyword(null,"compute","compute",1555393130));
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;

/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var args11873 = [];
var len__7484__auto___11926 = arguments.length;
var i__7485__auto___11927 = (0);
while(true){
if((i__7485__auto___11927 < len__7484__auto___11926)){
args11873.push((arguments[i__7485__auto___11927]));

var G__11928 = (i__7485__auto___11927 + (1));
i__7485__auto___11927 = G__11928;
continue;
} else {
}
break;
}

var G__11875 = args11873.length;
switch (G__11875) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args11873.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.call(null,p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.call(null,t_buf_or_n);
var fc = cljs.core.async.chan.call(null,f_buf_or_n);
var c__11244__auto___11930 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___11930,tc,fc){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___11930,tc,fc){
return (function (state_11901){
var state_val_11902 = (state_11901[(1)]);
if((state_val_11902 === (7))){
var inst_11897 = (state_11901[(2)]);
var state_11901__$1 = state_11901;
var statearr_11903_11931 = state_11901__$1;
(statearr_11903_11931[(2)] = inst_11897);

(statearr_11903_11931[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (1))){
var state_11901__$1 = state_11901;
var statearr_11904_11932 = state_11901__$1;
(statearr_11904_11932[(2)] = null);

(statearr_11904_11932[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (4))){
var inst_11878 = (state_11901[(7)]);
var inst_11878__$1 = (state_11901[(2)]);
var inst_11879 = (inst_11878__$1 == null);
var state_11901__$1 = (function (){var statearr_11905 = state_11901;
(statearr_11905[(7)] = inst_11878__$1);

return statearr_11905;
})();
if(cljs.core.truth_(inst_11879)){
var statearr_11906_11933 = state_11901__$1;
(statearr_11906_11933[(1)] = (5));

} else {
var statearr_11907_11934 = state_11901__$1;
(statearr_11907_11934[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (13))){
var state_11901__$1 = state_11901;
var statearr_11908_11935 = state_11901__$1;
(statearr_11908_11935[(2)] = null);

(statearr_11908_11935[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (6))){
var inst_11878 = (state_11901[(7)]);
var inst_11884 = p.call(null,inst_11878);
var state_11901__$1 = state_11901;
if(cljs.core.truth_(inst_11884)){
var statearr_11909_11936 = state_11901__$1;
(statearr_11909_11936[(1)] = (9));

} else {
var statearr_11910_11937 = state_11901__$1;
(statearr_11910_11937[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (3))){
var inst_11899 = (state_11901[(2)]);
var state_11901__$1 = state_11901;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_11901__$1,inst_11899);
} else {
if((state_val_11902 === (12))){
var state_11901__$1 = state_11901;
var statearr_11911_11938 = state_11901__$1;
(statearr_11911_11938[(2)] = null);

(statearr_11911_11938[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (2))){
var state_11901__$1 = state_11901;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_11901__$1,(4),ch);
} else {
if((state_val_11902 === (11))){
var inst_11878 = (state_11901[(7)]);
var inst_11888 = (state_11901[(2)]);
var state_11901__$1 = state_11901;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_11901__$1,(8),inst_11888,inst_11878);
} else {
if((state_val_11902 === (9))){
var state_11901__$1 = state_11901;
var statearr_11912_11939 = state_11901__$1;
(statearr_11912_11939[(2)] = tc);

(statearr_11912_11939[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (5))){
var inst_11881 = cljs.core.async.close_BANG_.call(null,tc);
var inst_11882 = cljs.core.async.close_BANG_.call(null,fc);
var state_11901__$1 = (function (){var statearr_11913 = state_11901;
(statearr_11913[(8)] = inst_11881);

return statearr_11913;
})();
var statearr_11914_11940 = state_11901__$1;
(statearr_11914_11940[(2)] = inst_11882);

(statearr_11914_11940[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (14))){
var inst_11895 = (state_11901[(2)]);
var state_11901__$1 = state_11901;
var statearr_11915_11941 = state_11901__$1;
(statearr_11915_11941[(2)] = inst_11895);

(statearr_11915_11941[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (10))){
var state_11901__$1 = state_11901;
var statearr_11916_11942 = state_11901__$1;
(statearr_11916_11942[(2)] = fc);

(statearr_11916_11942[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_11902 === (8))){
var inst_11890 = (state_11901[(2)]);
var state_11901__$1 = state_11901;
if(cljs.core.truth_(inst_11890)){
var statearr_11917_11943 = state_11901__$1;
(statearr_11917_11943[(1)] = (12));

} else {
var statearr_11918_11944 = state_11901__$1;
(statearr_11918_11944[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___11930,tc,fc))
;
return ((function (switch__11132__auto__,c__11244__auto___11930,tc,fc){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_11922 = [null,null,null,null,null,null,null,null,null];
(statearr_11922[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_11922[(1)] = (1));

return statearr_11922;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_11901){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_11901);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e11923){if((e11923 instanceof Object)){
var ex__11136__auto__ = e11923;
var statearr_11924_11945 = state_11901;
(statearr_11924_11945[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_11901);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e11923;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__11946 = state_11901;
state_11901 = G__11946;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_11901){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_11901);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___11930,tc,fc))
})();
var state__11246__auto__ = (function (){var statearr_11925 = f__11245__auto__.call(null);
(statearr_11925[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___11930);

return statearr_11925;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___11930,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;

/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__){
return (function (state_12010){
var state_val_12011 = (state_12010[(1)]);
if((state_val_12011 === (7))){
var inst_12006 = (state_12010[(2)]);
var state_12010__$1 = state_12010;
var statearr_12012_12033 = state_12010__$1;
(statearr_12012_12033[(2)] = inst_12006);

(statearr_12012_12033[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (1))){
var inst_11990 = init;
var state_12010__$1 = (function (){var statearr_12013 = state_12010;
(statearr_12013[(7)] = inst_11990);

return statearr_12013;
})();
var statearr_12014_12034 = state_12010__$1;
(statearr_12014_12034[(2)] = null);

(statearr_12014_12034[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (4))){
var inst_11993 = (state_12010[(8)]);
var inst_11993__$1 = (state_12010[(2)]);
var inst_11994 = (inst_11993__$1 == null);
var state_12010__$1 = (function (){var statearr_12015 = state_12010;
(statearr_12015[(8)] = inst_11993__$1);

return statearr_12015;
})();
if(cljs.core.truth_(inst_11994)){
var statearr_12016_12035 = state_12010__$1;
(statearr_12016_12035[(1)] = (5));

} else {
var statearr_12017_12036 = state_12010__$1;
(statearr_12017_12036[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (6))){
var inst_11997 = (state_12010[(9)]);
var inst_11990 = (state_12010[(7)]);
var inst_11993 = (state_12010[(8)]);
var inst_11997__$1 = f.call(null,inst_11990,inst_11993);
var inst_11998 = cljs.core.reduced_QMARK_.call(null,inst_11997__$1);
var state_12010__$1 = (function (){var statearr_12018 = state_12010;
(statearr_12018[(9)] = inst_11997__$1);

return statearr_12018;
})();
if(inst_11998){
var statearr_12019_12037 = state_12010__$1;
(statearr_12019_12037[(1)] = (8));

} else {
var statearr_12020_12038 = state_12010__$1;
(statearr_12020_12038[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (3))){
var inst_12008 = (state_12010[(2)]);
var state_12010__$1 = state_12010;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_12010__$1,inst_12008);
} else {
if((state_val_12011 === (2))){
var state_12010__$1 = state_12010;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_12010__$1,(4),ch);
} else {
if((state_val_12011 === (9))){
var inst_11997 = (state_12010[(9)]);
var inst_11990 = inst_11997;
var state_12010__$1 = (function (){var statearr_12021 = state_12010;
(statearr_12021[(7)] = inst_11990);

return statearr_12021;
})();
var statearr_12022_12039 = state_12010__$1;
(statearr_12022_12039[(2)] = null);

(statearr_12022_12039[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (5))){
var inst_11990 = (state_12010[(7)]);
var state_12010__$1 = state_12010;
var statearr_12023_12040 = state_12010__$1;
(statearr_12023_12040[(2)] = inst_11990);

(statearr_12023_12040[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (10))){
var inst_12004 = (state_12010[(2)]);
var state_12010__$1 = state_12010;
var statearr_12024_12041 = state_12010__$1;
(statearr_12024_12041[(2)] = inst_12004);

(statearr_12024_12041[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12011 === (8))){
var inst_11997 = (state_12010[(9)]);
var inst_12000 = cljs.core.deref.call(null,inst_11997);
var state_12010__$1 = state_12010;
var statearr_12025_12042 = state_12010__$1;
(statearr_12025_12042[(2)] = inst_12000);

(statearr_12025_12042[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto__))
;
return ((function (switch__11132__auto__,c__11244__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__11133__auto__ = null;
var cljs$core$async$reduce_$_state_machine__11133__auto____0 = (function (){
var statearr_12029 = [null,null,null,null,null,null,null,null,null,null];
(statearr_12029[(0)] = cljs$core$async$reduce_$_state_machine__11133__auto__);

(statearr_12029[(1)] = (1));

return statearr_12029;
});
var cljs$core$async$reduce_$_state_machine__11133__auto____1 = (function (state_12010){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_12010);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e12030){if((e12030 instanceof Object)){
var ex__11136__auto__ = e12030;
var statearr_12031_12043 = state_12010;
(statearr_12031_12043[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_12010);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e12030;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__12044 = state_12010;
state_12010 = G__12044;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__11133__auto__ = function(state_12010){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__11133__auto____1.call(this,state_12010);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__11133__auto____0;
cljs$core$async$reduce_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__11133__auto____1;
return cljs$core$async$reduce_$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__))
})();
var state__11246__auto__ = (function (){var statearr_12032 = f__11245__auto__.call(null);
(statearr_12032[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_12032;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__))
);

return c__11244__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var args12045 = [];
var len__7484__auto___12097 = arguments.length;
var i__7485__auto___12098 = (0);
while(true){
if((i__7485__auto___12098 < len__7484__auto___12097)){
args12045.push((arguments[i__7485__auto___12098]));

var G__12099 = (i__7485__auto___12098 + (1));
i__7485__auto___12098 = G__12099;
continue;
} else {
}
break;
}

var G__12047 = args12045.length;
switch (G__12047) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args12045.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.call(null,ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__){
return (function (state_12072){
var state_val_12073 = (state_12072[(1)]);
if((state_val_12073 === (7))){
var inst_12054 = (state_12072[(2)]);
var state_12072__$1 = state_12072;
var statearr_12074_12101 = state_12072__$1;
(statearr_12074_12101[(2)] = inst_12054);

(statearr_12074_12101[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (1))){
var inst_12048 = cljs.core.seq.call(null,coll);
var inst_12049 = inst_12048;
var state_12072__$1 = (function (){var statearr_12075 = state_12072;
(statearr_12075[(7)] = inst_12049);

return statearr_12075;
})();
var statearr_12076_12102 = state_12072__$1;
(statearr_12076_12102[(2)] = null);

(statearr_12076_12102[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (4))){
var inst_12049 = (state_12072[(7)]);
var inst_12052 = cljs.core.first.call(null,inst_12049);
var state_12072__$1 = state_12072;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_12072__$1,(7),ch,inst_12052);
} else {
if((state_val_12073 === (13))){
var inst_12066 = (state_12072[(2)]);
var state_12072__$1 = state_12072;
var statearr_12077_12103 = state_12072__$1;
(statearr_12077_12103[(2)] = inst_12066);

(statearr_12077_12103[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (6))){
var inst_12057 = (state_12072[(2)]);
var state_12072__$1 = state_12072;
if(cljs.core.truth_(inst_12057)){
var statearr_12078_12104 = state_12072__$1;
(statearr_12078_12104[(1)] = (8));

} else {
var statearr_12079_12105 = state_12072__$1;
(statearr_12079_12105[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (3))){
var inst_12070 = (state_12072[(2)]);
var state_12072__$1 = state_12072;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_12072__$1,inst_12070);
} else {
if((state_val_12073 === (12))){
var state_12072__$1 = state_12072;
var statearr_12080_12106 = state_12072__$1;
(statearr_12080_12106[(2)] = null);

(statearr_12080_12106[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (2))){
var inst_12049 = (state_12072[(7)]);
var state_12072__$1 = state_12072;
if(cljs.core.truth_(inst_12049)){
var statearr_12081_12107 = state_12072__$1;
(statearr_12081_12107[(1)] = (4));

} else {
var statearr_12082_12108 = state_12072__$1;
(statearr_12082_12108[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (11))){
var inst_12063 = cljs.core.async.close_BANG_.call(null,ch);
var state_12072__$1 = state_12072;
var statearr_12083_12109 = state_12072__$1;
(statearr_12083_12109[(2)] = inst_12063);

(statearr_12083_12109[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (9))){
var state_12072__$1 = state_12072;
if(cljs.core.truth_(close_QMARK_)){
var statearr_12084_12110 = state_12072__$1;
(statearr_12084_12110[(1)] = (11));

} else {
var statearr_12085_12111 = state_12072__$1;
(statearr_12085_12111[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (5))){
var inst_12049 = (state_12072[(7)]);
var state_12072__$1 = state_12072;
var statearr_12086_12112 = state_12072__$1;
(statearr_12086_12112[(2)] = inst_12049);

(statearr_12086_12112[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (10))){
var inst_12068 = (state_12072[(2)]);
var state_12072__$1 = state_12072;
var statearr_12087_12113 = state_12072__$1;
(statearr_12087_12113[(2)] = inst_12068);

(statearr_12087_12113[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12073 === (8))){
var inst_12049 = (state_12072[(7)]);
var inst_12059 = cljs.core.next.call(null,inst_12049);
var inst_12049__$1 = inst_12059;
var state_12072__$1 = (function (){var statearr_12088 = state_12072;
(statearr_12088[(7)] = inst_12049__$1);

return statearr_12088;
})();
var statearr_12089_12114 = state_12072__$1;
(statearr_12089_12114[(2)] = null);

(statearr_12089_12114[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto__))
;
return ((function (switch__11132__auto__,c__11244__auto__){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_12093 = [null,null,null,null,null,null,null,null];
(statearr_12093[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_12093[(1)] = (1));

return statearr_12093;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_12072){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_12072);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e12094){if((e12094 instanceof Object)){
var ex__11136__auto__ = e12094;
var statearr_12095_12115 = state_12072;
(statearr_12095_12115[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_12072);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e12094;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__12116 = state_12072;
state_12072 = G__12116;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_12072){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_12072);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__))
})();
var state__11246__auto__ = (function (){var statearr_12096 = f__11245__auto__.call(null);
(statearr_12096[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_12096;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__))
);

return c__11244__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;

/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.call(null,cljs.core.bounded_count.call(null,(100),coll));
cljs.core.async.onto_chan.call(null,ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((!((_ == null))) && (!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__7072__auto__ = (((_ == null))?null:_);
var m__7073__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,_);
} else {
var m__7073__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,_);
} else {
throw cljs.core.missing_protocol.call(null,"Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((!((m == null))) && (!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,ch,close_QMARK_);
} else {
var m__7073__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,ch);
} else {
var m__7073__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m);
} else {
var m__7073__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async12342 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async12342 = (function (mult,ch,cs,meta12343){
this.mult = mult;
this.ch = ch;
this.cs = cs;
this.meta12343 = meta12343;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_12344,meta12343__$1){
var self__ = this;
var _12344__$1 = this;
return (new cljs.core.async.t_cljs$core$async12342(self__.mult,self__.ch,self__.cs,meta12343__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_12344){
var self__ = this;
var _12344__$1 = this;
return self__.meta12343;
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mult$ = true;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"mult","mult",-1187640995,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Creates and returns a mult(iple) of the supplied channel. Channels\n  containing copies of the channel can be created with 'tap', and\n  detached with 'untap'.\n\n  Each item is distributed to all taps in parallel and synchronously,\n  i.e. each tap must accept before the next item is distributed. Use\n  buffering/windowing to prevent slow taps from holding up the mult.\n\n  Items received when there are no taps get dropped.\n\n  If a tap puts to a closed channel, it will be removed from the mult."], null)),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"meta12343","meta12343",1758048643,null)], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async12342.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async12342.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async12342";

cljs.core.async.t_cljs$core$async12342.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async12342");
});})(cs))
;

cljs.core.async.__GT_t_cljs$core$async12342 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async12342(mult__$1,ch__$1,cs__$1,meta12343){
return (new cljs.core.async.t_cljs$core$async12342(mult__$1,ch__$1,cs__$1,meta12343));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async12342(cljs$core$async$mult,ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__11244__auto___12567 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___12567,cs,m,dchan,dctr,done){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___12567,cs,m,dchan,dctr,done){
return (function (state_12479){
var state_val_12480 = (state_12479[(1)]);
if((state_val_12480 === (7))){
var inst_12475 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12481_12568 = state_12479__$1;
(statearr_12481_12568[(2)] = inst_12475);

(statearr_12481_12568[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (20))){
var inst_12378 = (state_12479[(7)]);
var inst_12390 = cljs.core.first.call(null,inst_12378);
var inst_12391 = cljs.core.nth.call(null,inst_12390,(0),null);
var inst_12392 = cljs.core.nth.call(null,inst_12390,(1),null);
var state_12479__$1 = (function (){var statearr_12482 = state_12479;
(statearr_12482[(8)] = inst_12391);

return statearr_12482;
})();
if(cljs.core.truth_(inst_12392)){
var statearr_12483_12569 = state_12479__$1;
(statearr_12483_12569[(1)] = (22));

} else {
var statearr_12484_12570 = state_12479__$1;
(statearr_12484_12570[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (27))){
var inst_12427 = (state_12479[(9)]);
var inst_12347 = (state_12479[(10)]);
var inst_12420 = (state_12479[(11)]);
var inst_12422 = (state_12479[(12)]);
var inst_12427__$1 = cljs.core._nth.call(null,inst_12420,inst_12422);
var inst_12428 = cljs.core.async.put_BANG_.call(null,inst_12427__$1,inst_12347,done);
var state_12479__$1 = (function (){var statearr_12485 = state_12479;
(statearr_12485[(9)] = inst_12427__$1);

return statearr_12485;
})();
if(cljs.core.truth_(inst_12428)){
var statearr_12486_12571 = state_12479__$1;
(statearr_12486_12571[(1)] = (30));

} else {
var statearr_12487_12572 = state_12479__$1;
(statearr_12487_12572[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (1))){
var state_12479__$1 = state_12479;
var statearr_12488_12573 = state_12479__$1;
(statearr_12488_12573[(2)] = null);

(statearr_12488_12573[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (24))){
var inst_12378 = (state_12479[(7)]);
var inst_12397 = (state_12479[(2)]);
var inst_12398 = cljs.core.next.call(null,inst_12378);
var inst_12356 = inst_12398;
var inst_12357 = null;
var inst_12358 = (0);
var inst_12359 = (0);
var state_12479__$1 = (function (){var statearr_12489 = state_12479;
(statearr_12489[(13)] = inst_12356);

(statearr_12489[(14)] = inst_12397);

(statearr_12489[(15)] = inst_12358);

(statearr_12489[(16)] = inst_12357);

(statearr_12489[(17)] = inst_12359);

return statearr_12489;
})();
var statearr_12490_12574 = state_12479__$1;
(statearr_12490_12574[(2)] = null);

(statearr_12490_12574[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (39))){
var state_12479__$1 = state_12479;
var statearr_12494_12575 = state_12479__$1;
(statearr_12494_12575[(2)] = null);

(statearr_12494_12575[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (4))){
var inst_12347 = (state_12479[(10)]);
var inst_12347__$1 = (state_12479[(2)]);
var inst_12348 = (inst_12347__$1 == null);
var state_12479__$1 = (function (){var statearr_12495 = state_12479;
(statearr_12495[(10)] = inst_12347__$1);

return statearr_12495;
})();
if(cljs.core.truth_(inst_12348)){
var statearr_12496_12576 = state_12479__$1;
(statearr_12496_12576[(1)] = (5));

} else {
var statearr_12497_12577 = state_12479__$1;
(statearr_12497_12577[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (15))){
var inst_12356 = (state_12479[(13)]);
var inst_12358 = (state_12479[(15)]);
var inst_12357 = (state_12479[(16)]);
var inst_12359 = (state_12479[(17)]);
var inst_12374 = (state_12479[(2)]);
var inst_12375 = (inst_12359 + (1));
var tmp12491 = inst_12356;
var tmp12492 = inst_12358;
var tmp12493 = inst_12357;
var inst_12356__$1 = tmp12491;
var inst_12357__$1 = tmp12493;
var inst_12358__$1 = tmp12492;
var inst_12359__$1 = inst_12375;
var state_12479__$1 = (function (){var statearr_12498 = state_12479;
(statearr_12498[(13)] = inst_12356__$1);

(statearr_12498[(18)] = inst_12374);

(statearr_12498[(15)] = inst_12358__$1);

(statearr_12498[(16)] = inst_12357__$1);

(statearr_12498[(17)] = inst_12359__$1);

return statearr_12498;
})();
var statearr_12499_12578 = state_12479__$1;
(statearr_12499_12578[(2)] = null);

(statearr_12499_12578[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (21))){
var inst_12401 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12503_12579 = state_12479__$1;
(statearr_12503_12579[(2)] = inst_12401);

(statearr_12503_12579[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (31))){
var inst_12427 = (state_12479[(9)]);
var inst_12431 = done.call(null,null);
var inst_12432 = cljs.core.async.untap_STAR_.call(null,m,inst_12427);
var state_12479__$1 = (function (){var statearr_12504 = state_12479;
(statearr_12504[(19)] = inst_12431);

return statearr_12504;
})();
var statearr_12505_12580 = state_12479__$1;
(statearr_12505_12580[(2)] = inst_12432);

(statearr_12505_12580[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (32))){
var inst_12419 = (state_12479[(20)]);
var inst_12421 = (state_12479[(21)]);
var inst_12420 = (state_12479[(11)]);
var inst_12422 = (state_12479[(12)]);
var inst_12434 = (state_12479[(2)]);
var inst_12435 = (inst_12422 + (1));
var tmp12500 = inst_12419;
var tmp12501 = inst_12421;
var tmp12502 = inst_12420;
var inst_12419__$1 = tmp12500;
var inst_12420__$1 = tmp12502;
var inst_12421__$1 = tmp12501;
var inst_12422__$1 = inst_12435;
var state_12479__$1 = (function (){var statearr_12506 = state_12479;
(statearr_12506[(20)] = inst_12419__$1);

(statearr_12506[(21)] = inst_12421__$1);

(statearr_12506[(22)] = inst_12434);

(statearr_12506[(11)] = inst_12420__$1);

(statearr_12506[(12)] = inst_12422__$1);

return statearr_12506;
})();
var statearr_12507_12581 = state_12479__$1;
(statearr_12507_12581[(2)] = null);

(statearr_12507_12581[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (40))){
var inst_12447 = (state_12479[(23)]);
var inst_12451 = done.call(null,null);
var inst_12452 = cljs.core.async.untap_STAR_.call(null,m,inst_12447);
var state_12479__$1 = (function (){var statearr_12508 = state_12479;
(statearr_12508[(24)] = inst_12451);

return statearr_12508;
})();
var statearr_12509_12582 = state_12479__$1;
(statearr_12509_12582[(2)] = inst_12452);

(statearr_12509_12582[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (33))){
var inst_12438 = (state_12479[(25)]);
var inst_12440 = cljs.core.chunked_seq_QMARK_.call(null,inst_12438);
var state_12479__$1 = state_12479;
if(inst_12440){
var statearr_12510_12583 = state_12479__$1;
(statearr_12510_12583[(1)] = (36));

} else {
var statearr_12511_12584 = state_12479__$1;
(statearr_12511_12584[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (13))){
var inst_12368 = (state_12479[(26)]);
var inst_12371 = cljs.core.async.close_BANG_.call(null,inst_12368);
var state_12479__$1 = state_12479;
var statearr_12512_12585 = state_12479__$1;
(statearr_12512_12585[(2)] = inst_12371);

(statearr_12512_12585[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (22))){
var inst_12391 = (state_12479[(8)]);
var inst_12394 = cljs.core.async.close_BANG_.call(null,inst_12391);
var state_12479__$1 = state_12479;
var statearr_12513_12586 = state_12479__$1;
(statearr_12513_12586[(2)] = inst_12394);

(statearr_12513_12586[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (36))){
var inst_12438 = (state_12479[(25)]);
var inst_12442 = cljs.core.chunk_first.call(null,inst_12438);
var inst_12443 = cljs.core.chunk_rest.call(null,inst_12438);
var inst_12444 = cljs.core.count.call(null,inst_12442);
var inst_12419 = inst_12443;
var inst_12420 = inst_12442;
var inst_12421 = inst_12444;
var inst_12422 = (0);
var state_12479__$1 = (function (){var statearr_12514 = state_12479;
(statearr_12514[(20)] = inst_12419);

(statearr_12514[(21)] = inst_12421);

(statearr_12514[(11)] = inst_12420);

(statearr_12514[(12)] = inst_12422);

return statearr_12514;
})();
var statearr_12515_12587 = state_12479__$1;
(statearr_12515_12587[(2)] = null);

(statearr_12515_12587[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (41))){
var inst_12438 = (state_12479[(25)]);
var inst_12454 = (state_12479[(2)]);
var inst_12455 = cljs.core.next.call(null,inst_12438);
var inst_12419 = inst_12455;
var inst_12420 = null;
var inst_12421 = (0);
var inst_12422 = (0);
var state_12479__$1 = (function (){var statearr_12516 = state_12479;
(statearr_12516[(20)] = inst_12419);

(statearr_12516[(21)] = inst_12421);

(statearr_12516[(27)] = inst_12454);

(statearr_12516[(11)] = inst_12420);

(statearr_12516[(12)] = inst_12422);

return statearr_12516;
})();
var statearr_12517_12588 = state_12479__$1;
(statearr_12517_12588[(2)] = null);

(statearr_12517_12588[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (43))){
var state_12479__$1 = state_12479;
var statearr_12518_12589 = state_12479__$1;
(statearr_12518_12589[(2)] = null);

(statearr_12518_12589[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (29))){
var inst_12463 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12519_12590 = state_12479__$1;
(statearr_12519_12590[(2)] = inst_12463);

(statearr_12519_12590[(1)] = (26));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (44))){
var inst_12472 = (state_12479[(2)]);
var state_12479__$1 = (function (){var statearr_12520 = state_12479;
(statearr_12520[(28)] = inst_12472);

return statearr_12520;
})();
var statearr_12521_12591 = state_12479__$1;
(statearr_12521_12591[(2)] = null);

(statearr_12521_12591[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (6))){
var inst_12411 = (state_12479[(29)]);
var inst_12410 = cljs.core.deref.call(null,cs);
var inst_12411__$1 = cljs.core.keys.call(null,inst_12410);
var inst_12412 = cljs.core.count.call(null,inst_12411__$1);
var inst_12413 = cljs.core.reset_BANG_.call(null,dctr,inst_12412);
var inst_12418 = cljs.core.seq.call(null,inst_12411__$1);
var inst_12419 = inst_12418;
var inst_12420 = null;
var inst_12421 = (0);
var inst_12422 = (0);
var state_12479__$1 = (function (){var statearr_12522 = state_12479;
(statearr_12522[(20)] = inst_12419);

(statearr_12522[(21)] = inst_12421);

(statearr_12522[(30)] = inst_12413);

(statearr_12522[(11)] = inst_12420);

(statearr_12522[(29)] = inst_12411__$1);

(statearr_12522[(12)] = inst_12422);

return statearr_12522;
})();
var statearr_12523_12592 = state_12479__$1;
(statearr_12523_12592[(2)] = null);

(statearr_12523_12592[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (28))){
var inst_12419 = (state_12479[(20)]);
var inst_12438 = (state_12479[(25)]);
var inst_12438__$1 = cljs.core.seq.call(null,inst_12419);
var state_12479__$1 = (function (){var statearr_12524 = state_12479;
(statearr_12524[(25)] = inst_12438__$1);

return statearr_12524;
})();
if(inst_12438__$1){
var statearr_12525_12593 = state_12479__$1;
(statearr_12525_12593[(1)] = (33));

} else {
var statearr_12526_12594 = state_12479__$1;
(statearr_12526_12594[(1)] = (34));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (25))){
var inst_12421 = (state_12479[(21)]);
var inst_12422 = (state_12479[(12)]);
var inst_12424 = (inst_12422 < inst_12421);
var inst_12425 = inst_12424;
var state_12479__$1 = state_12479;
if(cljs.core.truth_(inst_12425)){
var statearr_12527_12595 = state_12479__$1;
(statearr_12527_12595[(1)] = (27));

} else {
var statearr_12528_12596 = state_12479__$1;
(statearr_12528_12596[(1)] = (28));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (34))){
var state_12479__$1 = state_12479;
var statearr_12529_12597 = state_12479__$1;
(statearr_12529_12597[(2)] = null);

(statearr_12529_12597[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (17))){
var state_12479__$1 = state_12479;
var statearr_12530_12598 = state_12479__$1;
(statearr_12530_12598[(2)] = null);

(statearr_12530_12598[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (3))){
var inst_12477 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_12479__$1,inst_12477);
} else {
if((state_val_12480 === (12))){
var inst_12406 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12531_12599 = state_12479__$1;
(statearr_12531_12599[(2)] = inst_12406);

(statearr_12531_12599[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (2))){
var state_12479__$1 = state_12479;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_12479__$1,(4),ch);
} else {
if((state_val_12480 === (23))){
var state_12479__$1 = state_12479;
var statearr_12532_12600 = state_12479__$1;
(statearr_12532_12600[(2)] = null);

(statearr_12532_12600[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (35))){
var inst_12461 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12533_12601 = state_12479__$1;
(statearr_12533_12601[(2)] = inst_12461);

(statearr_12533_12601[(1)] = (29));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (19))){
var inst_12378 = (state_12479[(7)]);
var inst_12382 = cljs.core.chunk_first.call(null,inst_12378);
var inst_12383 = cljs.core.chunk_rest.call(null,inst_12378);
var inst_12384 = cljs.core.count.call(null,inst_12382);
var inst_12356 = inst_12383;
var inst_12357 = inst_12382;
var inst_12358 = inst_12384;
var inst_12359 = (0);
var state_12479__$1 = (function (){var statearr_12534 = state_12479;
(statearr_12534[(13)] = inst_12356);

(statearr_12534[(15)] = inst_12358);

(statearr_12534[(16)] = inst_12357);

(statearr_12534[(17)] = inst_12359);

return statearr_12534;
})();
var statearr_12535_12602 = state_12479__$1;
(statearr_12535_12602[(2)] = null);

(statearr_12535_12602[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (11))){
var inst_12356 = (state_12479[(13)]);
var inst_12378 = (state_12479[(7)]);
var inst_12378__$1 = cljs.core.seq.call(null,inst_12356);
var state_12479__$1 = (function (){var statearr_12536 = state_12479;
(statearr_12536[(7)] = inst_12378__$1);

return statearr_12536;
})();
if(inst_12378__$1){
var statearr_12537_12603 = state_12479__$1;
(statearr_12537_12603[(1)] = (16));

} else {
var statearr_12538_12604 = state_12479__$1;
(statearr_12538_12604[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (9))){
var inst_12408 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12539_12605 = state_12479__$1;
(statearr_12539_12605[(2)] = inst_12408);

(statearr_12539_12605[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (5))){
var inst_12354 = cljs.core.deref.call(null,cs);
var inst_12355 = cljs.core.seq.call(null,inst_12354);
var inst_12356 = inst_12355;
var inst_12357 = null;
var inst_12358 = (0);
var inst_12359 = (0);
var state_12479__$1 = (function (){var statearr_12540 = state_12479;
(statearr_12540[(13)] = inst_12356);

(statearr_12540[(15)] = inst_12358);

(statearr_12540[(16)] = inst_12357);

(statearr_12540[(17)] = inst_12359);

return statearr_12540;
})();
var statearr_12541_12606 = state_12479__$1;
(statearr_12541_12606[(2)] = null);

(statearr_12541_12606[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (14))){
var state_12479__$1 = state_12479;
var statearr_12542_12607 = state_12479__$1;
(statearr_12542_12607[(2)] = null);

(statearr_12542_12607[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (45))){
var inst_12469 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12543_12608 = state_12479__$1;
(statearr_12543_12608[(2)] = inst_12469);

(statearr_12543_12608[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (26))){
var inst_12411 = (state_12479[(29)]);
var inst_12465 = (state_12479[(2)]);
var inst_12466 = cljs.core.seq.call(null,inst_12411);
var state_12479__$1 = (function (){var statearr_12544 = state_12479;
(statearr_12544[(31)] = inst_12465);

return statearr_12544;
})();
if(inst_12466){
var statearr_12545_12609 = state_12479__$1;
(statearr_12545_12609[(1)] = (42));

} else {
var statearr_12546_12610 = state_12479__$1;
(statearr_12546_12610[(1)] = (43));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (16))){
var inst_12378 = (state_12479[(7)]);
var inst_12380 = cljs.core.chunked_seq_QMARK_.call(null,inst_12378);
var state_12479__$1 = state_12479;
if(inst_12380){
var statearr_12547_12611 = state_12479__$1;
(statearr_12547_12611[(1)] = (19));

} else {
var statearr_12548_12612 = state_12479__$1;
(statearr_12548_12612[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (38))){
var inst_12458 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12549_12613 = state_12479__$1;
(statearr_12549_12613[(2)] = inst_12458);

(statearr_12549_12613[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (30))){
var state_12479__$1 = state_12479;
var statearr_12550_12614 = state_12479__$1;
(statearr_12550_12614[(2)] = null);

(statearr_12550_12614[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (10))){
var inst_12357 = (state_12479[(16)]);
var inst_12359 = (state_12479[(17)]);
var inst_12367 = cljs.core._nth.call(null,inst_12357,inst_12359);
var inst_12368 = cljs.core.nth.call(null,inst_12367,(0),null);
var inst_12369 = cljs.core.nth.call(null,inst_12367,(1),null);
var state_12479__$1 = (function (){var statearr_12551 = state_12479;
(statearr_12551[(26)] = inst_12368);

return statearr_12551;
})();
if(cljs.core.truth_(inst_12369)){
var statearr_12552_12615 = state_12479__$1;
(statearr_12552_12615[(1)] = (13));

} else {
var statearr_12553_12616 = state_12479__$1;
(statearr_12553_12616[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (18))){
var inst_12404 = (state_12479[(2)]);
var state_12479__$1 = state_12479;
var statearr_12554_12617 = state_12479__$1;
(statearr_12554_12617[(2)] = inst_12404);

(statearr_12554_12617[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (42))){
var state_12479__$1 = state_12479;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_12479__$1,(45),dchan);
} else {
if((state_val_12480 === (37))){
var inst_12447 = (state_12479[(23)]);
var inst_12347 = (state_12479[(10)]);
var inst_12438 = (state_12479[(25)]);
var inst_12447__$1 = cljs.core.first.call(null,inst_12438);
var inst_12448 = cljs.core.async.put_BANG_.call(null,inst_12447__$1,inst_12347,done);
var state_12479__$1 = (function (){var statearr_12555 = state_12479;
(statearr_12555[(23)] = inst_12447__$1);

return statearr_12555;
})();
if(cljs.core.truth_(inst_12448)){
var statearr_12556_12618 = state_12479__$1;
(statearr_12556_12618[(1)] = (39));

} else {
var statearr_12557_12619 = state_12479__$1;
(statearr_12557_12619[(1)] = (40));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12480 === (8))){
var inst_12358 = (state_12479[(15)]);
var inst_12359 = (state_12479[(17)]);
var inst_12361 = (inst_12359 < inst_12358);
var inst_12362 = inst_12361;
var state_12479__$1 = state_12479;
if(cljs.core.truth_(inst_12362)){
var statearr_12558_12620 = state_12479__$1;
(statearr_12558_12620[(1)] = (10));

} else {
var statearr_12559_12621 = state_12479__$1;
(statearr_12559_12621[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___12567,cs,m,dchan,dctr,done))
;
return ((function (switch__11132__auto__,c__11244__auto___12567,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__11133__auto__ = null;
var cljs$core$async$mult_$_state_machine__11133__auto____0 = (function (){
var statearr_12563 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_12563[(0)] = cljs$core$async$mult_$_state_machine__11133__auto__);

(statearr_12563[(1)] = (1));

return statearr_12563;
});
var cljs$core$async$mult_$_state_machine__11133__auto____1 = (function (state_12479){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_12479);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e12564){if((e12564 instanceof Object)){
var ex__11136__auto__ = e12564;
var statearr_12565_12622 = state_12479;
(statearr_12565_12622[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_12479);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e12564;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__12623 = state_12479;
state_12479 = G__12623;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__11133__auto__ = function(state_12479){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__11133__auto____1.call(this,state_12479);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__11133__auto____0;
cljs$core$async$mult_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__11133__auto____1;
return cljs$core$async$mult_$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___12567,cs,m,dchan,dctr,done))
})();
var state__11246__auto__ = (function (){var statearr_12566 = f__11245__auto__.call(null);
(statearr_12566[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___12567);

return statearr_12566;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___12567,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var args12624 = [];
var len__7484__auto___12627 = arguments.length;
var i__7485__auto___12628 = (0);
while(true){
if((i__7485__auto___12628 < len__7484__auto___12627)){
args12624.push((arguments[i__7485__auto___12628]));

var G__12629 = (i__7485__auto___12628 + (1));
i__7485__auto___12628 = G__12629;
continue;
} else {
}
break;
}

var G__12626 = args12624.length;
switch (G__12626) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args12624.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.call(null,mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_.call(null,mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;

/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_.call(null,mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_.call(null,mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,ch);
} else {
var m__7073__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,ch);
} else {
var m__7073__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m);
} else {
var m__7073__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((!((m == null))) && (!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,state_map);
} else {
var m__7073__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,state_map);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((!((m == null))) && (!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__7072__auto__ = (((m == null))?null:m);
var m__7073__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,m,mode);
} else {
var m__7073__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,m,mode);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__7491__auto__ = [];
var len__7484__auto___12641 = arguments.length;
var i__7485__auto___12642 = (0);
while(true){
if((i__7485__auto___12642 < len__7484__auto___12641)){
args__7491__auto__.push((arguments[i__7485__auto___12642]));

var G__12643 = (i__7485__auto___12642 + (1));
i__7485__auto___12642 = G__12643;
continue;
} else {
}
break;
}

var argseq__7492__auto__ = ((((3) < args__7491__auto__.length))?(new cljs.core.IndexedSeq(args__7491__auto__.slice((3)),(0),null)):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__7492__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__12635){
var map__12636 = p__12635;
var map__12636__$1 = ((((!((map__12636 == null)))?((((map__12636.cljs$lang$protocol_mask$partition0$ & (64))) || (map__12636.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__12636):map__12636);
var opts = map__12636__$1;
var statearr_12638_12644 = state;
(statearr_12638_12644[cljs.core.async.impl.ioc_helpers.STATE_IDX] = cont_block);


var temp__4657__auto__ = cljs.core.async.do_alts.call(null,((function (map__12636,map__12636__$1,opts){
return (function (val){
var statearr_12639_12645 = state;
(statearr_12639_12645[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state);
});})(map__12636,map__12636__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__4657__auto__)){
var cb = temp__4657__auto__;
var statearr_12640_12646 = state;
(statearr_12640_12646[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = cljs.core.deref.call(null,cb));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq12631){
var G__12632 = cljs.core.first.call(null,seq12631);
var seq12631__$1 = cljs.core.next.call(null,seq12631);
var G__12633 = cljs.core.first.call(null,seq12631__$1);
var seq12631__$2 = cljs.core.next.call(null,seq12631__$1);
var G__12634 = cljs.core.first.call(null,seq12631__$2);
var seq12631__$3 = cljs.core.next.call(null,seq12631__$2);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__12632,G__12633,G__12634,seq12631__$3);
});

/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pause","pause",-2095325672),null,new cljs.core.Keyword(null,"mute","mute",1151223646),null], null), null);
var attrs = cljs.core.conj.call(null,solo_modes,new cljs.core.Keyword(null,"solo","solo",-316350075));
var solo_mode = cljs.core.atom.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646));
var change = cljs.core.async.chan.call(null);
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.call(null,change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv.call(null,((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_(attr.call(null,v))){
return cljs.core.conj.call(null,ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref.call(null,cs);
var mode = cljs.core.deref.call(null,solo_mode);
var solos = pick.call(null,new cljs.core.Keyword(null,"solo","solo",-316350075),chs);
var pauses = pick.call(null,new cljs.core.Keyword(null,"pause","pause",-2095325672),chs);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"solos","solos",1441458643),solos,new cljs.core.Keyword(null,"mutes","mutes",1068806309),pick.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646),chs),new cljs.core.Keyword(null,"reads","reads",-1215067361),cljs.core.conj.call(null,(((cljs.core._EQ_.call(null,mode,new cljs.core.Keyword(null,"pause","pause",-2095325672))) && (!(cljs.core.empty_QMARK_.call(null,solos))))?cljs.core.vec.call(null,solos):cljs.core.vec.call(null,cljs.core.remove.call(null,pauses,cljs.core.keys.call(null,chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async12812 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async12812 = (function (change,mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta12813){
this.change = change;
this.mix = mix;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta12813 = meta12813;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_12814,meta12813__$1){
var self__ = this;
var _12814__$1 = this;
return (new cljs.core.async.t_cljs$core$async12812(self__.change,self__.mix,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta12813__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_12814){
var self__ = this;
var _12814__$1 = this;
return self__.meta12813;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$ = true;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.partial.call(null,cljs.core.merge_with,cljs.core.merge),state_map);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.solo_modes.call(null,mode))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str([cljs.core.str("mode must be one of: "),cljs.core.str(self__.solo_modes)].join('')),cljs.core.str("\n"),cljs.core.str("(solo-modes mode)")].join('')));
}

cljs.core.reset_BANG_.call(null,self__.solo_mode,mode);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 11, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"change","change",477485025,null),cljs.core.with_meta(new cljs.core.Symbol(null,"mix","mix",2121373763,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"out","out",729986010,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Creates and returns a mix of one or more input channels which will\n  be put on the supplied out channel. Input sources can be added to\n  the mix with 'admix', and removed with 'unmix'. A mix supports\n  soloing, muting and pausing multiple inputs atomically using\n  'toggle', and can solo using either muting or pausing as determined\n  by 'solo-mode'.\n\n  Each channel can have zero or more boolean modes set via 'toggle':\n\n  :solo - when true, only this (ond other soloed) channel(s) will appear\n          in the mix output channel. :mute and :pause states of soloed\n          channels are ignored. If solo-mode is :mute, non-soloed\n          channels are muted, if :pause, non-soloed channels are\n          paused.\n\n  :mute - muted channels will have their contents consumed but not included in the mix\n  :pause - paused channels will not have their contents consumed (and thus also not included in the mix)\n"], null)),new cljs.core.Symbol(null,"solo-mode","solo-mode",2031788074,null),new cljs.core.Symbol(null,"pick","pick",1300068175,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"calc-state","calc-state",-349968968,null),new cljs.core.Symbol(null,"out","out",729986010,null),new cljs.core.Symbol(null,"changed","changed",-2083710852,null),new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"attrs","attrs",-450137186,null),new cljs.core.Symbol(null,"meta12813","meta12813",-170506062,null)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async12812.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async12812.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async12812";

cljs.core.async.t_cljs$core$async12812.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async12812");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.__GT_t_cljs$core$async12812 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async12812(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta12813){
return (new cljs.core.async.t_cljs$core$async12812(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta12813));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async12812(change,cljs$core$async$mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__11244__auto___12977 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_12914){
var state_val_12915 = (state_12914[(1)]);
if((state_val_12915 === (7))){
var inst_12830 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
var statearr_12916_12978 = state_12914__$1;
(statearr_12916_12978[(2)] = inst_12830);

(statearr_12916_12978[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (20))){
var inst_12842 = (state_12914[(7)]);
var state_12914__$1 = state_12914;
var statearr_12917_12979 = state_12914__$1;
(statearr_12917_12979[(2)] = inst_12842);

(statearr_12917_12979[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (27))){
var state_12914__$1 = state_12914;
var statearr_12918_12980 = state_12914__$1;
(statearr_12918_12980[(2)] = null);

(statearr_12918_12980[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (1))){
var inst_12818 = (state_12914[(8)]);
var inst_12818__$1 = calc_state.call(null);
var inst_12820 = (inst_12818__$1 == null);
var inst_12821 = cljs.core.not.call(null,inst_12820);
var state_12914__$1 = (function (){var statearr_12919 = state_12914;
(statearr_12919[(8)] = inst_12818__$1);

return statearr_12919;
})();
if(inst_12821){
var statearr_12920_12981 = state_12914__$1;
(statearr_12920_12981[(1)] = (2));

} else {
var statearr_12921_12982 = state_12914__$1;
(statearr_12921_12982[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (24))){
var inst_12865 = (state_12914[(9)]);
var inst_12874 = (state_12914[(10)]);
var inst_12888 = (state_12914[(11)]);
var inst_12888__$1 = inst_12865.call(null,inst_12874);
var state_12914__$1 = (function (){var statearr_12922 = state_12914;
(statearr_12922[(11)] = inst_12888__$1);

return statearr_12922;
})();
if(cljs.core.truth_(inst_12888__$1)){
var statearr_12923_12983 = state_12914__$1;
(statearr_12923_12983[(1)] = (29));

} else {
var statearr_12924_12984 = state_12914__$1;
(statearr_12924_12984[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (4))){
var inst_12833 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12833)){
var statearr_12925_12985 = state_12914__$1;
(statearr_12925_12985[(1)] = (8));

} else {
var statearr_12926_12986 = state_12914__$1;
(statearr_12926_12986[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (15))){
var inst_12859 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12859)){
var statearr_12927_12987 = state_12914__$1;
(statearr_12927_12987[(1)] = (19));

} else {
var statearr_12928_12988 = state_12914__$1;
(statearr_12928_12988[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (21))){
var inst_12864 = (state_12914[(12)]);
var inst_12864__$1 = (state_12914[(2)]);
var inst_12865 = cljs.core.get.call(null,inst_12864__$1,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_12866 = cljs.core.get.call(null,inst_12864__$1,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_12867 = cljs.core.get.call(null,inst_12864__$1,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var state_12914__$1 = (function (){var statearr_12929 = state_12914;
(statearr_12929[(12)] = inst_12864__$1);

(statearr_12929[(9)] = inst_12865);

(statearr_12929[(13)] = inst_12866);

return statearr_12929;
})();
return cljs.core.async.ioc_alts_BANG_.call(null,state_12914__$1,(22),inst_12867);
} else {
if((state_val_12915 === (31))){
var inst_12896 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12896)){
var statearr_12930_12989 = state_12914__$1;
(statearr_12930_12989[(1)] = (32));

} else {
var statearr_12931_12990 = state_12914__$1;
(statearr_12931_12990[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (32))){
var inst_12873 = (state_12914[(14)]);
var state_12914__$1 = state_12914;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_12914__$1,(35),out,inst_12873);
} else {
if((state_val_12915 === (33))){
var inst_12864 = (state_12914[(12)]);
var inst_12842 = inst_12864;
var state_12914__$1 = (function (){var statearr_12932 = state_12914;
(statearr_12932[(7)] = inst_12842);

return statearr_12932;
})();
var statearr_12933_12991 = state_12914__$1;
(statearr_12933_12991[(2)] = null);

(statearr_12933_12991[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (13))){
var inst_12842 = (state_12914[(7)]);
var inst_12849 = inst_12842.cljs$lang$protocol_mask$partition0$;
var inst_12850 = (inst_12849 & (64));
var inst_12851 = inst_12842.cljs$core$ISeq$;
var inst_12852 = (inst_12850) || (inst_12851);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12852)){
var statearr_12934_12992 = state_12914__$1;
(statearr_12934_12992[(1)] = (16));

} else {
var statearr_12935_12993 = state_12914__$1;
(statearr_12935_12993[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (22))){
var inst_12874 = (state_12914[(10)]);
var inst_12873 = (state_12914[(14)]);
var inst_12872 = (state_12914[(2)]);
var inst_12873__$1 = cljs.core.nth.call(null,inst_12872,(0),null);
var inst_12874__$1 = cljs.core.nth.call(null,inst_12872,(1),null);
var inst_12875 = (inst_12873__$1 == null);
var inst_12876 = cljs.core._EQ_.call(null,inst_12874__$1,change);
var inst_12877 = (inst_12875) || (inst_12876);
var state_12914__$1 = (function (){var statearr_12936 = state_12914;
(statearr_12936[(10)] = inst_12874__$1);

(statearr_12936[(14)] = inst_12873__$1);

return statearr_12936;
})();
if(cljs.core.truth_(inst_12877)){
var statearr_12937_12994 = state_12914__$1;
(statearr_12937_12994[(1)] = (23));

} else {
var statearr_12938_12995 = state_12914__$1;
(statearr_12938_12995[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (36))){
var inst_12864 = (state_12914[(12)]);
var inst_12842 = inst_12864;
var state_12914__$1 = (function (){var statearr_12939 = state_12914;
(statearr_12939[(7)] = inst_12842);

return statearr_12939;
})();
var statearr_12940_12996 = state_12914__$1;
(statearr_12940_12996[(2)] = null);

(statearr_12940_12996[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (29))){
var inst_12888 = (state_12914[(11)]);
var state_12914__$1 = state_12914;
var statearr_12941_12997 = state_12914__$1;
(statearr_12941_12997[(2)] = inst_12888);

(statearr_12941_12997[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (6))){
var state_12914__$1 = state_12914;
var statearr_12942_12998 = state_12914__$1;
(statearr_12942_12998[(2)] = false);

(statearr_12942_12998[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (28))){
var inst_12884 = (state_12914[(2)]);
var inst_12885 = calc_state.call(null);
var inst_12842 = inst_12885;
var state_12914__$1 = (function (){var statearr_12943 = state_12914;
(statearr_12943[(7)] = inst_12842);

(statearr_12943[(15)] = inst_12884);

return statearr_12943;
})();
var statearr_12944_12999 = state_12914__$1;
(statearr_12944_12999[(2)] = null);

(statearr_12944_12999[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (25))){
var inst_12910 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
var statearr_12945_13000 = state_12914__$1;
(statearr_12945_13000[(2)] = inst_12910);

(statearr_12945_13000[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (34))){
var inst_12908 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
var statearr_12946_13001 = state_12914__$1;
(statearr_12946_13001[(2)] = inst_12908);

(statearr_12946_13001[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (17))){
var state_12914__$1 = state_12914;
var statearr_12947_13002 = state_12914__$1;
(statearr_12947_13002[(2)] = false);

(statearr_12947_13002[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (3))){
var state_12914__$1 = state_12914;
var statearr_12948_13003 = state_12914__$1;
(statearr_12948_13003[(2)] = false);

(statearr_12948_13003[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (12))){
var inst_12912 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_12914__$1,inst_12912);
} else {
if((state_val_12915 === (2))){
var inst_12818 = (state_12914[(8)]);
var inst_12823 = inst_12818.cljs$lang$protocol_mask$partition0$;
var inst_12824 = (inst_12823 & (64));
var inst_12825 = inst_12818.cljs$core$ISeq$;
var inst_12826 = (inst_12824) || (inst_12825);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12826)){
var statearr_12949_13004 = state_12914__$1;
(statearr_12949_13004[(1)] = (5));

} else {
var statearr_12950_13005 = state_12914__$1;
(statearr_12950_13005[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (23))){
var inst_12873 = (state_12914[(14)]);
var inst_12879 = (inst_12873 == null);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12879)){
var statearr_12951_13006 = state_12914__$1;
(statearr_12951_13006[(1)] = (26));

} else {
var statearr_12952_13007 = state_12914__$1;
(statearr_12952_13007[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (35))){
var inst_12899 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
if(cljs.core.truth_(inst_12899)){
var statearr_12953_13008 = state_12914__$1;
(statearr_12953_13008[(1)] = (36));

} else {
var statearr_12954_13009 = state_12914__$1;
(statearr_12954_13009[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (19))){
var inst_12842 = (state_12914[(7)]);
var inst_12861 = cljs.core.apply.call(null,cljs.core.hash_map,inst_12842);
var state_12914__$1 = state_12914;
var statearr_12955_13010 = state_12914__$1;
(statearr_12955_13010[(2)] = inst_12861);

(statearr_12955_13010[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (11))){
var inst_12842 = (state_12914[(7)]);
var inst_12846 = (inst_12842 == null);
var inst_12847 = cljs.core.not.call(null,inst_12846);
var state_12914__$1 = state_12914;
if(inst_12847){
var statearr_12956_13011 = state_12914__$1;
(statearr_12956_13011[(1)] = (13));

} else {
var statearr_12957_13012 = state_12914__$1;
(statearr_12957_13012[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (9))){
var inst_12818 = (state_12914[(8)]);
var state_12914__$1 = state_12914;
var statearr_12958_13013 = state_12914__$1;
(statearr_12958_13013[(2)] = inst_12818);

(statearr_12958_13013[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (5))){
var state_12914__$1 = state_12914;
var statearr_12959_13014 = state_12914__$1;
(statearr_12959_13014[(2)] = true);

(statearr_12959_13014[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (14))){
var state_12914__$1 = state_12914;
var statearr_12960_13015 = state_12914__$1;
(statearr_12960_13015[(2)] = false);

(statearr_12960_13015[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (26))){
var inst_12874 = (state_12914[(10)]);
var inst_12881 = cljs.core.swap_BANG_.call(null,cs,cljs.core.dissoc,inst_12874);
var state_12914__$1 = state_12914;
var statearr_12961_13016 = state_12914__$1;
(statearr_12961_13016[(2)] = inst_12881);

(statearr_12961_13016[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (16))){
var state_12914__$1 = state_12914;
var statearr_12962_13017 = state_12914__$1;
(statearr_12962_13017[(2)] = true);

(statearr_12962_13017[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (38))){
var inst_12904 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
var statearr_12963_13018 = state_12914__$1;
(statearr_12963_13018[(2)] = inst_12904);

(statearr_12963_13018[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (30))){
var inst_12865 = (state_12914[(9)]);
var inst_12874 = (state_12914[(10)]);
var inst_12866 = (state_12914[(13)]);
var inst_12891 = cljs.core.empty_QMARK_.call(null,inst_12865);
var inst_12892 = inst_12866.call(null,inst_12874);
var inst_12893 = cljs.core.not.call(null,inst_12892);
var inst_12894 = (inst_12891) && (inst_12893);
var state_12914__$1 = state_12914;
var statearr_12964_13019 = state_12914__$1;
(statearr_12964_13019[(2)] = inst_12894);

(statearr_12964_13019[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (10))){
var inst_12818 = (state_12914[(8)]);
var inst_12838 = (state_12914[(2)]);
var inst_12839 = cljs.core.get.call(null,inst_12838,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_12840 = cljs.core.get.call(null,inst_12838,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_12841 = cljs.core.get.call(null,inst_12838,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var inst_12842 = inst_12818;
var state_12914__$1 = (function (){var statearr_12965 = state_12914;
(statearr_12965[(16)] = inst_12839);

(statearr_12965[(17)] = inst_12841);

(statearr_12965[(7)] = inst_12842);

(statearr_12965[(18)] = inst_12840);

return statearr_12965;
})();
var statearr_12966_13020 = state_12914__$1;
(statearr_12966_13020[(2)] = null);

(statearr_12966_13020[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (18))){
var inst_12856 = (state_12914[(2)]);
var state_12914__$1 = state_12914;
var statearr_12967_13021 = state_12914__$1;
(statearr_12967_13021[(2)] = inst_12856);

(statearr_12967_13021[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (37))){
var state_12914__$1 = state_12914;
var statearr_12968_13022 = state_12914__$1;
(statearr_12968_13022[(2)] = null);

(statearr_12968_13022[(1)] = (38));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_12915 === (8))){
var inst_12818 = (state_12914[(8)]);
var inst_12835 = cljs.core.apply.call(null,cljs.core.hash_map,inst_12818);
var state_12914__$1 = state_12914;
var statearr_12969_13023 = state_12914__$1;
(statearr_12969_13023[(2)] = inst_12835);

(statearr_12969_13023[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__11132__auto__,c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__11133__auto__ = null;
var cljs$core$async$mix_$_state_machine__11133__auto____0 = (function (){
var statearr_12973 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_12973[(0)] = cljs$core$async$mix_$_state_machine__11133__auto__);

(statearr_12973[(1)] = (1));

return statearr_12973;
});
var cljs$core$async$mix_$_state_machine__11133__auto____1 = (function (state_12914){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_12914);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e12974){if((e12974 instanceof Object)){
var ex__11136__auto__ = e12974;
var statearr_12975_13024 = state_12914;
(statearr_12975_13024[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_12914);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e12974;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13025 = state_12914;
state_12914 = G__13025;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__11133__auto__ = function(state_12914){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__11133__auto____1.call(this,state_12914);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__11133__auto____0;
cljs$core$async$mix_$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__11133__auto____1;
return cljs$core$async$mix_$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__11246__auto__ = (function (){var statearr_12976 = f__11245__auto__.call(null);
(statearr_12976[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___12977);

return statearr_12976;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___12977,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_.call(null,mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_.call(null,mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_.call(null,mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_.call(null,mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_.call(null,mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((!((p == null))) && (!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__7072__auto__ = (((p == null))?null:p);
var m__7073__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,p,v,ch,close_QMARK_);
} else {
var m__7073__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,p,v,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__7072__auto__ = (((p == null))?null:p);
var m__7073__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,p,v,ch);
} else {
var m__7073__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,p,v,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var args13026 = [];
var len__7484__auto___13029 = arguments.length;
var i__7485__auto___13030 = (0);
while(true){
if((i__7485__auto___13030 < len__7484__auto___13029)){
args13026.push((arguments[i__7485__auto___13030]));

var G__13031 = (i__7485__auto___13030 + (1));
i__7485__auto___13030 = G__13031;
continue;
} else {
}
break;
}

var G__13028 = args13026.length;
switch (G__13028) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13026.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__7072__auto__ = (((p == null))?null:p);
var m__7073__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,p);
} else {
var m__7073__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,p);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__7072__auto__ = (((p == null))?null:p);
var m__7073__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__7072__auto__)]);
if(!((m__7073__auto__ == null))){
return m__7073__auto__.call(null,p,v);
} else {
var m__7073__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__7073__auto____$1 == null))){
return m__7073__auto____$1.call(null,p,v);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;


/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var args13034 = [];
var len__7484__auto___13159 = arguments.length;
var i__7485__auto___13160 = (0);
while(true){
if((i__7485__auto___13160 < len__7484__auto___13159)){
args13034.push((arguments[i__7485__auto___13160]));

var G__13161 = (i__7485__auto___13160 + (1));
i__7485__auto___13160 = G__13161;
continue;
} else {
}
break;
}

var G__13036 = args13034.length;
switch (G__13036) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13034.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.call(null,ch,topic_fn,cljs.core.constantly.call(null,null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__6409__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,mults),topic);
if(cljs.core.truth_(or__6409__auto__)){
return or__6409__auto__;
} else {
return cljs.core.get.call(null,cljs.core.swap_BANG_.call(null,mults,((function (or__6409__auto__,mults){
return (function (p1__13033_SHARP_){
if(cljs.core.truth_(p1__13033_SHARP_.call(null,topic))){
return p1__13033_SHARP_;
} else {
return cljs.core.assoc.call(null,p1__13033_SHARP_,topic,cljs.core.async.mult.call(null,cljs.core.async.chan.call(null,buf_fn.call(null,topic))));
}
});})(or__6409__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if(typeof cljs.core.async.t_cljs$core$async13037 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async13037 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta13038){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta13038 = meta13038;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_13039,meta13038__$1){
var self__ = this;
var _13039__$1 = this;
return (new cljs.core.async.t_cljs$core$async13037(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta13038__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_13039){
var self__ = this;
var _13039__$1 = this;
return self__.meta13038;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Pub$ = true;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = self__.ensure_mult.call(null,topic);
return cljs.core.async.tap.call(null,m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__4657__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,self__.mults),topic);
if(cljs.core.truth_(temp__4657__auto__)){
var m = temp__4657__auto__;
return cljs.core.async.untap.call(null,m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_.call(null,self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.call(null,self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"topic-fn","topic-fn",-862449736,null),new cljs.core.Symbol(null,"buf-fn","buf-fn",-1200281591,null),new cljs.core.Symbol(null,"mults","mults",-461114485,null),new cljs.core.Symbol(null,"ensure-mult","ensure-mult",1796584816,null),new cljs.core.Symbol(null,"meta13038","meta13038",25497699,null)], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async13037.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async13037.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async13037";

cljs.core.async.t_cljs$core$async13037.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async13037");
});})(mults,ensure_mult))
;

cljs.core.async.__GT_t_cljs$core$async13037 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async13037(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta13038){
return (new cljs.core.async.t_cljs$core$async13037(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta13038));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async13037(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__11244__auto___13163 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13163,mults,ensure_mult,p){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13163,mults,ensure_mult,p){
return (function (state_13111){
var state_val_13112 = (state_13111[(1)]);
if((state_val_13112 === (7))){
var inst_13107 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13113_13164 = state_13111__$1;
(statearr_13113_13164[(2)] = inst_13107);

(statearr_13113_13164[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (20))){
var state_13111__$1 = state_13111;
var statearr_13114_13165 = state_13111__$1;
(statearr_13114_13165[(2)] = null);

(statearr_13114_13165[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (1))){
var state_13111__$1 = state_13111;
var statearr_13115_13166 = state_13111__$1;
(statearr_13115_13166[(2)] = null);

(statearr_13115_13166[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (24))){
var inst_13090 = (state_13111[(7)]);
var inst_13099 = cljs.core.swap_BANG_.call(null,mults,cljs.core.dissoc,inst_13090);
var state_13111__$1 = state_13111;
var statearr_13116_13167 = state_13111__$1;
(statearr_13116_13167[(2)] = inst_13099);

(statearr_13116_13167[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (4))){
var inst_13042 = (state_13111[(8)]);
var inst_13042__$1 = (state_13111[(2)]);
var inst_13043 = (inst_13042__$1 == null);
var state_13111__$1 = (function (){var statearr_13117 = state_13111;
(statearr_13117[(8)] = inst_13042__$1);

return statearr_13117;
})();
if(cljs.core.truth_(inst_13043)){
var statearr_13118_13168 = state_13111__$1;
(statearr_13118_13168[(1)] = (5));

} else {
var statearr_13119_13169 = state_13111__$1;
(statearr_13119_13169[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (15))){
var inst_13084 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13120_13170 = state_13111__$1;
(statearr_13120_13170[(2)] = inst_13084);

(statearr_13120_13170[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (21))){
var inst_13104 = (state_13111[(2)]);
var state_13111__$1 = (function (){var statearr_13121 = state_13111;
(statearr_13121[(9)] = inst_13104);

return statearr_13121;
})();
var statearr_13122_13171 = state_13111__$1;
(statearr_13122_13171[(2)] = null);

(statearr_13122_13171[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (13))){
var inst_13066 = (state_13111[(10)]);
var inst_13068 = cljs.core.chunked_seq_QMARK_.call(null,inst_13066);
var state_13111__$1 = state_13111;
if(inst_13068){
var statearr_13123_13172 = state_13111__$1;
(statearr_13123_13172[(1)] = (16));

} else {
var statearr_13124_13173 = state_13111__$1;
(statearr_13124_13173[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (22))){
var inst_13096 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
if(cljs.core.truth_(inst_13096)){
var statearr_13125_13174 = state_13111__$1;
(statearr_13125_13174[(1)] = (23));

} else {
var statearr_13126_13175 = state_13111__$1;
(statearr_13126_13175[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (6))){
var inst_13042 = (state_13111[(8)]);
var inst_13092 = (state_13111[(11)]);
var inst_13090 = (state_13111[(7)]);
var inst_13090__$1 = topic_fn.call(null,inst_13042);
var inst_13091 = cljs.core.deref.call(null,mults);
var inst_13092__$1 = cljs.core.get.call(null,inst_13091,inst_13090__$1);
var state_13111__$1 = (function (){var statearr_13127 = state_13111;
(statearr_13127[(11)] = inst_13092__$1);

(statearr_13127[(7)] = inst_13090__$1);

return statearr_13127;
})();
if(cljs.core.truth_(inst_13092__$1)){
var statearr_13128_13176 = state_13111__$1;
(statearr_13128_13176[(1)] = (19));

} else {
var statearr_13129_13177 = state_13111__$1;
(statearr_13129_13177[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (25))){
var inst_13101 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13130_13178 = state_13111__$1;
(statearr_13130_13178[(2)] = inst_13101);

(statearr_13130_13178[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (17))){
var inst_13066 = (state_13111[(10)]);
var inst_13075 = cljs.core.first.call(null,inst_13066);
var inst_13076 = cljs.core.async.muxch_STAR_.call(null,inst_13075);
var inst_13077 = cljs.core.async.close_BANG_.call(null,inst_13076);
var inst_13078 = cljs.core.next.call(null,inst_13066);
var inst_13052 = inst_13078;
var inst_13053 = null;
var inst_13054 = (0);
var inst_13055 = (0);
var state_13111__$1 = (function (){var statearr_13131 = state_13111;
(statearr_13131[(12)] = inst_13053);

(statearr_13131[(13)] = inst_13052);

(statearr_13131[(14)] = inst_13077);

(statearr_13131[(15)] = inst_13054);

(statearr_13131[(16)] = inst_13055);

return statearr_13131;
})();
var statearr_13132_13179 = state_13111__$1;
(statearr_13132_13179[(2)] = null);

(statearr_13132_13179[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (3))){
var inst_13109 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13111__$1,inst_13109);
} else {
if((state_val_13112 === (12))){
var inst_13086 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13133_13180 = state_13111__$1;
(statearr_13133_13180[(2)] = inst_13086);

(statearr_13133_13180[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (2))){
var state_13111__$1 = state_13111;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13111__$1,(4),ch);
} else {
if((state_val_13112 === (23))){
var state_13111__$1 = state_13111;
var statearr_13134_13181 = state_13111__$1;
(statearr_13134_13181[(2)] = null);

(statearr_13134_13181[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (19))){
var inst_13042 = (state_13111[(8)]);
var inst_13092 = (state_13111[(11)]);
var inst_13094 = cljs.core.async.muxch_STAR_.call(null,inst_13092);
var state_13111__$1 = state_13111;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13111__$1,(22),inst_13094,inst_13042);
} else {
if((state_val_13112 === (11))){
var inst_13052 = (state_13111[(13)]);
var inst_13066 = (state_13111[(10)]);
var inst_13066__$1 = cljs.core.seq.call(null,inst_13052);
var state_13111__$1 = (function (){var statearr_13135 = state_13111;
(statearr_13135[(10)] = inst_13066__$1);

return statearr_13135;
})();
if(inst_13066__$1){
var statearr_13136_13182 = state_13111__$1;
(statearr_13136_13182[(1)] = (13));

} else {
var statearr_13137_13183 = state_13111__$1;
(statearr_13137_13183[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (9))){
var inst_13088 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13138_13184 = state_13111__$1;
(statearr_13138_13184[(2)] = inst_13088);

(statearr_13138_13184[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (5))){
var inst_13049 = cljs.core.deref.call(null,mults);
var inst_13050 = cljs.core.vals.call(null,inst_13049);
var inst_13051 = cljs.core.seq.call(null,inst_13050);
var inst_13052 = inst_13051;
var inst_13053 = null;
var inst_13054 = (0);
var inst_13055 = (0);
var state_13111__$1 = (function (){var statearr_13139 = state_13111;
(statearr_13139[(12)] = inst_13053);

(statearr_13139[(13)] = inst_13052);

(statearr_13139[(15)] = inst_13054);

(statearr_13139[(16)] = inst_13055);

return statearr_13139;
})();
var statearr_13140_13185 = state_13111__$1;
(statearr_13140_13185[(2)] = null);

(statearr_13140_13185[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (14))){
var state_13111__$1 = state_13111;
var statearr_13144_13186 = state_13111__$1;
(statearr_13144_13186[(2)] = null);

(statearr_13144_13186[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (16))){
var inst_13066 = (state_13111[(10)]);
var inst_13070 = cljs.core.chunk_first.call(null,inst_13066);
var inst_13071 = cljs.core.chunk_rest.call(null,inst_13066);
var inst_13072 = cljs.core.count.call(null,inst_13070);
var inst_13052 = inst_13071;
var inst_13053 = inst_13070;
var inst_13054 = inst_13072;
var inst_13055 = (0);
var state_13111__$1 = (function (){var statearr_13145 = state_13111;
(statearr_13145[(12)] = inst_13053);

(statearr_13145[(13)] = inst_13052);

(statearr_13145[(15)] = inst_13054);

(statearr_13145[(16)] = inst_13055);

return statearr_13145;
})();
var statearr_13146_13187 = state_13111__$1;
(statearr_13146_13187[(2)] = null);

(statearr_13146_13187[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (10))){
var inst_13053 = (state_13111[(12)]);
var inst_13052 = (state_13111[(13)]);
var inst_13054 = (state_13111[(15)]);
var inst_13055 = (state_13111[(16)]);
var inst_13060 = cljs.core._nth.call(null,inst_13053,inst_13055);
var inst_13061 = cljs.core.async.muxch_STAR_.call(null,inst_13060);
var inst_13062 = cljs.core.async.close_BANG_.call(null,inst_13061);
var inst_13063 = (inst_13055 + (1));
var tmp13141 = inst_13053;
var tmp13142 = inst_13052;
var tmp13143 = inst_13054;
var inst_13052__$1 = tmp13142;
var inst_13053__$1 = tmp13141;
var inst_13054__$1 = tmp13143;
var inst_13055__$1 = inst_13063;
var state_13111__$1 = (function (){var statearr_13147 = state_13111;
(statearr_13147[(12)] = inst_13053__$1);

(statearr_13147[(13)] = inst_13052__$1);

(statearr_13147[(15)] = inst_13054__$1);

(statearr_13147[(16)] = inst_13055__$1);

(statearr_13147[(17)] = inst_13062);

return statearr_13147;
})();
var statearr_13148_13188 = state_13111__$1;
(statearr_13148_13188[(2)] = null);

(statearr_13148_13188[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (18))){
var inst_13081 = (state_13111[(2)]);
var state_13111__$1 = state_13111;
var statearr_13149_13189 = state_13111__$1;
(statearr_13149_13189[(2)] = inst_13081);

(statearr_13149_13189[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13112 === (8))){
var inst_13054 = (state_13111[(15)]);
var inst_13055 = (state_13111[(16)]);
var inst_13057 = (inst_13055 < inst_13054);
var inst_13058 = inst_13057;
var state_13111__$1 = state_13111;
if(cljs.core.truth_(inst_13058)){
var statearr_13150_13190 = state_13111__$1;
(statearr_13150_13190[(1)] = (10));

} else {
var statearr_13151_13191 = state_13111__$1;
(statearr_13151_13191[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13163,mults,ensure_mult,p))
;
return ((function (switch__11132__auto__,c__11244__auto___13163,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13155 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_13155[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13155[(1)] = (1));

return statearr_13155;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13111){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13111);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13156){if((e13156 instanceof Object)){
var ex__11136__auto__ = e13156;
var statearr_13157_13192 = state_13111;
(statearr_13157_13192[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13111);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13156;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13193 = state_13111;
state_13111 = G__13193;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13111){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13111);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13163,mults,ensure_mult,p))
})();
var state__11246__auto__ = (function (){var statearr_13158 = f__11245__auto__.call(null);
(statearr_13158[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13163);

return statearr_13158;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13163,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;

/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var args13194 = [];
var len__7484__auto___13197 = arguments.length;
var i__7485__auto___13198 = (0);
while(true){
if((i__7485__auto___13198 < len__7484__auto___13197)){
args13194.push((arguments[i__7485__auto___13198]));

var G__13199 = (i__7485__auto___13198 + (1));
i__7485__auto___13198 = G__13199;
continue;
} else {
}
break;
}

var G__13196 = args13194.length;
switch (G__13196) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13194.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.call(null,p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_.call(null,p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;

/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_.call(null,p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var args13201 = [];
var len__7484__auto___13204 = arguments.length;
var i__7485__auto___13205 = (0);
while(true){
if((i__7485__auto___13205 < len__7484__auto___13204)){
args13201.push((arguments[i__7485__auto___13205]));

var G__13206 = (i__7485__auto___13205 + (1));
i__7485__auto___13205 = G__13206;
continue;
} else {
}
break;
}

var G__13203 = args13201.length;
switch (G__13203) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13201.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.call(null,p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.call(null,p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;

/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var args13208 = [];
var len__7484__auto___13279 = arguments.length;
var i__7485__auto___13280 = (0);
while(true){
if((i__7485__auto___13280 < len__7484__auto___13279)){
args13208.push((arguments[i__7485__auto___13280]));

var G__13281 = (i__7485__auto___13280 + (1));
i__7485__auto___13280 = G__13281;
continue;
} else {
}
break;
}

var G__13210 = args13208.length;
switch (G__13210) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13208.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.call(null,f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec.call(null,chs);
var out = cljs.core.async.chan.call(null,buf_or_n);
var cnt = cljs.core.count.call(null,chs__$1);
var rets = cljs.core.object_array.call(null,cnt);
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = cljs.core.mapv.call(null,((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.call(null,cnt));
var c__11244__auto___13283 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_13249){
var state_val_13250 = (state_13249[(1)]);
if((state_val_13250 === (7))){
var state_13249__$1 = state_13249;
var statearr_13251_13284 = state_13249__$1;
(statearr_13251_13284[(2)] = null);

(statearr_13251_13284[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (1))){
var state_13249__$1 = state_13249;
var statearr_13252_13285 = state_13249__$1;
(statearr_13252_13285[(2)] = null);

(statearr_13252_13285[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (4))){
var inst_13213 = (state_13249[(7)]);
var inst_13215 = (inst_13213 < cnt);
var state_13249__$1 = state_13249;
if(cljs.core.truth_(inst_13215)){
var statearr_13253_13286 = state_13249__$1;
(statearr_13253_13286[(1)] = (6));

} else {
var statearr_13254_13287 = state_13249__$1;
(statearr_13254_13287[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (15))){
var inst_13245 = (state_13249[(2)]);
var state_13249__$1 = state_13249;
var statearr_13255_13288 = state_13249__$1;
(statearr_13255_13288[(2)] = inst_13245);

(statearr_13255_13288[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (13))){
var inst_13238 = cljs.core.async.close_BANG_.call(null,out);
var state_13249__$1 = state_13249;
var statearr_13256_13289 = state_13249__$1;
(statearr_13256_13289[(2)] = inst_13238);

(statearr_13256_13289[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (6))){
var state_13249__$1 = state_13249;
var statearr_13257_13290 = state_13249__$1;
(statearr_13257_13290[(2)] = null);

(statearr_13257_13290[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (3))){
var inst_13247 = (state_13249[(2)]);
var state_13249__$1 = state_13249;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13249__$1,inst_13247);
} else {
if((state_val_13250 === (12))){
var inst_13235 = (state_13249[(8)]);
var inst_13235__$1 = (state_13249[(2)]);
var inst_13236 = cljs.core.some.call(null,cljs.core.nil_QMARK_,inst_13235__$1);
var state_13249__$1 = (function (){var statearr_13258 = state_13249;
(statearr_13258[(8)] = inst_13235__$1);

return statearr_13258;
})();
if(cljs.core.truth_(inst_13236)){
var statearr_13259_13291 = state_13249__$1;
(statearr_13259_13291[(1)] = (13));

} else {
var statearr_13260_13292 = state_13249__$1;
(statearr_13260_13292[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (2))){
var inst_13212 = cljs.core.reset_BANG_.call(null,dctr,cnt);
var inst_13213 = (0);
var state_13249__$1 = (function (){var statearr_13261 = state_13249;
(statearr_13261[(9)] = inst_13212);

(statearr_13261[(7)] = inst_13213);

return statearr_13261;
})();
var statearr_13262_13293 = state_13249__$1;
(statearr_13262_13293[(2)] = null);

(statearr_13262_13293[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (11))){
var inst_13213 = (state_13249[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame.call(null,state_13249,(10),Object,null,(9));
var inst_13222 = chs__$1.call(null,inst_13213);
var inst_13223 = done.call(null,inst_13213);
var inst_13224 = cljs.core.async.take_BANG_.call(null,inst_13222,inst_13223);
var state_13249__$1 = state_13249;
var statearr_13263_13294 = state_13249__$1;
(statearr_13263_13294[(2)] = inst_13224);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13249__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (9))){
var inst_13213 = (state_13249[(7)]);
var inst_13226 = (state_13249[(2)]);
var inst_13227 = (inst_13213 + (1));
var inst_13213__$1 = inst_13227;
var state_13249__$1 = (function (){var statearr_13264 = state_13249;
(statearr_13264[(7)] = inst_13213__$1);

(statearr_13264[(10)] = inst_13226);

return statearr_13264;
})();
var statearr_13265_13295 = state_13249__$1;
(statearr_13265_13295[(2)] = null);

(statearr_13265_13295[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (5))){
var inst_13233 = (state_13249[(2)]);
var state_13249__$1 = (function (){var statearr_13266 = state_13249;
(statearr_13266[(11)] = inst_13233);

return statearr_13266;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13249__$1,(12),dchan);
} else {
if((state_val_13250 === (14))){
var inst_13235 = (state_13249[(8)]);
var inst_13240 = cljs.core.apply.call(null,f,inst_13235);
var state_13249__$1 = state_13249;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13249__$1,(16),out,inst_13240);
} else {
if((state_val_13250 === (16))){
var inst_13242 = (state_13249[(2)]);
var state_13249__$1 = (function (){var statearr_13267 = state_13249;
(statearr_13267[(12)] = inst_13242);

return statearr_13267;
})();
var statearr_13268_13296 = state_13249__$1;
(statearr_13268_13296[(2)] = null);

(statearr_13268_13296[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (10))){
var inst_13217 = (state_13249[(2)]);
var inst_13218 = cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec);
var state_13249__$1 = (function (){var statearr_13269 = state_13249;
(statearr_13269[(13)] = inst_13217);

return statearr_13269;
})();
var statearr_13270_13297 = state_13249__$1;
(statearr_13270_13297[(2)] = inst_13218);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13249__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13250 === (8))){
var inst_13231 = (state_13249[(2)]);
var state_13249__$1 = state_13249;
var statearr_13271_13298 = state_13249__$1;
(statearr_13271_13298[(2)] = inst_13231);

(statearr_13271_13298[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__11132__auto__,c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13275 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_13275[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13275[(1)] = (1));

return statearr_13275;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13249){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13249);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13276){if((e13276 instanceof Object)){
var ex__11136__auto__ = e13276;
var statearr_13277_13299 = state_13249;
(statearr_13277_13299[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13249);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13276;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13300 = state_13249;
state_13249 = G__13300;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13249){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13249);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__11246__auto__ = (function (){var statearr_13278 = f__11245__auto__.call(null);
(statearr_13278[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13283);

return statearr_13278;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13283,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;

/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var args13302 = [];
var len__7484__auto___13360 = arguments.length;
var i__7485__auto___13361 = (0);
while(true){
if((i__7485__auto___13361 < len__7484__auto___13360)){
args13302.push((arguments[i__7485__auto___13361]));

var G__13362 = (i__7485__auto___13361 + (1));
i__7485__auto___13361 = G__13362;
continue;
} else {
}
break;
}

var G__13304 = args13302.length;
switch (G__13304) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13302.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.call(null,chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___13364 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13364,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13364,out){
return (function (state_13336){
var state_val_13337 = (state_13336[(1)]);
if((state_val_13337 === (7))){
var inst_13315 = (state_13336[(7)]);
var inst_13316 = (state_13336[(8)]);
var inst_13315__$1 = (state_13336[(2)]);
var inst_13316__$1 = cljs.core.nth.call(null,inst_13315__$1,(0),null);
var inst_13317 = cljs.core.nth.call(null,inst_13315__$1,(1),null);
var inst_13318 = (inst_13316__$1 == null);
var state_13336__$1 = (function (){var statearr_13338 = state_13336;
(statearr_13338[(7)] = inst_13315__$1);

(statearr_13338[(9)] = inst_13317);

(statearr_13338[(8)] = inst_13316__$1);

return statearr_13338;
})();
if(cljs.core.truth_(inst_13318)){
var statearr_13339_13365 = state_13336__$1;
(statearr_13339_13365[(1)] = (8));

} else {
var statearr_13340_13366 = state_13336__$1;
(statearr_13340_13366[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (1))){
var inst_13305 = cljs.core.vec.call(null,chs);
var inst_13306 = inst_13305;
var state_13336__$1 = (function (){var statearr_13341 = state_13336;
(statearr_13341[(10)] = inst_13306);

return statearr_13341;
})();
var statearr_13342_13367 = state_13336__$1;
(statearr_13342_13367[(2)] = null);

(statearr_13342_13367[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (4))){
var inst_13306 = (state_13336[(10)]);
var state_13336__$1 = state_13336;
return cljs.core.async.ioc_alts_BANG_.call(null,state_13336__$1,(7),inst_13306);
} else {
if((state_val_13337 === (6))){
var inst_13332 = (state_13336[(2)]);
var state_13336__$1 = state_13336;
var statearr_13343_13368 = state_13336__$1;
(statearr_13343_13368[(2)] = inst_13332);

(statearr_13343_13368[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (3))){
var inst_13334 = (state_13336[(2)]);
var state_13336__$1 = state_13336;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13336__$1,inst_13334);
} else {
if((state_val_13337 === (2))){
var inst_13306 = (state_13336[(10)]);
var inst_13308 = cljs.core.count.call(null,inst_13306);
var inst_13309 = (inst_13308 > (0));
var state_13336__$1 = state_13336;
if(cljs.core.truth_(inst_13309)){
var statearr_13345_13369 = state_13336__$1;
(statearr_13345_13369[(1)] = (4));

} else {
var statearr_13346_13370 = state_13336__$1;
(statearr_13346_13370[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (11))){
var inst_13306 = (state_13336[(10)]);
var inst_13325 = (state_13336[(2)]);
var tmp13344 = inst_13306;
var inst_13306__$1 = tmp13344;
var state_13336__$1 = (function (){var statearr_13347 = state_13336;
(statearr_13347[(11)] = inst_13325);

(statearr_13347[(10)] = inst_13306__$1);

return statearr_13347;
})();
var statearr_13348_13371 = state_13336__$1;
(statearr_13348_13371[(2)] = null);

(statearr_13348_13371[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (9))){
var inst_13316 = (state_13336[(8)]);
var state_13336__$1 = state_13336;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13336__$1,(11),out,inst_13316);
} else {
if((state_val_13337 === (5))){
var inst_13330 = cljs.core.async.close_BANG_.call(null,out);
var state_13336__$1 = state_13336;
var statearr_13349_13372 = state_13336__$1;
(statearr_13349_13372[(2)] = inst_13330);

(statearr_13349_13372[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (10))){
var inst_13328 = (state_13336[(2)]);
var state_13336__$1 = state_13336;
var statearr_13350_13373 = state_13336__$1;
(statearr_13350_13373[(2)] = inst_13328);

(statearr_13350_13373[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13337 === (8))){
var inst_13315 = (state_13336[(7)]);
var inst_13317 = (state_13336[(9)]);
var inst_13306 = (state_13336[(10)]);
var inst_13316 = (state_13336[(8)]);
var inst_13320 = (function (){var cs = inst_13306;
var vec__13311 = inst_13315;
var v = inst_13316;
var c = inst_13317;
return ((function (cs,vec__13311,v,c,inst_13315,inst_13317,inst_13306,inst_13316,state_val_13337,c__11244__auto___13364,out){
return (function (p1__13301_SHARP_){
return cljs.core.not_EQ_.call(null,c,p1__13301_SHARP_);
});
;})(cs,vec__13311,v,c,inst_13315,inst_13317,inst_13306,inst_13316,state_val_13337,c__11244__auto___13364,out))
})();
var inst_13321 = cljs.core.filterv.call(null,inst_13320,inst_13306);
var inst_13306__$1 = inst_13321;
var state_13336__$1 = (function (){var statearr_13351 = state_13336;
(statearr_13351[(10)] = inst_13306__$1);

return statearr_13351;
})();
var statearr_13352_13374 = state_13336__$1;
(statearr_13352_13374[(2)] = null);

(statearr_13352_13374[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13364,out))
;
return ((function (switch__11132__auto__,c__11244__auto___13364,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13356 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_13356[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13356[(1)] = (1));

return statearr_13356;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13336){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13336);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13357){if((e13357 instanceof Object)){
var ex__11136__auto__ = e13357;
var statearr_13358_13375 = state_13336;
(statearr_13358_13375[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13336);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13357;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13376 = state_13336;
state_13336 = G__13376;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13336){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13336);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13364,out))
})();
var state__11246__auto__ = (function (){var statearr_13359 = f__11245__auto__.call(null);
(statearr_13359[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13364);

return statearr_13359;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13364,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;

/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce.call(null,cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var args13377 = [];
var len__7484__auto___13426 = arguments.length;
var i__7485__auto___13427 = (0);
while(true){
if((i__7485__auto___13427 < len__7484__auto___13426)){
args13377.push((arguments[i__7485__auto___13427]));

var G__13428 = (i__7485__auto___13427 + (1));
i__7485__auto___13427 = G__13428;
continue;
} else {
}
break;
}

var G__13379 = args13377.length;
switch (G__13379) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13377.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.call(null,n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___13430 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13430,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13430,out){
return (function (state_13403){
var state_val_13404 = (state_13403[(1)]);
if((state_val_13404 === (7))){
var inst_13385 = (state_13403[(7)]);
var inst_13385__$1 = (state_13403[(2)]);
var inst_13386 = (inst_13385__$1 == null);
var inst_13387 = cljs.core.not.call(null,inst_13386);
var state_13403__$1 = (function (){var statearr_13405 = state_13403;
(statearr_13405[(7)] = inst_13385__$1);

return statearr_13405;
})();
if(inst_13387){
var statearr_13406_13431 = state_13403__$1;
(statearr_13406_13431[(1)] = (8));

} else {
var statearr_13407_13432 = state_13403__$1;
(statearr_13407_13432[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (1))){
var inst_13380 = (0);
var state_13403__$1 = (function (){var statearr_13408 = state_13403;
(statearr_13408[(8)] = inst_13380);

return statearr_13408;
})();
var statearr_13409_13433 = state_13403__$1;
(statearr_13409_13433[(2)] = null);

(statearr_13409_13433[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (4))){
var state_13403__$1 = state_13403;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13403__$1,(7),ch);
} else {
if((state_val_13404 === (6))){
var inst_13398 = (state_13403[(2)]);
var state_13403__$1 = state_13403;
var statearr_13410_13434 = state_13403__$1;
(statearr_13410_13434[(2)] = inst_13398);

(statearr_13410_13434[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (3))){
var inst_13400 = (state_13403[(2)]);
var inst_13401 = cljs.core.async.close_BANG_.call(null,out);
var state_13403__$1 = (function (){var statearr_13411 = state_13403;
(statearr_13411[(9)] = inst_13400);

return statearr_13411;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13403__$1,inst_13401);
} else {
if((state_val_13404 === (2))){
var inst_13380 = (state_13403[(8)]);
var inst_13382 = (inst_13380 < n);
var state_13403__$1 = state_13403;
if(cljs.core.truth_(inst_13382)){
var statearr_13412_13435 = state_13403__$1;
(statearr_13412_13435[(1)] = (4));

} else {
var statearr_13413_13436 = state_13403__$1;
(statearr_13413_13436[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (11))){
var inst_13380 = (state_13403[(8)]);
var inst_13390 = (state_13403[(2)]);
var inst_13391 = (inst_13380 + (1));
var inst_13380__$1 = inst_13391;
var state_13403__$1 = (function (){var statearr_13414 = state_13403;
(statearr_13414[(10)] = inst_13390);

(statearr_13414[(8)] = inst_13380__$1);

return statearr_13414;
})();
var statearr_13415_13437 = state_13403__$1;
(statearr_13415_13437[(2)] = null);

(statearr_13415_13437[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (9))){
var state_13403__$1 = state_13403;
var statearr_13416_13438 = state_13403__$1;
(statearr_13416_13438[(2)] = null);

(statearr_13416_13438[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (5))){
var state_13403__$1 = state_13403;
var statearr_13417_13439 = state_13403__$1;
(statearr_13417_13439[(2)] = null);

(statearr_13417_13439[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (10))){
var inst_13395 = (state_13403[(2)]);
var state_13403__$1 = state_13403;
var statearr_13418_13440 = state_13403__$1;
(statearr_13418_13440[(2)] = inst_13395);

(statearr_13418_13440[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13404 === (8))){
var inst_13385 = (state_13403[(7)]);
var state_13403__$1 = state_13403;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13403__$1,(11),out,inst_13385);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13430,out))
;
return ((function (switch__11132__auto__,c__11244__auto___13430,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13422 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_13422[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13422[(1)] = (1));

return statearr_13422;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13403){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13403);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13423){if((e13423 instanceof Object)){
var ex__11136__auto__ = e13423;
var statearr_13424_13441 = state_13403;
(statearr_13424_13441[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13403);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13423;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13442 = state_13403;
state_13403 = G__13442;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13403){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13403);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13430,out))
})();
var state__11246__auto__ = (function (){var statearr_13425 = f__11245__auto__.call(null);
(statearr_13425[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13430);

return statearr_13425;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13430,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async13450 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async13450 = (function (map_LT_,f,ch,meta13451){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta13451 = meta13451;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_13452,meta13451__$1){
var self__ = this;
var _13452__$1 = this;
return (new cljs.core.async.t_cljs$core$async13450(self__.map_LT_,self__.f,self__.ch,meta13451__$1));
});

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_13452){
var self__ = this;
var _13452__$1 = this;
return self__.meta13451;
});

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,(function (){
if(typeof cljs.core.async.t_cljs$core$async13453 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async13453 = (function (map_LT_,f,ch,meta13451,_,fn1,meta13454){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta13451 = meta13451;
this._ = _;
this.fn1 = fn1;
this.meta13454 = meta13454;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_13455,meta13454__$1){
var self__ = this;
var _13455__$1 = this;
return (new cljs.core.async.t_cljs$core$async13453(self__.map_LT_,self__.f,self__.ch,self__.meta13451,self__._,self__.fn1,meta13454__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_13455){
var self__ = this;
var _13455__$1 = this;
return self__.meta13454;
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit.call(null,self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__13443_SHARP_){
return f1.call(null,(((p1__13443_SHARP_ == null))?null:self__.f.call(null,p1__13443_SHARP_)));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map<","map<",-1235808357,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta13451","meta13451",-273849900,null),cljs.core.with_meta(new cljs.core.Symbol(null,"_","_",-1201019570,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core.async","t_cljs$core$async13450","cljs.core.async/t_cljs$core$async13450",-2142396240,null)], null)),new cljs.core.Symbol(null,"fn1","fn1",895834444,null),new cljs.core.Symbol(null,"meta13454","meta13454",22263890,null)], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async13453.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async13453.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async13453";

cljs.core.async.t_cljs$core$async13453.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async13453");
});})(___$1))
;

cljs.core.async.__GT_t_cljs$core$async13453 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async13453(map_LT___$1,f__$1,ch__$1,meta13451__$1,___$2,fn1__$1,meta13454){
return (new cljs.core.async.t_cljs$core$async13453(map_LT___$1,f__$1,ch__$1,meta13451__$1,___$2,fn1__$1,meta13454));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async13453(self__.map_LT_,self__.f,self__.ch,self__.meta13451,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__6397__auto__ = ret;
if(cljs.core.truth_(and__6397__auto__)){
return !((cljs.core.deref.call(null,ret) == null));
} else {
return and__6397__auto__;
}
})())){
return cljs.core.async.impl.channels.box.call(null,self__.f.call(null,cljs.core.deref.call(null,ret)));
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async13450.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async13450.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map<","map<",-1235808357,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta13451","meta13451",-273849900,null)], null);
});

cljs.core.async.t_cljs$core$async13450.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async13450.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async13450";

cljs.core.async.t_cljs$core$async13450.cljs$lang$ctorPrWriter = (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async13450");
});

cljs.core.async.__GT_t_cljs$core$async13450 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async13450(map_LT___$1,f__$1,ch__$1,meta13451){
return (new cljs.core.async.t_cljs$core$async13450(map_LT___$1,f__$1,ch__$1,meta13451));
});

}

return (new cljs.core.async.t_cljs$core$async13450(cljs$core$async$map_LT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async13459 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async13459 = (function (map_GT_,f,ch,meta13460){
this.map_GT_ = map_GT_;
this.f = f;
this.ch = ch;
this.meta13460 = meta13460;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_13461,meta13460__$1){
var self__ = this;
var _13461__$1 = this;
return (new cljs.core.async.t_cljs$core$async13459(self__.map_GT_,self__.f,self__.ch,meta13460__$1));
});

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_13461){
var self__ = this;
var _13461__$1 = this;
return self__.meta13460;
});

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async13459.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,self__.f.call(null,val),fn1);
});

cljs.core.async.t_cljs$core$async13459.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map>","map>",1676369295,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta13460","meta13460",-331233321,null)], null);
});

cljs.core.async.t_cljs$core$async13459.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async13459.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async13459";

cljs.core.async.t_cljs$core$async13459.cljs$lang$ctorPrWriter = (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async13459");
});

cljs.core.async.__GT_t_cljs$core$async13459 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async13459(map_GT___$1,f__$1,ch__$1,meta13460){
return (new cljs.core.async.t_cljs$core$async13459(map_GT___$1,f__$1,ch__$1,meta13460));
});

}

return (new cljs.core.async.t_cljs$core$async13459(cljs$core$async$map_GT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if(typeof cljs.core.async.t_cljs$core$async13465 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async13465 = (function (filter_GT_,p,ch,meta13466){
this.filter_GT_ = filter_GT_;
this.p = p;
this.ch = ch;
this.meta13466 = meta13466;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_13467,meta13466__$1){
var self__ = this;
var _13467__$1 = this;
return (new cljs.core.async.t_cljs$core$async13465(self__.filter_GT_,self__.p,self__.ch,meta13466__$1));
});

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_13467){
var self__ = this;
var _13467__$1 = this;
return self__.meta13466;
});

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async13465.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.p.call(null,val))){
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box.call(null,cljs.core.not.call(null,cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch)));
}
});

cljs.core.async.t_cljs$core$async13465.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"filter>","filter>",-37644455,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta13466","meta13466",1755809368,null)], null);
});

cljs.core.async.t_cljs$core$async13465.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async13465.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async13465";

cljs.core.async.t_cljs$core$async13465.cljs$lang$ctorPrWriter = (function (this__7015__auto__,writer__7016__auto__,opt__7017__auto__){
return cljs.core._write.call(null,writer__7016__auto__,"cljs.core.async/t_cljs$core$async13465");
});

cljs.core.async.__GT_t_cljs$core$async13465 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async13465(filter_GT___$1,p__$1,ch__$1,meta13466){
return (new cljs.core.async.t_cljs$core$async13465(filter_GT___$1,p__$1,ch__$1,meta13466));
});

}

return (new cljs.core.async.t_cljs$core$async13465(cljs$core$async$filter_GT_,p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_.call(null,cljs.core.complement.call(null,p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var args13468 = [];
var len__7484__auto___13512 = arguments.length;
var i__7485__auto___13513 = (0);
while(true){
if((i__7485__auto___13513 < len__7484__auto___13512)){
args13468.push((arguments[i__7485__auto___13513]));

var G__13514 = (i__7485__auto___13513 + (1));
i__7485__auto___13513 = G__13514;
continue;
} else {
}
break;
}

var G__13470 = args13468.length;
switch (G__13470) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13468.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.call(null,p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___13516 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13516,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13516,out){
return (function (state_13491){
var state_val_13492 = (state_13491[(1)]);
if((state_val_13492 === (7))){
var inst_13487 = (state_13491[(2)]);
var state_13491__$1 = state_13491;
var statearr_13493_13517 = state_13491__$1;
(statearr_13493_13517[(2)] = inst_13487);

(statearr_13493_13517[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (1))){
var state_13491__$1 = state_13491;
var statearr_13494_13518 = state_13491__$1;
(statearr_13494_13518[(2)] = null);

(statearr_13494_13518[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (4))){
var inst_13473 = (state_13491[(7)]);
var inst_13473__$1 = (state_13491[(2)]);
var inst_13474 = (inst_13473__$1 == null);
var state_13491__$1 = (function (){var statearr_13495 = state_13491;
(statearr_13495[(7)] = inst_13473__$1);

return statearr_13495;
})();
if(cljs.core.truth_(inst_13474)){
var statearr_13496_13519 = state_13491__$1;
(statearr_13496_13519[(1)] = (5));

} else {
var statearr_13497_13520 = state_13491__$1;
(statearr_13497_13520[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (6))){
var inst_13473 = (state_13491[(7)]);
var inst_13478 = p.call(null,inst_13473);
var state_13491__$1 = state_13491;
if(cljs.core.truth_(inst_13478)){
var statearr_13498_13521 = state_13491__$1;
(statearr_13498_13521[(1)] = (8));

} else {
var statearr_13499_13522 = state_13491__$1;
(statearr_13499_13522[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (3))){
var inst_13489 = (state_13491[(2)]);
var state_13491__$1 = state_13491;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13491__$1,inst_13489);
} else {
if((state_val_13492 === (2))){
var state_13491__$1 = state_13491;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13491__$1,(4),ch);
} else {
if((state_val_13492 === (11))){
var inst_13481 = (state_13491[(2)]);
var state_13491__$1 = state_13491;
var statearr_13500_13523 = state_13491__$1;
(statearr_13500_13523[(2)] = inst_13481);

(statearr_13500_13523[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (9))){
var state_13491__$1 = state_13491;
var statearr_13501_13524 = state_13491__$1;
(statearr_13501_13524[(2)] = null);

(statearr_13501_13524[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (5))){
var inst_13476 = cljs.core.async.close_BANG_.call(null,out);
var state_13491__$1 = state_13491;
var statearr_13502_13525 = state_13491__$1;
(statearr_13502_13525[(2)] = inst_13476);

(statearr_13502_13525[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (10))){
var inst_13484 = (state_13491[(2)]);
var state_13491__$1 = (function (){var statearr_13503 = state_13491;
(statearr_13503[(8)] = inst_13484);

return statearr_13503;
})();
var statearr_13504_13526 = state_13491__$1;
(statearr_13504_13526[(2)] = null);

(statearr_13504_13526[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13492 === (8))){
var inst_13473 = (state_13491[(7)]);
var state_13491__$1 = state_13491;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13491__$1,(11),out,inst_13473);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13516,out))
;
return ((function (switch__11132__auto__,c__11244__auto___13516,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13508 = [null,null,null,null,null,null,null,null,null];
(statearr_13508[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13508[(1)] = (1));

return statearr_13508;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13491){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13491);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13509){if((e13509 instanceof Object)){
var ex__11136__auto__ = e13509;
var statearr_13510_13527 = state_13491;
(statearr_13510_13527[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13491);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13509;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13528 = state_13491;
state_13491 = G__13528;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13491){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13491);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13516,out))
})();
var state__11246__auto__ = (function (){var statearr_13511 = f__11245__auto__.call(null);
(statearr_13511[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13516);

return statearr_13511;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13516,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var args13529 = [];
var len__7484__auto___13532 = arguments.length;
var i__7485__auto___13533 = (0);
while(true){
if((i__7485__auto___13533 < len__7484__auto___13532)){
args13529.push((arguments[i__7485__auto___13533]));

var G__13534 = (i__7485__auto___13533 + (1));
i__7485__auto___13533 = G__13534;
continue;
} else {
}
break;
}

var G__13531 = args13529.length;
switch (G__13531) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13529.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.call(null,p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.call(null,cljs.core.complement.call(null,p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;

cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__11244__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto__){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto__){
return (function (state_13701){
var state_val_13702 = (state_13701[(1)]);
if((state_val_13702 === (7))){
var inst_13697 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
var statearr_13703_13744 = state_13701__$1;
(statearr_13703_13744[(2)] = inst_13697);

(statearr_13703_13744[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (20))){
var inst_13667 = (state_13701[(7)]);
var inst_13678 = (state_13701[(2)]);
var inst_13679 = cljs.core.next.call(null,inst_13667);
var inst_13653 = inst_13679;
var inst_13654 = null;
var inst_13655 = (0);
var inst_13656 = (0);
var state_13701__$1 = (function (){var statearr_13704 = state_13701;
(statearr_13704[(8)] = inst_13655);

(statearr_13704[(9)] = inst_13656);

(statearr_13704[(10)] = inst_13653);

(statearr_13704[(11)] = inst_13678);

(statearr_13704[(12)] = inst_13654);

return statearr_13704;
})();
var statearr_13705_13745 = state_13701__$1;
(statearr_13705_13745[(2)] = null);

(statearr_13705_13745[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (1))){
var state_13701__$1 = state_13701;
var statearr_13706_13746 = state_13701__$1;
(statearr_13706_13746[(2)] = null);

(statearr_13706_13746[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (4))){
var inst_13642 = (state_13701[(13)]);
var inst_13642__$1 = (state_13701[(2)]);
var inst_13643 = (inst_13642__$1 == null);
var state_13701__$1 = (function (){var statearr_13707 = state_13701;
(statearr_13707[(13)] = inst_13642__$1);

return statearr_13707;
})();
if(cljs.core.truth_(inst_13643)){
var statearr_13708_13747 = state_13701__$1;
(statearr_13708_13747[(1)] = (5));

} else {
var statearr_13709_13748 = state_13701__$1;
(statearr_13709_13748[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (15))){
var state_13701__$1 = state_13701;
var statearr_13713_13749 = state_13701__$1;
(statearr_13713_13749[(2)] = null);

(statearr_13713_13749[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (21))){
var state_13701__$1 = state_13701;
var statearr_13714_13750 = state_13701__$1;
(statearr_13714_13750[(2)] = null);

(statearr_13714_13750[(1)] = (23));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (13))){
var inst_13655 = (state_13701[(8)]);
var inst_13656 = (state_13701[(9)]);
var inst_13653 = (state_13701[(10)]);
var inst_13654 = (state_13701[(12)]);
var inst_13663 = (state_13701[(2)]);
var inst_13664 = (inst_13656 + (1));
var tmp13710 = inst_13655;
var tmp13711 = inst_13653;
var tmp13712 = inst_13654;
var inst_13653__$1 = tmp13711;
var inst_13654__$1 = tmp13712;
var inst_13655__$1 = tmp13710;
var inst_13656__$1 = inst_13664;
var state_13701__$1 = (function (){var statearr_13715 = state_13701;
(statearr_13715[(8)] = inst_13655__$1);

(statearr_13715[(9)] = inst_13656__$1);

(statearr_13715[(10)] = inst_13653__$1);

(statearr_13715[(12)] = inst_13654__$1);

(statearr_13715[(14)] = inst_13663);

return statearr_13715;
})();
var statearr_13716_13751 = state_13701__$1;
(statearr_13716_13751[(2)] = null);

(statearr_13716_13751[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (22))){
var state_13701__$1 = state_13701;
var statearr_13717_13752 = state_13701__$1;
(statearr_13717_13752[(2)] = null);

(statearr_13717_13752[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (6))){
var inst_13642 = (state_13701[(13)]);
var inst_13651 = f.call(null,inst_13642);
var inst_13652 = cljs.core.seq.call(null,inst_13651);
var inst_13653 = inst_13652;
var inst_13654 = null;
var inst_13655 = (0);
var inst_13656 = (0);
var state_13701__$1 = (function (){var statearr_13718 = state_13701;
(statearr_13718[(8)] = inst_13655);

(statearr_13718[(9)] = inst_13656);

(statearr_13718[(10)] = inst_13653);

(statearr_13718[(12)] = inst_13654);

return statearr_13718;
})();
var statearr_13719_13753 = state_13701__$1;
(statearr_13719_13753[(2)] = null);

(statearr_13719_13753[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (17))){
var inst_13667 = (state_13701[(7)]);
var inst_13671 = cljs.core.chunk_first.call(null,inst_13667);
var inst_13672 = cljs.core.chunk_rest.call(null,inst_13667);
var inst_13673 = cljs.core.count.call(null,inst_13671);
var inst_13653 = inst_13672;
var inst_13654 = inst_13671;
var inst_13655 = inst_13673;
var inst_13656 = (0);
var state_13701__$1 = (function (){var statearr_13720 = state_13701;
(statearr_13720[(8)] = inst_13655);

(statearr_13720[(9)] = inst_13656);

(statearr_13720[(10)] = inst_13653);

(statearr_13720[(12)] = inst_13654);

return statearr_13720;
})();
var statearr_13721_13754 = state_13701__$1;
(statearr_13721_13754[(2)] = null);

(statearr_13721_13754[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (3))){
var inst_13699 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13701__$1,inst_13699);
} else {
if((state_val_13702 === (12))){
var inst_13687 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
var statearr_13722_13755 = state_13701__$1;
(statearr_13722_13755[(2)] = inst_13687);

(statearr_13722_13755[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (2))){
var state_13701__$1 = state_13701;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13701__$1,(4),in$);
} else {
if((state_val_13702 === (23))){
var inst_13695 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
var statearr_13723_13756 = state_13701__$1;
(statearr_13723_13756[(2)] = inst_13695);

(statearr_13723_13756[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (19))){
var inst_13682 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
var statearr_13724_13757 = state_13701__$1;
(statearr_13724_13757[(2)] = inst_13682);

(statearr_13724_13757[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (11))){
var inst_13667 = (state_13701[(7)]);
var inst_13653 = (state_13701[(10)]);
var inst_13667__$1 = cljs.core.seq.call(null,inst_13653);
var state_13701__$1 = (function (){var statearr_13725 = state_13701;
(statearr_13725[(7)] = inst_13667__$1);

return statearr_13725;
})();
if(inst_13667__$1){
var statearr_13726_13758 = state_13701__$1;
(statearr_13726_13758[(1)] = (14));

} else {
var statearr_13727_13759 = state_13701__$1;
(statearr_13727_13759[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (9))){
var inst_13689 = (state_13701[(2)]);
var inst_13690 = cljs.core.async.impl.protocols.closed_QMARK_.call(null,out);
var state_13701__$1 = (function (){var statearr_13728 = state_13701;
(statearr_13728[(15)] = inst_13689);

return statearr_13728;
})();
if(cljs.core.truth_(inst_13690)){
var statearr_13729_13760 = state_13701__$1;
(statearr_13729_13760[(1)] = (21));

} else {
var statearr_13730_13761 = state_13701__$1;
(statearr_13730_13761[(1)] = (22));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (5))){
var inst_13645 = cljs.core.async.close_BANG_.call(null,out);
var state_13701__$1 = state_13701;
var statearr_13731_13762 = state_13701__$1;
(statearr_13731_13762[(2)] = inst_13645);

(statearr_13731_13762[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (14))){
var inst_13667 = (state_13701[(7)]);
var inst_13669 = cljs.core.chunked_seq_QMARK_.call(null,inst_13667);
var state_13701__$1 = state_13701;
if(inst_13669){
var statearr_13732_13763 = state_13701__$1;
(statearr_13732_13763[(1)] = (17));

} else {
var statearr_13733_13764 = state_13701__$1;
(statearr_13733_13764[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (16))){
var inst_13685 = (state_13701[(2)]);
var state_13701__$1 = state_13701;
var statearr_13734_13765 = state_13701__$1;
(statearr_13734_13765[(2)] = inst_13685);

(statearr_13734_13765[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13702 === (10))){
var inst_13656 = (state_13701[(9)]);
var inst_13654 = (state_13701[(12)]);
var inst_13661 = cljs.core._nth.call(null,inst_13654,inst_13656);
var state_13701__$1 = state_13701;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13701__$1,(13),out,inst_13661);
} else {
if((state_val_13702 === (18))){
var inst_13667 = (state_13701[(7)]);
var inst_13676 = cljs.core.first.call(null,inst_13667);
var state_13701__$1 = state_13701;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13701__$1,(20),out,inst_13676);
} else {
if((state_val_13702 === (8))){
var inst_13655 = (state_13701[(8)]);
var inst_13656 = (state_13701[(9)]);
var inst_13658 = (inst_13656 < inst_13655);
var inst_13659 = inst_13658;
var state_13701__$1 = state_13701;
if(cljs.core.truth_(inst_13659)){
var statearr_13735_13766 = state_13701__$1;
(statearr_13735_13766[(1)] = (10));

} else {
var statearr_13736_13767 = state_13701__$1;
(statearr_13736_13767[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto__))
;
return ((function (switch__11132__auto__,c__11244__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____0 = (function (){
var statearr_13740 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_13740[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__);

(statearr_13740[(1)] = (1));

return statearr_13740;
});
var cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____1 = (function (state_13701){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13701);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13741){if((e13741 instanceof Object)){
var ex__11136__auto__ = e13741;
var statearr_13742_13768 = state_13701;
(statearr_13742_13768[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13701);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13741;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13769 = state_13701;
state_13701 = G__13769;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__ = function(state_13701){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____1.call(this,state_13701);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__11133__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto__))
})();
var state__11246__auto__ = (function (){var statearr_13743 = f__11245__auto__.call(null);
(statearr_13743[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto__);

return statearr_13743;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto__))
);

return c__11244__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var args13770 = [];
var len__7484__auto___13773 = arguments.length;
var i__7485__auto___13774 = (0);
while(true){
if((i__7485__auto___13774 < len__7484__auto___13773)){
args13770.push((arguments[i__7485__auto___13774]));

var G__13775 = (i__7485__auto___13774 + (1));
i__7485__auto___13774 = G__13775;
continue;
} else {
}
break;
}

var G__13772 = args13770.length;
switch (G__13772) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13770.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.call(null,f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var args13777 = [];
var len__7484__auto___13780 = arguments.length;
var i__7485__auto___13781 = (0);
while(true){
if((i__7485__auto___13781 < len__7484__auto___13780)){
args13777.push((arguments[i__7485__auto___13781]));

var G__13782 = (i__7485__auto___13781 + (1));
i__7485__auto___13781 = G__13782;
continue;
} else {
}
break;
}

var G__13779 = args13777.length;
switch (G__13779) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13777.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.call(null,f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var args13784 = [];
var len__7484__auto___13835 = arguments.length;
var i__7485__auto___13836 = (0);
while(true){
if((i__7485__auto___13836 < len__7484__auto___13835)){
args13784.push((arguments[i__7485__auto___13836]));

var G__13837 = (i__7485__auto___13836 + (1));
i__7485__auto___13836 = G__13837;
continue;
} else {
}
break;
}

var G__13786 = args13784.length;
switch (G__13786) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13784.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.call(null,ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___13839 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13839,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13839,out){
return (function (state_13810){
var state_val_13811 = (state_13810[(1)]);
if((state_val_13811 === (7))){
var inst_13805 = (state_13810[(2)]);
var state_13810__$1 = state_13810;
var statearr_13812_13840 = state_13810__$1;
(statearr_13812_13840[(2)] = inst_13805);

(statearr_13812_13840[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (1))){
var inst_13787 = null;
var state_13810__$1 = (function (){var statearr_13813 = state_13810;
(statearr_13813[(7)] = inst_13787);

return statearr_13813;
})();
var statearr_13814_13841 = state_13810__$1;
(statearr_13814_13841[(2)] = null);

(statearr_13814_13841[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (4))){
var inst_13790 = (state_13810[(8)]);
var inst_13790__$1 = (state_13810[(2)]);
var inst_13791 = (inst_13790__$1 == null);
var inst_13792 = cljs.core.not.call(null,inst_13791);
var state_13810__$1 = (function (){var statearr_13815 = state_13810;
(statearr_13815[(8)] = inst_13790__$1);

return statearr_13815;
})();
if(inst_13792){
var statearr_13816_13842 = state_13810__$1;
(statearr_13816_13842[(1)] = (5));

} else {
var statearr_13817_13843 = state_13810__$1;
(statearr_13817_13843[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (6))){
var state_13810__$1 = state_13810;
var statearr_13818_13844 = state_13810__$1;
(statearr_13818_13844[(2)] = null);

(statearr_13818_13844[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (3))){
var inst_13807 = (state_13810[(2)]);
var inst_13808 = cljs.core.async.close_BANG_.call(null,out);
var state_13810__$1 = (function (){var statearr_13819 = state_13810;
(statearr_13819[(9)] = inst_13807);

return statearr_13819;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13810__$1,inst_13808);
} else {
if((state_val_13811 === (2))){
var state_13810__$1 = state_13810;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13810__$1,(4),ch);
} else {
if((state_val_13811 === (11))){
var inst_13790 = (state_13810[(8)]);
var inst_13799 = (state_13810[(2)]);
var inst_13787 = inst_13790;
var state_13810__$1 = (function (){var statearr_13820 = state_13810;
(statearr_13820[(10)] = inst_13799);

(statearr_13820[(7)] = inst_13787);

return statearr_13820;
})();
var statearr_13821_13845 = state_13810__$1;
(statearr_13821_13845[(2)] = null);

(statearr_13821_13845[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (9))){
var inst_13790 = (state_13810[(8)]);
var state_13810__$1 = state_13810;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13810__$1,(11),out,inst_13790);
} else {
if((state_val_13811 === (5))){
var inst_13790 = (state_13810[(8)]);
var inst_13787 = (state_13810[(7)]);
var inst_13794 = cljs.core._EQ_.call(null,inst_13790,inst_13787);
var state_13810__$1 = state_13810;
if(inst_13794){
var statearr_13823_13846 = state_13810__$1;
(statearr_13823_13846[(1)] = (8));

} else {
var statearr_13824_13847 = state_13810__$1;
(statearr_13824_13847[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (10))){
var inst_13802 = (state_13810[(2)]);
var state_13810__$1 = state_13810;
var statearr_13825_13848 = state_13810__$1;
(statearr_13825_13848[(2)] = inst_13802);

(statearr_13825_13848[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13811 === (8))){
var inst_13787 = (state_13810[(7)]);
var tmp13822 = inst_13787;
var inst_13787__$1 = tmp13822;
var state_13810__$1 = (function (){var statearr_13826 = state_13810;
(statearr_13826[(7)] = inst_13787__$1);

return statearr_13826;
})();
var statearr_13827_13849 = state_13810__$1;
(statearr_13827_13849[(2)] = null);

(statearr_13827_13849[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13839,out))
;
return ((function (switch__11132__auto__,c__11244__auto___13839,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13831 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_13831[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13831[(1)] = (1));

return statearr_13831;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13810){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13810);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13832){if((e13832 instanceof Object)){
var ex__11136__auto__ = e13832;
var statearr_13833_13850 = state_13810;
(statearr_13833_13850[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13810);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13832;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13851 = state_13810;
state_13810 = G__13851;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13810){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13810);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13839,out))
})();
var state__11246__auto__ = (function (){var statearr_13834 = f__11245__auto__.call(null);
(statearr_13834[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13839);

return statearr_13834;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13839,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var args13852 = [];
var len__7484__auto___13922 = arguments.length;
var i__7485__auto___13923 = (0);
while(true){
if((i__7485__auto___13923 < len__7484__auto___13922)){
args13852.push((arguments[i__7485__auto___13923]));

var G__13924 = (i__7485__auto___13923 + (1));
i__7485__auto___13923 = G__13924;
continue;
} else {
}
break;
}

var G__13854 = args13852.length;
switch (G__13854) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13852.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.call(null,n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___13926 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___13926,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___13926,out){
return (function (state_13892){
var state_val_13893 = (state_13892[(1)]);
if((state_val_13893 === (7))){
var inst_13888 = (state_13892[(2)]);
var state_13892__$1 = state_13892;
var statearr_13894_13927 = state_13892__$1;
(statearr_13894_13927[(2)] = inst_13888);

(statearr_13894_13927[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (1))){
var inst_13855 = (new Array(n));
var inst_13856 = inst_13855;
var inst_13857 = (0);
var state_13892__$1 = (function (){var statearr_13895 = state_13892;
(statearr_13895[(7)] = inst_13857);

(statearr_13895[(8)] = inst_13856);

return statearr_13895;
})();
var statearr_13896_13928 = state_13892__$1;
(statearr_13896_13928[(2)] = null);

(statearr_13896_13928[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (4))){
var inst_13860 = (state_13892[(9)]);
var inst_13860__$1 = (state_13892[(2)]);
var inst_13861 = (inst_13860__$1 == null);
var inst_13862 = cljs.core.not.call(null,inst_13861);
var state_13892__$1 = (function (){var statearr_13897 = state_13892;
(statearr_13897[(9)] = inst_13860__$1);

return statearr_13897;
})();
if(inst_13862){
var statearr_13898_13929 = state_13892__$1;
(statearr_13898_13929[(1)] = (5));

} else {
var statearr_13899_13930 = state_13892__$1;
(statearr_13899_13930[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (15))){
var inst_13882 = (state_13892[(2)]);
var state_13892__$1 = state_13892;
var statearr_13900_13931 = state_13892__$1;
(statearr_13900_13931[(2)] = inst_13882);

(statearr_13900_13931[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (13))){
var state_13892__$1 = state_13892;
var statearr_13901_13932 = state_13892__$1;
(statearr_13901_13932[(2)] = null);

(statearr_13901_13932[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (6))){
var inst_13857 = (state_13892[(7)]);
var inst_13878 = (inst_13857 > (0));
var state_13892__$1 = state_13892;
if(cljs.core.truth_(inst_13878)){
var statearr_13902_13933 = state_13892__$1;
(statearr_13902_13933[(1)] = (12));

} else {
var statearr_13903_13934 = state_13892__$1;
(statearr_13903_13934[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (3))){
var inst_13890 = (state_13892[(2)]);
var state_13892__$1 = state_13892;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13892__$1,inst_13890);
} else {
if((state_val_13893 === (12))){
var inst_13856 = (state_13892[(8)]);
var inst_13880 = cljs.core.vec.call(null,inst_13856);
var state_13892__$1 = state_13892;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13892__$1,(15),out,inst_13880);
} else {
if((state_val_13893 === (2))){
var state_13892__$1 = state_13892;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13892__$1,(4),ch);
} else {
if((state_val_13893 === (11))){
var inst_13872 = (state_13892[(2)]);
var inst_13873 = (new Array(n));
var inst_13856 = inst_13873;
var inst_13857 = (0);
var state_13892__$1 = (function (){var statearr_13904 = state_13892;
(statearr_13904[(7)] = inst_13857);

(statearr_13904[(10)] = inst_13872);

(statearr_13904[(8)] = inst_13856);

return statearr_13904;
})();
var statearr_13905_13935 = state_13892__$1;
(statearr_13905_13935[(2)] = null);

(statearr_13905_13935[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (9))){
var inst_13856 = (state_13892[(8)]);
var inst_13870 = cljs.core.vec.call(null,inst_13856);
var state_13892__$1 = state_13892;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13892__$1,(11),out,inst_13870);
} else {
if((state_val_13893 === (5))){
var inst_13857 = (state_13892[(7)]);
var inst_13860 = (state_13892[(9)]);
var inst_13856 = (state_13892[(8)]);
var inst_13865 = (state_13892[(11)]);
var inst_13864 = (inst_13856[inst_13857] = inst_13860);
var inst_13865__$1 = (inst_13857 + (1));
var inst_13866 = (inst_13865__$1 < n);
var state_13892__$1 = (function (){var statearr_13906 = state_13892;
(statearr_13906[(12)] = inst_13864);

(statearr_13906[(11)] = inst_13865__$1);

return statearr_13906;
})();
if(cljs.core.truth_(inst_13866)){
var statearr_13907_13936 = state_13892__$1;
(statearr_13907_13936[(1)] = (8));

} else {
var statearr_13908_13937 = state_13892__$1;
(statearr_13908_13937[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (14))){
var inst_13885 = (state_13892[(2)]);
var inst_13886 = cljs.core.async.close_BANG_.call(null,out);
var state_13892__$1 = (function (){var statearr_13910 = state_13892;
(statearr_13910[(13)] = inst_13885);

return statearr_13910;
})();
var statearr_13911_13938 = state_13892__$1;
(statearr_13911_13938[(2)] = inst_13886);

(statearr_13911_13938[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (10))){
var inst_13876 = (state_13892[(2)]);
var state_13892__$1 = state_13892;
var statearr_13912_13939 = state_13892__$1;
(statearr_13912_13939[(2)] = inst_13876);

(statearr_13912_13939[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13893 === (8))){
var inst_13856 = (state_13892[(8)]);
var inst_13865 = (state_13892[(11)]);
var tmp13909 = inst_13856;
var inst_13856__$1 = tmp13909;
var inst_13857 = inst_13865;
var state_13892__$1 = (function (){var statearr_13913 = state_13892;
(statearr_13913[(7)] = inst_13857);

(statearr_13913[(8)] = inst_13856__$1);

return statearr_13913;
})();
var statearr_13914_13940 = state_13892__$1;
(statearr_13914_13940[(2)] = null);

(statearr_13914_13940[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___13926,out))
;
return ((function (switch__11132__auto__,c__11244__auto___13926,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_13918 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_13918[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_13918[(1)] = (1));

return statearr_13918;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13892){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13892);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e13919){if((e13919 instanceof Object)){
var ex__11136__auto__ = e13919;
var statearr_13920_13941 = state_13892;
(statearr_13920_13941[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13892);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e13919;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__13942 = state_13892;
state_13892 = G__13942;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13892){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13892);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___13926,out))
})();
var state__11246__auto__ = (function (){var statearr_13921 = f__11245__auto__.call(null);
(statearr_13921[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___13926);

return statearr_13921;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___13926,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;

/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var args13943 = [];
var len__7484__auto___14017 = arguments.length;
var i__7485__auto___14018 = (0);
while(true){
if((i__7485__auto___14018 < len__7484__auto___14017)){
args13943.push((arguments[i__7485__auto___14018]));

var G__14019 = (i__7485__auto___14018 + (1));
i__7485__auto___14018 = G__14019;
continue;
} else {
}
break;
}

var G__13945 = args13943.length;
switch (G__13945) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args13943.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.call(null,f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__11244__auto___14021 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__11244__auto___14021,out){
return (function (){
var f__11245__auto__ = (function (){var switch__11132__auto__ = ((function (c__11244__auto___14021,out){
return (function (state_13987){
var state_val_13988 = (state_13987[(1)]);
if((state_val_13988 === (7))){
var inst_13983 = (state_13987[(2)]);
var state_13987__$1 = state_13987;
var statearr_13989_14022 = state_13987__$1;
(statearr_13989_14022[(2)] = inst_13983);

(statearr_13989_14022[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (1))){
var inst_13946 = [];
var inst_13947 = inst_13946;
var inst_13948 = new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123);
var state_13987__$1 = (function (){var statearr_13990 = state_13987;
(statearr_13990[(7)] = inst_13947);

(statearr_13990[(8)] = inst_13948);

return statearr_13990;
})();
var statearr_13991_14023 = state_13987__$1;
(statearr_13991_14023[(2)] = null);

(statearr_13991_14023[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (4))){
var inst_13951 = (state_13987[(9)]);
var inst_13951__$1 = (state_13987[(2)]);
var inst_13952 = (inst_13951__$1 == null);
var inst_13953 = cljs.core.not.call(null,inst_13952);
var state_13987__$1 = (function (){var statearr_13992 = state_13987;
(statearr_13992[(9)] = inst_13951__$1);

return statearr_13992;
})();
if(inst_13953){
var statearr_13993_14024 = state_13987__$1;
(statearr_13993_14024[(1)] = (5));

} else {
var statearr_13994_14025 = state_13987__$1;
(statearr_13994_14025[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (15))){
var inst_13977 = (state_13987[(2)]);
var state_13987__$1 = state_13987;
var statearr_13995_14026 = state_13987__$1;
(statearr_13995_14026[(2)] = inst_13977);

(statearr_13995_14026[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (13))){
var state_13987__$1 = state_13987;
var statearr_13996_14027 = state_13987__$1;
(statearr_13996_14027[(2)] = null);

(statearr_13996_14027[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (6))){
var inst_13947 = (state_13987[(7)]);
var inst_13972 = inst_13947.length;
var inst_13973 = (inst_13972 > (0));
var state_13987__$1 = state_13987;
if(cljs.core.truth_(inst_13973)){
var statearr_13997_14028 = state_13987__$1;
(statearr_13997_14028[(1)] = (12));

} else {
var statearr_13998_14029 = state_13987__$1;
(statearr_13998_14029[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (3))){
var inst_13985 = (state_13987[(2)]);
var state_13987__$1 = state_13987;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_13987__$1,inst_13985);
} else {
if((state_val_13988 === (12))){
var inst_13947 = (state_13987[(7)]);
var inst_13975 = cljs.core.vec.call(null,inst_13947);
var state_13987__$1 = state_13987;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13987__$1,(15),out,inst_13975);
} else {
if((state_val_13988 === (2))){
var state_13987__$1 = state_13987;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_13987__$1,(4),ch);
} else {
if((state_val_13988 === (11))){
var inst_13955 = (state_13987[(10)]);
var inst_13951 = (state_13987[(9)]);
var inst_13965 = (state_13987[(2)]);
var inst_13966 = [];
var inst_13967 = inst_13966.push(inst_13951);
var inst_13947 = inst_13966;
var inst_13948 = inst_13955;
var state_13987__$1 = (function (){var statearr_13999 = state_13987;
(statearr_13999[(7)] = inst_13947);

(statearr_13999[(11)] = inst_13965);

(statearr_13999[(12)] = inst_13967);

(statearr_13999[(8)] = inst_13948);

return statearr_13999;
})();
var statearr_14000_14030 = state_13987__$1;
(statearr_14000_14030[(2)] = null);

(statearr_14000_14030[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (9))){
var inst_13947 = (state_13987[(7)]);
var inst_13963 = cljs.core.vec.call(null,inst_13947);
var state_13987__$1 = state_13987;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_13987__$1,(11),out,inst_13963);
} else {
if((state_val_13988 === (5))){
var inst_13955 = (state_13987[(10)]);
var inst_13948 = (state_13987[(8)]);
var inst_13951 = (state_13987[(9)]);
var inst_13955__$1 = f.call(null,inst_13951);
var inst_13956 = cljs.core._EQ_.call(null,inst_13955__$1,inst_13948);
var inst_13957 = cljs.core.keyword_identical_QMARK_.call(null,inst_13948,new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123));
var inst_13958 = (inst_13956) || (inst_13957);
var state_13987__$1 = (function (){var statearr_14001 = state_13987;
(statearr_14001[(10)] = inst_13955__$1);

return statearr_14001;
})();
if(cljs.core.truth_(inst_13958)){
var statearr_14002_14031 = state_13987__$1;
(statearr_14002_14031[(1)] = (8));

} else {
var statearr_14003_14032 = state_13987__$1;
(statearr_14003_14032[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (14))){
var inst_13980 = (state_13987[(2)]);
var inst_13981 = cljs.core.async.close_BANG_.call(null,out);
var state_13987__$1 = (function (){var statearr_14005 = state_13987;
(statearr_14005[(13)] = inst_13980);

return statearr_14005;
})();
var statearr_14006_14033 = state_13987__$1;
(statearr_14006_14033[(2)] = inst_13981);

(statearr_14006_14033[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (10))){
var inst_13970 = (state_13987[(2)]);
var state_13987__$1 = state_13987;
var statearr_14007_14034 = state_13987__$1;
(statearr_14007_14034[(2)] = inst_13970);

(statearr_14007_14034[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_13988 === (8))){
var inst_13947 = (state_13987[(7)]);
var inst_13955 = (state_13987[(10)]);
var inst_13951 = (state_13987[(9)]);
var inst_13960 = inst_13947.push(inst_13951);
var tmp14004 = inst_13947;
var inst_13947__$1 = tmp14004;
var inst_13948 = inst_13955;
var state_13987__$1 = (function (){var statearr_14008 = state_13987;
(statearr_14008[(7)] = inst_13947__$1);

(statearr_14008[(14)] = inst_13960);

(statearr_14008[(8)] = inst_13948);

return statearr_14008;
})();
var statearr_14009_14035 = state_13987__$1;
(statearr_14009_14035[(2)] = null);

(statearr_14009_14035[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__11244__auto___14021,out))
;
return ((function (switch__11132__auto__,c__11244__auto___14021,out){
return (function() {
var cljs$core$async$state_machine__11133__auto__ = null;
var cljs$core$async$state_machine__11133__auto____0 = (function (){
var statearr_14013 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_14013[(0)] = cljs$core$async$state_machine__11133__auto__);

(statearr_14013[(1)] = (1));

return statearr_14013;
});
var cljs$core$async$state_machine__11133__auto____1 = (function (state_13987){
while(true){
var ret_value__11134__auto__ = (function (){try{while(true){
var result__11135__auto__ = switch__11132__auto__.call(null,state_13987);
if(cljs.core.keyword_identical_QMARK_.call(null,result__11135__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__11135__auto__;
}
break;
}
}catch (e14014){if((e14014 instanceof Object)){
var ex__11136__auto__ = e14014;
var statearr_14015_14036 = state_13987;
(statearr_14015_14036[(5)] = ex__11136__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_13987);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e14014;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__11134__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__14037 = state_13987;
state_13987 = G__14037;
continue;
} else {
return ret_value__11134__auto__;
}
break;
}
});
cljs$core$async$state_machine__11133__auto__ = function(state_13987){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__11133__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__11133__auto____1.call(this,state_13987);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__11133__auto____0;
cljs$core$async$state_machine__11133__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__11133__auto____1;
return cljs$core$async$state_machine__11133__auto__;
})()
;})(switch__11132__auto__,c__11244__auto___14021,out))
})();
var state__11246__auto__ = (function (){var statearr_14016 = f__11245__auto__.call(null);
(statearr_14016[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__11244__auto___14021);

return statearr_14016;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__11246__auto__);
});})(c__11244__auto___14021,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;

