// Compiled by ClojureScript 1.9.229 {}
goog.provide('nonotes.prod');
goog.require('cljs.core');
goog.require('nonotes.core');
cljs.core._STAR_print_fn_STAR_ = (function() { 
var G__14137__delegate = function (_){
return null;
};
var G__14137 = function (var_args){
var _ = null;
if (arguments.length > 0) {
var G__14138__i = 0, G__14138__a = new Array(arguments.length -  0);
while (G__14138__i < G__14138__a.length) {G__14138__a[G__14138__i] = arguments[G__14138__i + 0]; ++G__14138__i;}
  _ = new cljs.core.IndexedSeq(G__14138__a,0);
} 
return G__14137__delegate.call(this,_);};
G__14137.cljs$lang$maxFixedArity = 0;
G__14137.cljs$lang$applyTo = (function (arglist__14139){
var _ = cljs.core.seq(arglist__14139);
return G__14137__delegate(_);
});
G__14137.cljs$core$IFn$_invoke$arity$variadic = G__14137__delegate;
return G__14137;
})()
;
nonotes.core.init_BANG_.call(null);
