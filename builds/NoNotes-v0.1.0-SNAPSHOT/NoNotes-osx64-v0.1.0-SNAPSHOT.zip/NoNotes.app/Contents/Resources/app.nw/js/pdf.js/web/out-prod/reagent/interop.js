// Compiled by ClojureScript 1.9.229 {}
goog.provide('reagent.interop');
goog.require('cljs.core');
